export const CAR_MAKES = [
  "Toyota", "Honda", "Nissan", "Mercedes-Benz", "BMW", "Audi", "Volkswagen", 
  "Hyundai", "Kia", "Mazda", "Subaru", "Ford", "Chevrolet", "Peugeot", 
  "Mitsubishi", "Suzuki", "Isuzu", "Land Rover", "Jeep", "Volvo", "Lexus",
  "Infiniti", "Acura", "Jaguar", "Porsche", "Ferrari", "Lamborghini", 
  "Maserati", "Alfa Romeo", "Fiat", "Renault", "Citroën", "Skoda", 
  "SEAT", "Dacia", "Lada"
];

export const CAR_MODELS: Record<string, string[]> = {
  "Toyota": [
    "Camry", "Corolla", "RAV4", "Prado", "Hilux", "Vitz", "Wish", "Mark X", "Harrier", "Land Cruiser",
    "Prius", "Yaris", "Avalon", "Highlander", "4Runner", "Tacoma", "Tundra", "Sienna", "Sequoia",
    "C-HR", "Venza", "Supra", "86", "Mirai", "Crown", "Alphard", "Vellfire", "Noah", "Voxy",
    "Hiace", "Coaster", "Dyna", "Probox", "Succeed", "Platz", "Belta", "Ractis", "Spacio",
    "Caldina", "Avensis", "Auris", "Verso", "Estima", "Previa", "Celica", "MR2", "Terrios"
  ],
  "Honda": [
    "Civic", "Accord", "CR-V", "Fit", "HR-V", "Pilot", "Ridgeline", "Passport", "Odyssey",
    "Insight", "Clarity", "City", "Jazz", "BR-V", "WR-V", "Amaze", "Brio", "Mobilio",
    "CR-Z", "S2000", "NSX", "Element", "CR-X", "Prelude", "Integra", "Legend", "Vigor",
    "Stream", "Freed", "Stepwgn", "Shuttle", "Grace", "Vezel", "Jade", "Spike"
  ],
  "Nissan": [
    "Altima", "Sentra", "Rogue", "Pathfinder", "Murano", "X-Trail", "Note", "Juke", "Maxima",
    "Armada", "Titan", "Frontier", "Versa", "Kicks", "Leaf", "370Z", "GT-R", "Quest",
    "Cube", "Micra", "March", "Sunny", "Almera", "Primera", "Teana", "Cefiro", "Skyline",
    "Patrol", "Navara", "Elgrand", "Serena", "Vanette", "Caravan", "NV200", "Tiida",
    "Livina", "Lafesta", "Wingroad", "AD", "Expert", "Clipper", "Moco", "Roox"
  ],
  "Mercedes-Benz": [
    "C-Class", "E-Class", "S-Class", "GLC", "GLE", "GLS", "A-Class", "CLA", "CLS", "G-Class",
    "GLB", "GLA", "AMG GT", "SL", "SLK", "SLC", "ML", "GL", "GLK", "R-Class", "B-Class",
    "Sprinter", "Vito", "Metris", "V-Class", "Viano", "Vaneo", "Citan"
  ],
  "BMW": [
    "1 Series", "2 Series", "3 Series", "4 Series", "5 Series", "6 Series", "7 Series", "8 Series",
    "X1", "X2", "X3", "X4", "X5", "X6", "X7", "Z3", "Z4", "i3", "i8", "iX", "M2", "M3", "M4", "M5", "M6", "M8"
  ],
  "Audi": [
    "A1", "A3", "A4", "A5", "A6", "A7", "A8", "Q2", "Q3", "Q4", "Q5", "Q7", "Q8", "TT", "R8",
    "RS3", "RS4", "RS5", "RS6", "RS7", "RS Q8", "S3", "S4", "S5", "S6", "S7", "S8", "SQ5", "SQ7", "SQ8"
  ],
  "Volkswagen": [
    "Golf", "Jetta", "Passat", "Tiguan", "Atlas", "Beetle", "Arteon", "ID.4", "Touareg",
    "Polo", "Up!", "T-Cross", "T-Roc", "Sharan", "Touran", "Caddy", "Crafter", "Amarok",
    "Scirocco", "Eos", "Phaeton", "CC", "Routan", "Rabbit"
  ],
  "Hyundai": [
    "Elantra", "Sonata", "Tucson", "Santa Fe", "Accent", "Veloster", "Genesis", "Palisade",
    "Kona", "Venue", "Ioniq", "Nexo", "Azera", "Equus", "Entourage", "Veracruz", "Tiburon",
    "XG300", "XG350", "i10", "i20", "i30", "ix35", "ix55", "Matrix", "Getz", "Atos"
  ],
  "Kia": [
    "Rio", "Forte", "Optima", "Stinger", "Soul", "Sportage", "Sorento", "Telluride", "Niro",
    "Seltos", "Carnival", "Sedona", "Cadenza", "K900", "Borrego", "Rondo", "Spectra",
    "Amanti", "Magentis", "Cerato", "Picanto", "Venga", "Ceed", "Carens"
  ],
  "Mazda": [
    "Mazda2", "Mazda3", "Mazda6", "CX-3", "CX-30", "CX-5", "CX-9", "CX-90", "MX-5 Miata",
    "MX-30", "Tribute", "MPV", "B-Series", "RX-7", "RX-8", "Protégé", "Millenia",
    "929", "626", "323", "121", "Demio", "Premacy", "Atenza", "Axela", "Biante"
  ],
  "Subaru": [
    "Impreza", "Legacy", "Outback", "Forester", "Crosstrek", "Ascent", "WRX", "BRZ",
    "Tribeca", "Baja", "SVX", "XT", "Justy", "Loyale", "GL", "DL", "Leone",
    "Alcyone", "Sambar", "Stella", "R2", "R1", "Vivio", "Pleo", "Domingo"
  ],
  "Ford": [
    "Fiesta", "Focus", "Fusion", "Mustang", "Explorer", "Escape", "Edge", "Expedition",
    "F-150", "F-250", "F-350", "Ranger", "Bronco", "EcoSport", "Kuga", "Mondeo",
    "Galaxy", "S-Max", "C-Max", "B-Max", "Ka", "Puma", "Cougar", "Probe", "Taurus",
    "Crown Victoria", "Thunderbird", "GT", "Transit", "Tourneo"
  ],
  "Chevrolet": [
    "Spark", "Sonic", "Cruze", "Malibu", "Impala", "Camaro", "Corvette", "Trax", "Equinox",
    "Traverse", "Tahoe", "Suburban", "Silverado", "Colorado", "Blazer", "Aveo", "Cobalt",
    "HHR", "SSR", "Monte Carlo", "Lumina", "Cavalier", "Beretta", "Corsica", "Celebrity"
  ],
  "Peugeot": [
    "108", "208", "308", "508", "2008", "3008", "5008", "Partner", "Expert", "Boxer",
    "RCZ", "407", "607", "807", "1007", "4007", "206", "306", "406", "106", "205", "405"
  ],
  "Mitsubishi": [
    "Mirage", "Lancer", "Outlander", "Eclipse Cross", "Pajero", "Montero", "ASX", "RVR",
    "Galant", "Diamante", "3000GT", "Eclipse", "Starion", "Colt", "Carisma", "Space Star",
    "Grandis", "Endeavor", "Raider", "L200", "Triton", "Delica", "Chariot"
  ],
  "Suzuki": [
    "Swift", "Baleno", "Vitara", "S-Cross", "Jimny", "Ignis", "Celerio", "Alto", "Wagon R",
    "Ertiga", "XL7", "SX4", "Kizashi", "Grand Vitara", "Aerio", "Forenza", "Reno",
    "Verona", "Esteem", "Sidekick", "Samurai", "X-90", "Cappuccino", "Cultus", "Every"
  ],
  "Isuzu": [
    "D-Max", "MU-X", "Trooper", "Rodeo", "Ascender", "Axiom", "VehiCROSS", "Amigo",
    "Pickup", "Hombre", "Impulse", "Stylus", "I-Mark", "I-Series", "NPR", "NQR", "FRR"
  ],
  "Land Rover": [
    "Range Rover", "Range Rover Sport", "Range Rover Evoque", "Range Rover Velar", "Discovery",
    "Discovery Sport", "Defender", "Freelander", "LR2", "LR3", "LR4", "Series I", "Series II", "Series III"
  ],
  "Jeep": [
    "Wrangler", "Grand Cherokee", "Cherokee", "Compass", "Renegade", "Gladiator", "Commander",
    "Liberty", "Patriot", "CJ-5", "CJ-7", "Wagoneer", "Grand Wagoneer", "Comanche"
  ],
  "Volvo": [
    "XC40", "XC60", "XC90", "S60", "S90", "V60", "V90", "C40", "C70", "S40", "V40", "V50",
    "S80", "V70", "XC70", "850", "960", "940", "740", "240", "140", "Amazon"
  ],
  "Lexus": [
    "ES", "IS", "GS", "LS", "UX", "NX", "RX", "GX", "LX", "LC", "RC", "CT", "HS", "SC"
  ],
  "Infiniti": [
    "Q50", "Q60", "Q70", "QX30", "QX50", "QX60", "QX80", "G35", "G37", "M35", "M45", "FX35", "FX45"
  ],
  "Acura": [
    "ILX", "TLX", "RLX", "RDX", "MDX", "NSX", "TSX", "TL", "RL", "RSX", "Integra", "Legend", "Vigor"
  ],
  "Jaguar": [
    "XE", "XF", "XJ", "F-PACE", "E-PACE", "I-PACE", "F-TYPE", "XK", "XJS", "S-Type", "X-Type"
  ],
  "Porsche": [
    "911", "Boxster", "Cayman", "Panamera", "Macan", "Cayenne", "Taycan", "928", "944", "968", "914"
  ],
  "Ferrari": [
    "488", "F8", "Roma", "Portofino", "GTC4Lusso", "812", "LaFerrari", "California", "458", "599"
  ],
  "Lamborghini": [
    "Huracán", "Aventador", "Urus", "Gallardo", "Murciélago", "Countach", "Diablo"
  ],
  "Maserati": [
    "Ghibli", "Quattroporte", "Levante", "GranTurismo", "GranCabrio"
  ],
  "Alfa Romeo": [
    "Giulia", "Stelvio", "4C", "Spider", "159", "156", "147", "GTV", "166"
  ],
  "Fiat": [
    "500", "Panda", "Punto", "Tipo", "500X", "500L", "Doblo", "Ducato", "Bravo", "Stilo"
  ],
  "Renault": [
    "Clio", "Megane", "Scenic", "Kadjar", "Captur", "Koleos", "Duster", "Logan", "Sandero", "Twingo"
  ],
  "Citroën": [
    "C1", "C3", "C4", "C5", "C3 Aircross", "C5 Aircross", "Berlingo", "Spacetourer", "Jumper"
  ],
  "Skoda": [
    "Fabia", "Octavia", "Superb", "Kamiq", "Karoq", "Kodiaq", "Rapid", "Yeti", "Roomster"
  ],
  "SEAT": [
    "Ibiza", "Leon", "Arona", "Ateca", "Tarraco", "Alhambra", "Toledo", "Altea", "Cordoba"
  ],
  "Dacia": [
    "Sandero", "Logan", "Duster", "Lodgy", "Dokker", "Spring"
  ],
  "Lada": [
    "Granta", "Vesta", "XRAY", "Largus", "4x4", "Kalina", "Priora", "Samara"
  ]
};

export const PROPERTY_TYPES = [
  { value: "land", label: "Land/Plots" },
  { value: "house", label: "Houses" }
];

export const LISTING_TYPES = [
  { value: "sale", label: "For Sale" },
  { value: "rent", label: "For Rent" },
  { value: "lease", label: "For Lease" }
];

export const CAR_CONDITIONS = [
  { value: "excellent", label: "Excellent" },
  { value: "good", label: "Good" },
  { value: "fair", label: "Fair" },
  { value: "poor", label: "Poor" }
];

export const PAYMENT_METHODS = [
  { value: "cash", label: "Cash Payment" },
  { value: "installments", label: "Installments Available" }
];

export const KENYAN_COUNTIES = [
  "Nairobi",
  "Kiambu", 
  "Kajiado",
  "Machakos",
  "Murang'a",
  "Nyeri",
  "Mombasa",
  "Kilifi",
  "Kwale",
  "Nakuru",
  "Uasin Gishu",
  "Kisumu",
  "Siaya",
  "Kakamega",
  "Bungoma",
  "Meru",
  "Embu",
  "Tharaka-Nithi",
  "Kitui",
  "Makueni",
  "Garissa",
  "Wajir",
  "Mandera",
  "Marsabit",
  "Isiolo",
  "Samburu",
  "Turkana",
  "West Pokot",
  "Trans Nzoia",
  "Busia",
  "Vihiga",
  "Nandi",
  "Kericho",
  "Bomet",
  "Narok",
  "Laikipia",
  "Baringo",
  "Elgeyo-Marakwet",
  "Nyandarua",
  "Kirinyaga",
  "Taita-Taveta",
  "Lamu",
  "Tana River",
  "Homa Bay",
  "Migori",
  "Kisii",
  "Nyamira"
];

export const COUNTY_TOWNS: Record<string, string[]> = {
  "Nairobi": [
    "CBD", "Westlands", "Karen", "Lavington", "Kilimani", "Kileleshwa",
    "Parklands", "Spring Valley", "Runda", "Muthaiga", "Gigiri", "Kitisuru",
    "Langata", "South C", "South B", "Embakasi", "Kasarani", "Roysambu",
    "Kahawa", "Ruiru", "Thika Road", "Ngong Road", "Mombasa Road", "Donholm",
    "Umoja", "Kariobangi", "Huruma", "Mathare", "Pangani", "Eastleigh",
    "Kamulu", "Ruai", "Mihango", "Pipeline", "Komarock", "Kayole", "Dandora",
    "Kariokor", "Shauri Moyo", "Makongeni", "Buruburu", "Jericho", "Lumumba",
    "Woodley", "Dagoretti", "Kawangware", "Riruta", "Satellite", "Uthiru"
  ],
  "Kiambu": [
    "Thika", "Ruiru", "Kikuyu", "Limuru", "Kiambu Town", "Juja", "Ruaka",
    "Banana", "Githurai", "Kahawa", "Kamiti", "Karuri", "Ndenderu",
    "Tigoni", "Lari", "Gatundu", "Githunguri", "Kabete", "Kirigiti",
    "Gachie", "Muchatha", "Kinoo", "Wangige", "Zambezi", "Uthiru",
    "Regen", "Kinale", "Nyathuna", "Komothai", "Mangu", "Makuyu"
  ],
  "Kajiado": [
    "Ongata Rongai", "Kitengela", "Ngong", "Kajiado Town", "Namanga",
    "Kiserian", "Magadi", "Loitokitok", "Mashuru", "Bissil", "Ewaso Nyiro"
  ],
  "Machakos": [
    "Machakos Town", "Mavoko", "Athi River", "Kangundo", "Matungulu",
    "Yatta", "Masii", "Mwala", "Kathiani", "Syokimau"
  ],
  "Murang'a": [
    "Murang'a Town", "Kenol", "Sagana", "Kandara", "Kigumo", "Maragua"
  ],
  "Nyeri": [
    "Nyeri Town", "Karatina", "Othaya", "Mukurwe-ini", "Tetu", "Mathira"
  ],
  "Nakuru": [
    "Nakuru Town", "Naivasha", "Gilgil", "Molo", "Njoro", "Elburgon",
    "Bahati", "Subukia", "Rongai", "Elementaita"
  ],
  "Mombasa": [
    "Mombasa Island", "Nyali", "Bamburi", "Shanzu", "Kisauni", "Likoni",
    "Changamwe", "Jomba", "Miritini", "Tudor"
  ],
  "Kilifi": [
    "Kilifi Town", "Malindi", "Watamu", "Gedi", "Mariakani", "Kaloleni",
    "Rabai", "Chonyi", "Kauma", "Mtwapa"
  ],
  "Kwale": [
    "Kwale Town", "Ukunda", "Diani", "Msambweni", "Lunga Lunga"
  ],
  "Kisumu": [
    "Kisumu City", "Maseno", "Ahero", "Muhoroni", "Chemelil", "Katito",
    "Kombewa", "Nyando", "Kondele"
  ],
  "Siaya": [
    "Siaya Town", "Bondo", "Usenge", "Yala", "Ugunja"
  ],
  "Uasin Gishu": [
    "Eldoret", "Moiben", "Soy", "Turbo", "Ainabkoi", "Kapseret", "Kesses"
  ],
  "Trans Nzoia": [
    "Kitale", "Endebess", "Kwanza", "Saboti", "Kiminini"
  ],
  "Meru": [
    "Meru Town", "Maua", "Mikinduri", "Nkubu", "Timau", "Kianjai", "Buuri"
  ],
  "Embu": [
    "Embu Town", "Siakago", "Runyenjes", "Mbeere North", "Mbeere South"
  ],
  "Tharaka-Nithi": [
    "Chuka", "Marimanti", "Kathwana", "Mukothima"
  ],
  "Kitui": [
    "Kitui Town", "Mwingi", "Mutomo", "Ikutha", "Kyuso"
  ],
  "Makueni": [
    "Wote", "Makindu", "Mtito Andei", "Sultan Hamud", "Emali"
  ],
  "Kakamega": [
    "Kakamega Town", "Mumias", "Butere", "Khwisero", "Matungu"
  ],
  "Vihiga": [
    "Vihiga Town", "Mbale", "Luanda", "Emuhaya", "Hamisi"
  ],
  "Bungoma": [
    "Bungoma Town", "Webuye", "Kimilili", "Sirisia", "Kanduyi"
  ],
  "Busia": [
    "Busia Town", "Malaba", "Funyula", "Nambale", "Teso North"
  ]
};

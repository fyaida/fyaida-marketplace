import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "./useAuth";

export function useLoginRedirect() {
  const { user, isLoading } = useAuth();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!isLoading && user && user.role) {
      // Redirect admin and advertiser users to dashboard after login
      if (user.role === 'admin' || user.role === 'advertiser') {
        setLocation("/dashboard");
      }
    }
  }, [user, isLoading, setLocation]);
}
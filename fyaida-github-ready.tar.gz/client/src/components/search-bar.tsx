import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";
import { PROPERTY_TYPES, KENYAN_COUNTIES } from "@/lib/constants";

interface SearchBarProps {
  onSearch: (filters: SearchFilters) => void;
  type?: "properties" | "cars";
}

export interface SearchFilters {
  propertyType?: string;
  county?: string;
  location?: string;
  priceRange?: string;
  search?: string;
}

export function SearchBar({ onSearch, type = "properties" }: SearchBarProps) {
  const [filters, setFilters] = useState<SearchFilters>({});

  const handleSearch = () => {
    onSearch(filters);
  };

  const handleFilterChange = (key: keyof SearchFilters, value: string) => {
    const newFilters = { ...filters, [key]: value || undefined };
    setFilters(newFilters);
  };

  return (
    <section className="gradient-hero text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Find Your Perfect {type === "properties" ? "Property" : "Car"}
          </h1>
          <p className="text-xl opacity-90">
            Browse thousands of {type} in Kenya
          </p>
        </div>

        <div className="search-form rounded-xl shadow-lg p-6 max-w-4xl mx-auto bg-white">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <select 
                className="w-full h-12 px-3 py-2 text-base border-2 border-gray-300 rounded-lg bg-white text-gray-800 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 appearance-none cursor-pointer shadow-sm"
                style={{
                  background: 'white',
                  backgroundImage: `url("data:image/svg+xml;charset=US-ASCII,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 4 5'><path fill='%23666' d='M2 0L0 2h4zm0 5L0 3h4z'/></svg>")`,
                  backgroundRepeat: 'no-repeat',
                  backgroundPosition: 'right 12px center',
                  backgroundSize: '12px',
                  paddingRight: '40px'
                }}
                onChange={(e) => handleFilterChange("propertyType", e.target.value)}
                defaultValue=""
              >
                <option value="" disabled>
                  {type === "properties" ? "Property Type" : "Car Make"}
                </option>
                {type === "properties" ? (
                  <>
                    {PROPERTY_TYPES.map((propType) => (
                      <option key={propType.value} value={propType.value}>
                        {propType.label}
                      </option>
                    ))}
                    <option value="car">Cars</option>
                  </>
                ) : (
                  <>
                    <option value="Toyota">Toyota</option>
                    <option value="Honda">Honda</option>
                    <option value="Nissan">Nissan</option>
                    <option value="Mercedes-Benz">Mercedes-Benz</option>
                  </>
                )}
              </select>
            </div>

            <div>
              <select 
                className="w-full h-12 px-3 py-2 text-base border-2 border-gray-300 rounded-lg bg-white text-gray-800 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 appearance-none cursor-pointer shadow-sm"
                style={{
                  background: 'white',
                  backgroundImage: `url("data:image/svg+xml;charset=US-ASCII,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 4 5'><path fill='%23666' d='M2 0L0 2h4zm0 5L0 3h4z'/></svg>")`,
                  backgroundRepeat: 'no-repeat',
                  backgroundPosition: 'right 12px center',
                  backgroundSize: '12px',
                  paddingRight: '40px'
                }}
                onChange={(e) => handleFilterChange("location", e.target.value)}
                defaultValue=""
              >
                <option value="" disabled>Location</option>
                {KENYAN_COUNTIES.slice(0, 10).map((county) => (
                  <option key={county} value={county}>
                    {county}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <select 
                className="w-full h-12 px-3 py-2 text-base border-2 border-gray-300 rounded-lg bg-white text-gray-800 focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 appearance-none cursor-pointer shadow-sm"
                style={{
                  background: 'white',
                  backgroundImage: `url("data:image/svg+xml;charset=US-ASCII,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 4 5'><path fill='%23666' d='M2 0L0 2h4zm0 5L0 3h4z'/></svg>")`,
                  backgroundRepeat: 'no-repeat',
                  backgroundPosition: 'right 12px center',
                  backgroundSize: '12px',
                  paddingRight: '40px'
                }}
                onChange={(e) => handleFilterChange("priceRange", e.target.value)}
                defaultValue=""
              >
                <option value="" disabled>Price Range</option>
                <option value="0-1000000">Under KSh 1M</option>
                <option value="1000000-5000000">KSh 1M - 5M</option>
                <option value="5000000-10000000">KSh 5M - 10M</option>
                <option value="10000000-">Above KSh 10M</option>
              </select>
            </div>

            <div>
              <Button 
                onClick={handleSearch}
                className="w-full h-12 bg-blue-600 text-white hover:bg-blue-700 rounded-lg font-semibold text-base shadow-md hover:shadow-lg transition-all duration-200"
              >
                <Search className="h-5 w-5 mr-2" />
                Search
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

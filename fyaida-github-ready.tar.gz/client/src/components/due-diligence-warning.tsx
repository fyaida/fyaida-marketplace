import { AlertTriangle, Eye, FileText, Shield, Phone } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";

export function DueDiligenceWarning() {
  const [, setLocation] = useLocation();

  return (
    <Card className="border-red-200 bg-red-50 mb-6">
      <CardContent className="p-4">
        <div className="flex items-start space-x-3">
          <AlertTriangle className="h-6 w-6 text-red-600 flex-shrink-0 mt-0.5" />
          <div className="flex-1">
            <h3 className="font-semibold text-red-800 mb-2">
              ⚠️ MANDATORY DUE DILIGENCE REQUIRED
            </h3>
            <p className="text-red-700 text-sm mb-3">
              Before committing to any property transaction, you MUST conduct thorough verification:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm text-red-700 mb-4">
              <div className="flex items-center space-x-2">
                <Eye className="h-4 w-4 flex-shrink-0" />
                <span>Visit and inspect the property personally</span>
              </div>
              <div className="flex items-center space-x-2">
                <FileText className="h-4 w-4 flex-shrink-0" />
                <span>Verify all legal documents and ownership</span>
              </div>
              <div className="flex items-center space-x-2">
                <Shield className="h-4 w-4 flex-shrink-0" />
                <span>Meet the advertiser in person</span>
              </div>
              <div className="flex items-center space-x-2">
                <Phone className="h-4 w-4 flex-shrink-0" />
                <span>Engage qualified professionals (lawyers, surveyors)</span>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setLocation('/terms')}
                className="text-red-700 border-red-300 hover:bg-red-100"
              >
                Read Full Terms & Safety Guidelines
              </Button>
              <span className="text-xs text-red-600 self-center">
                Your safety and investment protection depend on proper verification
              </span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
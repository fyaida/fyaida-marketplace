import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { X, Clock, CreditCard } from "lucide-react";
import { Link } from "wouter";

interface TrialStatus {
  hasSubscription: boolean;
  trialExpired: boolean;
  daysLeft: number;
  trialNotified: boolean;
  canPost: boolean;
  isAdmin?: boolean;
}

export function TrialNotification() {
  const [dismissed, setDismissed] = useState(false);

  const { data: trialStatus } = useQuery<TrialStatus>({
    queryKey: ["/api/auth/trial-status"],
    retry: false,
    refetchInterval: 30000, // Check every 30 seconds
  });

  // Don't show notification for admins or subscribed users
  if (!trialStatus || trialStatus.hasSubscription || trialStatus.isAdmin) {
    return null;
  }

  // Don't show if dismissed
  if (dismissed) {
    return null;
  }

  // Show trial expired notification (stealth trial reveal)
  if (trialStatus.trialExpired) {
    return (
      <div className="fixed top-4 right-4 z-50 max-w-md">
        <Alert className="border-red-200 bg-red-50 text-red-800">
          <CreditCard className="h-4 w-4" />
          <div className="flex justify-between items-start">
            <div className="flex-1">
              <AlertTitle className="text-red-900 font-semibold">
                Free Trial Expired
              </AlertTitle>
              <AlertDescription className="text-red-700 mt-1">
                Your 5-day free posting trial has ended. Subscribe for KSH 300 to continue posting and access premium features for 90 days.
              </AlertDescription>
              <div className="mt-3 flex gap-2">
                <Link href="/subscription">
                  <Button size="sm" className="bg-red-600 hover:bg-red-700 text-white">
                    Subscribe Now
                  </Button>
                </Link>
                <Button 
                  size="sm" 
                  variant="outline" 
                  onClick={() => setDismissed(true)}
                  className="text-red-600 border-red-300"
                >
                  Dismiss
                </Button>
              </div>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setDismissed(true)}
              className="text-red-600 hover:text-red-800 p-1"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </Alert>
      </div>
    );
  }

  // Don't show anything during active trial (stealth mode)
  return null;
}
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Crown, AlertCircle, Star, Users, CheckCircle } from "lucide-react";
import { useLocation } from "wouter";

interface SubscriptionBannerProps {
  title?: string;
  description?: string;
  features?: string[];
  type?: "post-ad" | "open-orders" | "general";
}

export function SubscriptionBanner({ 
  title = "Subscription Required",
  description = "Access premium features with your Fyaida subscription.",
  features = [
    "Post unlimited properties and cars",
    "View and respond to open orders",
    "Social media sharing capabilities",
    "Premium customer support"
  ],
  type = "general"
}: SubscriptionBannerProps) {
  const [, setLocation] = useLocation();

  const getTypeSpecificContent = () => {
    switch (type) {
      case "post-ad":
        return {
          title: "5-Day Trial Expired",
          description: "Your free trial has ended. Subscribe to continue posting properties and cars.",
          features: [
            "Continue posting unlimited listings", 
            "Share listings on social media",
            "View and respond to open orders",
            "90 days unlimited access"
          ]
        };
      case "open-orders":
        return {
          title: "Premium Feature: Open Orders",
          description: "View property requests from buyers and connect directly with potential customers.",
          features: [
            "Access to all open property orders",
            "Respond directly to buyer requests", 
            "Get notified of new orders",
            "Share orders on social media"
          ]
        };
      default:
        return { title, description, features };
    }
  };

  const content = getTypeSpecificContent();

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            {type === "post-ad" ? "Post Advertisement" : type === "open-orders" ? "Open Orders" : "Premium Features"}
          </h1>
          <p className="text-gray-600">
            {type === "post-ad" ? "Create property and car listings" : type === "open-orders" ? "Property requests from buyers" : "Unlock all Fyaida features"}
          </p>
        </div>

        <Card className="bg-gradient-to-r from-primary/10 to-primary/20 border-primary/30 mb-8">
          <CardContent className="pt-6">
            <div className="text-center">
              <Crown className="h-16 w-16 text-primary mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-gray-900 mb-4">
                {content.title}
              </h2>
              <p className="text-gray-600 mb-6 max-w-md mx-auto">
                {content.description}
              </p>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-8 max-w-2xl mx-auto">
                {content.features.map((feature, index) => (
                  <div key={index} className="flex items-center justify-start text-sm text-gray-700 bg-white/60 rounded-lg p-3">
                    <CheckCircle className="h-5 w-5 mr-3 text-green-600 flex-shrink-0" />
                    <span>{feature}</span>
                  </div>
                ))}
              </div>

              <div className="bg-white/80 rounded-lg p-6 mb-6 max-w-md mx-auto">
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">KSH 300</div>
                  <div className="text-sm text-gray-600 mb-2">One-time payment</div>
                  <div className="text-sm font-medium text-gray-900">90 Days Unlimited Access</div>
                </div>
                <div className="flex items-center justify-center mt-4 space-x-4 text-xs text-gray-500">
                  <div className="flex items-center">
                    <Star className="h-3 w-3 mr-1" />
                    <span>Premium Support</span>
                  </div>
                  <div className="flex items-center">
                    <Users className="h-3 w-3 mr-1" />
                    <span>M-Pesa Payment</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <Button 
                  onClick={() => setLocation('/subscription')}
                  size="lg"
                  className="w-full max-w-xs mx-auto bg-primary hover:bg-primary/90 text-white"
                >
                  Subscribe Now - KSH 300
                </Button>
                
                <div className="text-xs text-gray-500 max-w-sm mx-auto">
                  Pay via M-Pesa (Till: 3511028) • Instant activation • Cancel anytime
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
          <div className="flex items-start">
            <AlertCircle className="h-5 w-5 text-yellow-600 mr-3 mt-0.5" />
            <div className="text-sm">
              <p className="text-yellow-800 font-medium mb-1">Need Help?</p>
              <p className="text-yellow-700">
                Contact us via WhatsApp: <strong>0722869901</strong> or visit our office at Moi Avenue, Nairobi.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
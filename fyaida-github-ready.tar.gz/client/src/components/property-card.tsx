import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Bed, Bath, Car, Calendar, ArrowRight, Phone, MessageCircle } from "lucide-react";
import type { Property, User } from "@shared/schema";

interface PropertyCardProps {
  property: Property & { user?: { fullName: string; phoneNumber: string; } };
  onViewDetails?: (id: number) => void;
}

export function PropertyCard({ property, onViewDetails }: PropertyCardProps) {
  const formatPrice = (price: string) => {
    const numPrice = parseFloat(price);
    if (numPrice >= 1000000) {
      return `KSh ${(numPrice / 1000000).toFixed(1)}M`;
    }
    return `KSh ${numPrice.toLocaleString()}`;
  };

  const formatPhone = (phone: string) => {
    if (phone.startsWith('0')) {
      return '+254' + phone.substring(1);
    }
    if (phone.startsWith('254')) {
      return '+' + phone;
    }
    if (!phone.startsWith('+')) {
      return '+254' + phone;
    }
    return phone;
  };

  const makeCall = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (property.user?.phoneNumber) {
      window.location.href = `tel:${formatPhone(property.user.phoneNumber)}`;
    }
  };

  const sendWhatsApp = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (property.user?.phoneNumber) {
      const message = `Hi! I'm interested in your property: "${property.title}"\n\nPrice: ${formatPrice(property.price)}\nLocation: ${property.location}\n\nCan you provide more details?\n\nFrom Fyaida.com`;
      const whatsappUrl = `https://wa.me/${formatPhone(property.user.phoneNumber).replace('+', '')}?text=${encodeURIComponent(message)}`;
      window.open(whatsappUrl, '_blank');
    }
  };

  const getListingTypeColor = (type: string) => {
    switch (type) {
      case "sale":
        return "bg-secondary text-white";
      case "rent":
        return "bg-accent text-white";
      case "lease":
        return "bg-purple-500 text-white";
      default:
        return "bg-gray-500 text-white";
    }
  };

  const getListingTypeLabel = (type: string) => {
    switch (type) {
      case "sale":
        return "For Sale";
      case "rent":
        return "For Rent";
      case "lease":
        return "For Lease";
      default:
        return type;
    }
  };

  const primaryImage = property.images && property.images.length > 0 
    ? property.images[0] 
    : "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600";

  return (
    <Card className="property-card-hover overflow-hidden border">
      <div className="relative">
        <img
          src={primaryImage}
          alt={property.title}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-4 left-4">
          <Badge className={`${getListingTypeColor(property.listingType)} text-xs font-medium`}>
            {getListingTypeLabel(property.listingType)}
          </Badge>
        </div>
        <div className="absolute top-4 right-4">
          <span className="bg-white/90 px-2 py-1 rounded text-xl font-bold text-primary">
            {formatPrice(property.price)}
          </span>
        </div>
      </div>

      <CardContent className="p-4">
        <div className="mb-2">
          <h3 className="font-semibold text-gray-900 mb-2">{property.title}</h3>
          <p className="text-gray-600 text-sm mb-3 flex items-center">
            <MapPin className="h-4 w-4 mr-1" />
            {property.location}
          </p>
        </div>

        {property.type === "house" && (
          <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
            {property.bedrooms && (
              <span className="flex items-center">
                <Bed className="h-4 w-4 mr-1" />
                {property.bedrooms} Bedrooms
              </span>
            )}
            {property.bathrooms && (
              <span className="flex items-center">
                <Bath className="h-4 w-4 mr-1" />
                {property.bathrooms} Bathrooms
              </span>
            )}
            {property.parking && (
              <span className="flex items-center">
                <Car className="h-4 w-4 mr-1" />
                {property.parking} Parking
              </span>
            )}
          </div>
        )}

        {property.type === "land" && property.size && (
          <div className="flex items-center text-sm text-gray-600 mb-3">
            <span className="flex items-center">
              <svg className="h-4 w-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4h16v16H4V4z" />
              </svg>
              {property.size}
            </span>
          </div>
        )}

        <div className="space-y-3">
          {/* Contact Buttons */}
          {property.user?.phoneNumber && (
            <div className="grid grid-cols-2 gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={makeCall}
                className="text-blue-600 border-blue-300 hover:bg-blue-50"
              >
                <Phone className="h-3 w-3 mr-1" />
                Call
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={sendWhatsApp}
                className="text-green-600 border-green-300 hover:bg-green-50"
              >
                <MessageCircle className="h-3 w-3 mr-1" />
                WhatsApp
              </Button>
            </div>
          )}
          
          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-500">
              <Calendar className="h-3 w-3 inline mr-1" />
              Posted {new Date(property.createdAt!).toLocaleDateString()}
            </span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onViewDetails?.(property.id)}
              className="text-primary hover:text-primary/80"
            >
              View Details
              <ArrowRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

import { Button } from "@/components/ui/button";
import { Share2, MessageCircle, Mail, Lock } from "lucide-react";
import { FaFacebook, FaTwitter, FaWhatsapp, FaLinkedin, FaTelegram } from "react-icons/fa";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

interface SocialShareProps {
  title: string;
  description: string;
  url?: string;
  imageUrl?: string;
  type?: "property" | "car" | "order" | "app";
}

export function SocialShare({ title, description, url, imageUrl, type = "property" }: SocialShareProps) {
  const { toast } = useToast();
  
  // Check user subscription status
  const { data: user } = useQuery({
    queryKey: ["/api/auth/me"],
    retry: false,
  });

  const shareUrl = url || window.location.href;
  const shareText = `${title}\n\n${description}\n\nView on Fyaida Marketplace: ${shareUrl}`;
  const encodedText = encodeURIComponent(shareText);
  const encodedUrl = encodeURIComponent(shareUrl);
  const encodedTitle = encodeURIComponent(title);
  const encodedDescription = encodeURIComponent(description);

  const shareLinks = {
    whatsapp: `https://wa.me/?text=${encodedText}`,
    facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}&quote=${encodedTitle}`,
    twitter: `https://twitter.com/intent/tweet?text=${encodedTitle}&url=${encodedUrl}`,
    linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`,
    telegram: `https://t.me/share/url?url=${encodedUrl}&text=${encodedTitle}`,
    email: `mailto:?subject=${encodedTitle}&body=${encodedDescription}%0A%0A${encodedUrl}`,
  };

  const openShare = (platform: keyof typeof shareLinks) => {
    // Check if user has subscription or is admin
    if (!user || (!user.isSubscribed && user.role !== 'admin')) {
      toast({
        title: "Subscription Required",
        description: "Social media sharing requires an active subscription. Subscribe for KSH 300 to access premium features.",
        variant: "destructive",
      });
      return;
    }
    
    window.open(shareLinks[platform], '_blank', 'width=600,height=400');
  };

  return (
    <div className="flex flex-wrap gap-2">
      <Button
        size="sm"
        variant="outline"
        onClick={() => openShare('whatsapp')}
        className="text-green-600 border-green-600 hover:bg-green-50"
      >
        <FaWhatsapp className="h-4 w-4 mr-1" />
        WhatsApp
      </Button>
      
      <Button
        size="sm"
        variant="outline"
        onClick={() => openShare('facebook')}
        className="text-blue-600 border-blue-600 hover:bg-blue-50"
      >
        <FaFacebook className="h-4 w-4 mr-1" />
        Facebook
      </Button>
      
      <Button
        size="sm"
        variant="outline"
        onClick={() => openShare('twitter')}
        className="text-sky-500 border-sky-500 hover:bg-sky-50"
      >
        <FaTwitter className="h-4 w-4 mr-1" />
        Twitter
      </Button>
      
      <Button
        size="sm"
        variant="outline"
        onClick={() => openShare('linkedin')}
        className="text-blue-800 border-blue-800 hover:bg-blue-50"
      >
        <FaLinkedin className="h-4 w-4 mr-1" />
        LinkedIn
      </Button>
      
      <Button
        size="sm"
        variant="outline"
        onClick={() => openShare('telegram')}
        className="text-blue-400 border-blue-400 hover:bg-blue-50"
      >
        <FaTelegram className="h-4 w-4 mr-1" />
        Telegram
      </Button>
      
      <Button
        size="sm"
        variant="outline"
        onClick={() => openShare('email')}
        className="text-gray-600 border-gray-600 hover:bg-gray-50"
      >
        <Mail className="h-4 w-4 mr-1" />
        Email
      </Button>
    </div>
  );
}
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SimpleContactAdvertiser } from "@/components/simple-contact-advertiser";
import { DueDiligenceWarning } from "@/components/due-diligence-warning";
import { MapPin, Bed, Bath, Car, Calendar, Share2, Heart, ChevronLeft, ChevronRight, X } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Property } from "@shared/schema";

interface SimplePropertyDetailModalProps {
  property: Property & { user?: { fullName: string; phoneNumber: string } };
  onClose: () => void;
}

export function SimplePropertyDetailModal({ property, onClose }: SimplePropertyDetailModalProps) {
  const { toast } = useToast();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const formatPrice = (price: string) => {
    const numPrice = parseFloat(price);
    if (numPrice >= 1000000) {
      return `KSh ${(numPrice / 1000000).toFixed(1)}M`;
    } else if (numPrice >= 1000) {
      return `KSh ${(numPrice / 1000).toFixed(0)}K`;
    }
    return `KSh ${numPrice.toLocaleString()}`;
  };

  const handleShare = async () => {
    const shareText = `Check out this ${property.type} in ${property.location}: ${property.title} - ${formatPrice(property.price)}`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: property.title,
          text: shareText,
          url: window.location.href,
        });
      } catch (err) {
        // User cancelled sharing
      }
    } else {
      // Fallback to clipboard
      await navigator.clipboard.writeText(shareText);
      toast({
        title: "Copied to clipboard",
        description: "Property details copied to clipboard",
      });
    }
  };

  const nextImage = () => {
    if (property.images && property.images.length > 1) {
      setCurrentImageIndex((prev) => (prev + 1) % property.images!.length);
    }
  };

  const prevImage = () => {
    if (property.images && property.images.length > 1) {
      setCurrentImageIndex((prev) => (prev - 1 + property.images!.length) % property.images!.length);
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto p-0">
        <div className="relative">
          {/* Close Button */}
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="absolute top-4 right-4 z-10 bg-white/80 hover:bg-white"
          >
            <X className="h-4 w-4" />
          </Button>

          {/* Image Gallery */}
          <div className="relative h-64 md:h-80 bg-gray-200">
            {property.images && property.images.length > 0 ? (
              <>
                <img
                  src={property.images[currentImageIndex]}
                  alt={property.title}
                  className="w-full h-full object-cover"
                />
                {property.images.length > 1 && (
                  <>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={prevImage}
                      className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white"
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={nextImage}
                      className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-white/80 hover:bg-white"
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                    <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                      {property.images.map((_, index) => (
                        <button
                          key={index}
                          onClick={() => setCurrentImageIndex(index)}
                          className={`w-2 h-2 rounded-full ${
                            index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                          }`}
                        />
                      ))}
                    </div>
                  </>
                )}
              </>
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-gray-100">
                <span className="text-gray-500">No images available</span>
              </div>
            )}
          </div>

          {/* Content */}
          <div className="p-6">
            {/* Due Diligence Warning */}
            <DueDiligenceWarning />
            
            <DialogHeader className="mb-4">
              <div className="flex justify-between items-start mb-2">
                <DialogTitle className="text-2xl font-bold text-gray-900">
                  {property.title}
                </DialogTitle>
                <div className="flex space-x-2">
                  <Button variant="ghost" size="sm" onClick={handleShare}>
                    <Share2 className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm">
                    <Heart className="h-4 w-4" />
                  </Button>
                </div>
              </div>
              
              <div className="flex items-center text-gray-600 mb-2">
                <MapPin className="h-4 w-4 mr-1" />
                {property.location}
              </div>
              
              <div className="text-3xl font-bold text-primary mb-4">
                {formatPrice(property.price)}
              </div>
            </DialogHeader>

            {/* Property Details */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <div className="flex items-center space-x-2">
                <Badge variant="secondary">{property.type}</Badge>
              </div>
              <div className="flex items-center space-x-2">
                <Badge variant="outline">{property.listingType}</Badge>
              </div>
              {property.bedrooms && (
                <div className="flex items-center space-x-2">
                  <Bed className="h-4 w-4 text-gray-600" />
                  <span className="text-sm text-gray-600">{property.bedrooms} beds</span>
                </div>
              )}
              {property.bathrooms && (
                <div className="flex items-center space-x-2">
                  <Bath className="h-4 w-4 text-gray-600" />
                  <span className="text-sm text-gray-600">{property.bathrooms} baths</span>
                </div>
              )}
            </div>

            {/* Description */}
            <div className="mb-6">
              <h3 className="text-lg font-semibold mb-2">Description</h3>
              <p className="text-gray-600 leading-relaxed">{property.description}</p>
            </div>

            {/* Amenities */}
            {property.amenities && property.amenities.length > 0 && (
              <div className="mb-6">
                <h3 className="text-lg font-semibold mb-2">Amenities</h3>
                <div className="flex flex-wrap gap-2">
                  {property.amenities.map((amenity, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {amenity}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Contact Section */}
            {property.user && (
              <div className="border-t pt-6">
                <SimpleContactAdvertiser
                  advertiser={property.user}
                  listingTitle={property.title}
                  listingType="property"
                />
              </div>
            )}

            {/* Posted Date */}
            <div className="flex items-center text-sm text-gray-500 mt-4">
              <Calendar className="h-4 w-4 mr-1" />
              Posted {new Date(property.createdAt!).toLocaleDateString()}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
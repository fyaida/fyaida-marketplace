import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Home, Building, Car, ClipboardList, Plus, Menu, User, Smartphone } from "lucide-react";

const mobileNavItems = [
  { href: "/", label: "Home", icon: Home },
  { href: "/properties", label: "Properties", icon: Building },
  { href: "/cars", label: "Cars", icon: Car },
  { href: "/open-orders", label: "Orders", icon: ClipboardList },
  { href: "/post-ad", label: "Post Ad", icon: Plus },
  { href: "/dashboard", label: "Account", icon: User },
  { href: "/mobile-app", label: "Mobile App", icon: Smartphone },
];

export function MobileNavigation() {
  const [location] = useLocation();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      {/* Mobile Bottom Navigation - Always Visible */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-40">
        <div className="grid grid-cols-5 px-1">
          {mobileNavItems.slice(0, 4).map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href;
            return (
              <Link key={item.href} href={item.href}>
                <Button
                  variant="ghost"
                  className={`w-full h-14 flex flex-col items-center justify-center gap-1 rounded-none ${
                    isActive ? 'text-green-600 bg-green-50' : 'text-gray-600'
                  }`}
                >
                  <Icon className="h-5 w-5" />
                  <span className="text-xs font-medium">{item.label}</span>
                </Button>
              </Link>
            );
          })}
          
          {/* Menu Button */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                className="w-full h-14 flex flex-col items-center justify-center gap-1 rounded-none text-gray-600"
              >
                <Menu className="h-5 w-5" />
                <span className="text-xs font-medium">More</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="bottom" className="rounded-t-2xl">
              <div className="grid grid-cols-2 gap-4 py-6">
                {mobileNavItems.slice(4).map((item) => {
                  const Icon = item.icon;
                  const isActive = location === item.href;
                  return (
                    <Link key={item.href} href={item.href}>
                      <Button
                        variant="outline"
                        className={`w-full h-16 flex flex-col items-center justify-center gap-2 ${
                          isActive ? 'border-green-600 text-green-600 bg-green-50' : ''
                        }`}
                        onClick={() => setIsOpen(false)}
                      >
                        <Icon className="h-6 w-6" />
                        <span className="text-sm font-medium">{item.label}</span>
                      </Button>
                    </Link>
                  );
                })}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      {/* Spacer for bottom navigation */}
      <div className="md:hidden h-14" />
    </>
  );
}
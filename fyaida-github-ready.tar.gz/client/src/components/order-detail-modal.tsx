import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { SimpleContactAdvertiser } from "@/components/simple-contact-advertiser";
import { MapPin, Calendar, DollarSign, X, ImageIcon, Phone, MessageCircle, ExternalLink, Crown } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import type { OpenOrder } from "@shared/schema";

interface OrderDetailModalProps {
  order: OpenOrder & { user?: { fullName: string; phoneNumber: string } };
  onClose: () => void;
}

export function OrderDetailModal({ order, onClose }: OrderDetailModalProps) {
  const { toast } = useToast();
  
  // Check if user is authenticated and subscribed
  const { data: user } = useQuery({
    queryKey: ["/api/auth/me"],
    retry: false,
  });

  const formatBudget = (budget: string) => {
    const numBudget = parseFloat(budget);
    if (numBudget >= 1000000) {
      return `KSh ${(numBudget / 1000000).toFixed(1)}M`;
    } else if (numBudget >= 1000) {
      return `KSh ${(numBudget / 1000).toFixed(0)}K`;
    }
    return `KSh ${numBudget.toLocaleString()}`;
  };

  const makeCall = () => {
    if (order.user?.phoneNumber) {
      const formattedPhone = order.user.phoneNumber.startsWith('+254') 
        ? order.user.phoneNumber 
        : `+254${order.user.phoneNumber.replace(/^0/, '')}`;
      window.location.href = `tel:${formattedPhone}`;
    }
  };

  const sendWhatsApp = () => {
    if (order.user?.phoneNumber) {
      const formattedPhone = order.user.phoneNumber.startsWith('+254') 
        ? order.user.phoneNumber.substring(1)
        : `254${order.user.phoneNumber.replace(/^0/, '')}`;
      
      const message = `Hi! I saw your order request: ${order.title}. Budget: ${formatBudget(order.budget)}. Location: ${order.location}. I can help you with this request.`;
      
      window.open(`https://wa.me/${formattedPhone}?text=${encodeURIComponent(message)}`, '_blank');
    }
  };

  return (
    <Dialog open={true} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader className="relative">
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="absolute -top-2 -right-2"
          >
            <X className="h-4 w-4" />
          </Button>
          
          <DialogTitle className="text-xl font-bold text-gray-900 pr-8">
            {order.title}
          </DialogTitle>
          
          <div className="flex items-center text-gray-600 mt-2">
            <MapPin className="h-4 w-4 mr-1" />
            {order.location}
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Budget and Type */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <DollarSign className="h-5 w-5 text-green-600" />
              <span className="text-2xl font-bold text-green-600">
                {formatBudget(order.budget)}
              </span>
            </div>
            <Badge variant="secondary" className="text-sm">
              {order.propertyType}
            </Badge>
          </div>

          {/* Description */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-2">Request Details</h3>
            <p className="text-gray-600 leading-relaxed">{order.description}</p>
          </div>

          {/* Reference Image */}
          {order.referenceImageUrl && (
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Reference Image</h3>
              <div className="relative">
                <img
                  src={order.referenceImageUrl}
                  alt="Reference"
                  className="w-full max-w-sm h-48 object-cover rounded-lg border"
                />
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => window.open(order.referenceImageUrl, '_blank')}
                  className="absolute top-2 right-2 bg-white/80 hover:bg-white"
                >
                  <ExternalLink className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}

          {/* Contact Information */}
          <div className="border-t pt-6">
            <h3 className="font-semibold text-gray-900 mb-4">Contact Requester</h3>
            {order.user ? (
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <p className="font-medium text-gray-900">{order.user.fullName}</p>
                    <p className="text-sm text-gray-600">{order.user.phoneNumber}</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-3">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={makeCall}
                    className="text-blue-600 border-blue-300 hover:bg-blue-50"
                  >
                    <Phone className="h-4 w-4 mr-2" />
                    Call Now
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={sendWhatsApp}
                    className="text-green-600 border-green-300 hover:bg-green-50"
                  >
                    <MessageCircle className="h-4 w-4 mr-2" />
                    WhatsApp
                  </Button>
                </div>
              </div>
            ) : (
              <div className="bg-yellow-50 border border-yellow-200 p-4 rounded-lg">
                <div className="flex items-start">
                  <Crown className="h-5 w-5 text-yellow-600 mr-3 mt-0.5" />
                  <div className="flex-1">
                    <h4 className="text-sm font-medium text-yellow-800 mb-2">
                      Premium Feature - Contact Details
                    </h4>
                    <p className="text-sm text-yellow-700 mb-3">
                      Subscribe to view contact information and connect with order requesters directly.
                    </p>
                    <Button
                      size="sm"
                      onClick={() => window.location.href = '/subscription'}
                      className="bg-yellow-600 hover:bg-yellow-700 text-white"
                    >
                      <Crown className="h-4 w-4 mr-2" />
                      Subscribe for KSh 300
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Posted Date */}
          <div className="flex items-center text-sm text-gray-500 pt-4 border-t">
            <Calendar className="h-4 w-4 mr-1" />
            Posted {new Date(order.createdAt!).toLocaleDateString()}
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
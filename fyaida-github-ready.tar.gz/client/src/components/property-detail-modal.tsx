import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ContactAdvertiser } from "@/components/contact-advertiser";
import { MapPin, Bed, Bath, Car, Calendar, Share2, Heart, ChevronLeft, ChevronRight } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Property, User } from "@shared/schema";

interface PropertyDetailModalProps {
  propertyId: number | null;
  isOpen: boolean;
  onClose: () => void;
}

export function PropertyDetailModal({ propertyId, isOpen, onClose }: PropertyDetailModalProps) {
  const { toast } = useToast();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);

  const { data: property, isLoading } = useQuery<Property & { user: User }>({
    queryKey: ["/api/properties", propertyId],
    queryFn: () => fetch(`/api/properties/${propertyId}`).then(res => res.json()),
    enabled: !!propertyId && isOpen,
  });

  const formatPrice = (price: string) => {
    const numPrice = parseFloat(price);
    if (numPrice >= 1000000) {
      return `KSh ${(numPrice / 1000000).toFixed(1)}M`;
    }
    return `KSh ${numPrice.toLocaleString()}`;
  };

  const getListingTypeColor = (type: string) => {
    switch (type) {
      case "sale":
        return "bg-green-500 text-white";
      case "rent":
        return "bg-blue-500 text-white";
      case "lease":
        return "bg-purple-500 text-white";
      default:
        return "bg-gray-500 text-white";
    }
  };

  const getListingTypeLabel = (type: string) => {
    switch (type) {
      case "sale":
        return "For Sale";
      case "rent":
        return "For Rent";
      case "lease":
        return "For Lease";
      default:
        return type;
    }
  };

  const shareProperty = () => {
    const text = `Check out this ${property?.propertyType} in ${property?.location}!\n\n${property?.title}\n\nPrice: ${formatPrice(property?.price || "0")}\n\nView on Fyaida: ${window.location.origin}/properties`;
    
    if (navigator.share) {
      navigator.share({
        title: property?.title,
        text: text,
        url: window.location.href,
      });
    } else {
      navigator.clipboard.writeText(text).then(() => {
        toast({
          title: "Link Copied",
          description: "Property details copied to clipboard!",
        });
      });
    }
  };

  const nextImage = () => {
    if (property?.images && property.images.length > 1) {
      setCurrentImageIndex((prev) => 
        prev === property.images.length - 1 ? 0 : prev + 1
      );
    }
  };

  const previousImage = () => {
    if (property?.images && property.images.length > 1) {
      setCurrentImageIndex((prev) => 
        prev === 0 ? property.images.length - 1 : prev - 1
      );
    }
  };

  if (!property && !isLoading) return null;

  const images = property?.images && property.images.length > 0 
    ? property.images 
    : ["https://images.unsplash.com/photo-1564013799919-ab600027ffc6?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        {isLoading ? (
          <div className="flex items-center justify-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-green-600"></div>
          </div>
        ) : property ? (
          <div className="space-y-6">
            <DialogHeader>
              <DialogTitle className="text-2xl font-bold">{property.title}</DialogTitle>
            </DialogHeader>

            {/* Image Gallery */}
            <div className="relative">
              <div className="relative h-64 md:h-80 rounded-lg overflow-hidden">
                <img
                  src={images[currentImageIndex]}
                  alt={property.title}
                  className="w-full h-full object-cover"
                />
                
                {/* Image Navigation */}
                {images.length > 1 && (
                  <>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-black/20 hover:bg-black/40 text-white"
                      onClick={previousImage}
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-black/20 hover:bg-black/40 text-white"
                      onClick={nextImage}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                    
                    {/* Image Dots */}
                    <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                      {images.map((_, index) => (
                        <button
                          key={index}
                          className={`w-2 h-2 rounded-full ${
                            index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                          }`}
                          onClick={() => setCurrentImageIndex(index)}
                        />
                      ))}
                    </div>
                  </>
                )}

                {/* Badges */}
                <div className="absolute top-4 left-4">
                  <Badge className={`${getListingTypeColor(property.listingType)} text-sm font-medium`}>
                    {getListingTypeLabel(property.listingType)}
                  </Badge>
                </div>
                <div className="absolute top-4 right-4">
                  <span className="bg-white/90 px-3 py-2 rounded-lg text-2xl font-bold text-green-600">
                    {formatPrice(property.price)}
                  </span>
                </div>

                {/* Action Buttons */}
                <div className="absolute bottom-4 right-4 flex space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="bg-black/20 hover:bg-black/40 text-white"
                    onClick={shareProperty}
                  >
                    <Share2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </div>

            {/* Property Details */}
            <div className="grid md:grid-cols-2 gap-6">
              {/* Left Column - Property Info */}
              <div className="space-y-4">
                <div>
                  <h3 className="text-lg font-semibold mb-2">Property Details</h3>
                  <div className="space-y-2 text-sm">
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-2 text-gray-500" />
                      <span>{property.location}</span>
                    </div>
                    <div className="grid grid-cols-2 gap-4 mt-4">
                      <div>
                        <span className="font-medium">Type:</span>
                        <p className="text-gray-600 capitalize">{property.propertyType}</p>
                      </div>
                      <div>
                        <span className="font-medium">Category:</span>
                        <p className="text-gray-600 capitalize">{property.type}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Property Features */}
                {property.type === "house" && (
                  <div>
                    <h4 className="font-semibold mb-2">Features</h4>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      {property.bedrooms && (
                        <div className="flex items-center">
                          <Bed className="h-4 w-4 mr-2 text-gray-500" />
                          <span>{property.bedrooms} Bedrooms</span>
                        </div>
                      )}
                      {property.bathrooms && (
                        <div className="flex items-center">
                          <Bath className="h-4 w-4 mr-2 text-gray-500" />
                          <span>{property.bathrooms} Bathrooms</span>
                        </div>
                      )}
                      {property.parking && (
                        <div className="flex items-center">
                          <Car className="h-4 w-4 mr-2 text-gray-500" />
                          <span>{property.parking} Parking</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {property.type === "land" && property.size && (
                  <div>
                    <h4 className="font-semibold mb-2">Land Details</h4>
                    <div className="text-sm">
                      <div className="flex items-center">
                        <svg className="h-4 w-4 mr-2 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4h16v16H4V4z" />
                        </svg>
                        <span>Size: {property.size}</span>
                      </div>
                    </div>
                  </div>
                )}

                {/* Description */}
                {property.description && (
                  <div>
                    <h4 className="font-semibold mb-2">Description</h4>
                    <p className="text-gray-600 text-sm leading-relaxed">{property.description}</p>
                  </div>
                )}

                {/* Posted Date */}
                <div className="text-xs text-gray-500 flex items-center">
                  <Calendar className="h-3 w-3 mr-1" />
                  Posted {new Date(property.createdAt!).toLocaleDateString()}
                </div>
              </div>

              {/* Right Column - Contact */}
              <div>
                {property.user ? (
                  <ContactAdvertiser 
                    listing={property}
                    advertiser={{
                      ...property.user,
                      name: property.user.fullName,
                      phone: property.user.phoneNumber
                    }}
                    listingType="property"
                  />
                ) : (
                  <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 text-center">
                    <p className="text-gray-600">Contact information not available</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}
import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Plus, X, Upload, ImageIcon, Camera } from "lucide-react";

interface ImageGalleryPickerProps {
  images: string[];
  onImagesChange: (images: string[]) => void;
  maxImages?: number;
  label?: string;
  allowUrlInput?: boolean;
}

export function ImageGalleryPicker({ 
  images, 
  onImagesChange, 
  maxImages = 10,
  label = "Images",
  allowUrlInput = true 
}: ImageGalleryPickerProps) {
  const [newImageUrl, setNewImageUrl] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    // Convert files to URLs for preview (in production, upload to cloud storage)
    Array.from(files).forEach(file => {
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          if (e.target?.result && images.length < maxImages) {
            const newImages = [...images, e.target.result as string];
            onImagesChange(newImages);
          }
        };
        reader.readAsDataURL(file);
      }
    });

    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleGalleryClick = () => {
    fileInputRef.current?.click();
  };

  const addImageUrl = () => {
    if (newImageUrl.trim() && images.length < maxImages) {
      onImagesChange([...images, newImageUrl.trim()]);
      setNewImageUrl("");
    }
  };

  const removeImage = (index: number) => {
    const newImages = images.filter((_, i) => i !== index);
    onImagesChange(newImages);
  };

  const isImageLimitReached = images.length >= maxImages;

  return (
    <div className="space-y-4">
      <Label className="text-sm font-medium">{label}</Label>
      
      {/* Image Selection Buttons */}
      <div className="flex flex-wrap gap-2">
        <Button
          type="button"
          variant="outline"
          onClick={handleGalleryClick}
          disabled={isImageLimitReached}
          className="flex items-center gap-2"
        >
          <Camera className="h-4 w-4" />
          Select Photos
        </Button>

        {allowUrlInput && (
          <div className="flex gap-2 flex-1 min-w-64">
            <Input
              placeholder="Or paste image URL"
              value={newImageUrl}
              onChange={(e) => setNewImageUrl(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addImageUrl())}
              disabled={isImageLimitReached}
            />
            <Button
              type="button"
              variant="outline"
              onClick={addImageUrl}
              disabled={!newImageUrl.trim() || isImageLimitReached}
              size="sm"
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>

      {/* Hidden file input for gallery access */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        multiple
        onChange={handleFileSelect}
        className="hidden"
      />

      {/* Image limit indicator */}
      <p className="text-xs text-gray-500">
        {images.length} of {maxImages} images selected
        {isImageLimitReached && " (limit reached)"}
      </p>

      {/* Image Preview Grid */}
      {images.length > 0 && (
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {images.map((image, index) => (
            <div key={index} className="relative group">
              <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden border-2 border-gray-200 hover:border-blue-300 transition-colors">
                <img 
                  src={image} 
                  alt={`Image ${index + 1}`} 
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjQiIGhlaWdodD0iMjQiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHJlY3Qgd2lkdGg9IjI0IiBoZWlnaHQ9IjI0IiBmaWxsPSIjRjNGNEY2Ii8+CjxwYXRoIGQ9Ik04IDlIMTZWMTVIOFY5WiIgZmlsbD0iIzlDQTNBRiIvPgo8L3N2Zz4K";
                  }}
                />
              </div>
              
              {/* Remove button */}
              <Button
                type="button"
                size="sm"
                variant="destructive"
                className="absolute -top-2 -right-2 h-6 w-6 p-0 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={() => removeImage(index)}
              >
                <X className="h-3 w-3" />
              </Button>
              
              {/* Image number indicator */}
              <div className="absolute bottom-1 left-1 bg-black bg-opacity-60 text-white text-xs px-1.5 py-0.5 rounded">
                {index + 1}
              </div>
            </div>
          ))}
          
          {/* Add more button */}
          {!isImageLimitReached && (
            <button
              type="button"
              onClick={handleGalleryClick}
              className="aspect-square bg-gray-50 border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center hover:border-blue-300 hover:bg-blue-50 transition-colors group"
            >
              <Plus className="h-6 w-6 text-gray-400 group-hover:text-blue-500" />
              <span className="text-xs text-gray-500 group-hover:text-blue-500 mt-1">Add More</span>
            </button>
          )}
        </div>
      )}

      {/* Empty state */}
      {images.length === 0 && (
        <div 
          onClick={handleGalleryClick}
          className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center hover:border-blue-300 hover:bg-blue-50 transition-colors cursor-pointer group"
        >
          <ImageIcon className="h-12 w-12 text-gray-400 group-hover:text-blue-500 mx-auto mb-3" />
          <p className="text-gray-500 group-hover:text-blue-500 font-medium">Click to select images</p>
          <p className="text-xs text-gray-400 mt-1">
            Choose from your device gallery or camera
          </p>
        </div>
      )}
    </div>
  );
}
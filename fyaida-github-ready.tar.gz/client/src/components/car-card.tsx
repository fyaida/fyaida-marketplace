import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Calendar, Gauge, Settings, ArrowRight, Phone, MessageCircle } from "lucide-react";
import type { Car } from "@shared/schema";

interface CarCardProps {
  car: Car & { user?: { fullName: string; phoneNumber: string; } };
  onViewDetails?: (id: number) => void;
}

export function CarCard({ car, onViewDetails }: CarCardProps) {
  const formatPrice = (price: string) => {
    const numPrice = parseFloat(price);
    if (numPrice >= 1000000) {
      return `KSh ${(numPrice / 1000000).toFixed(1)}M`;
    }
    return `KSh ${numPrice.toLocaleString()}`;
  };

  const formatPhone = (phone: string) => {
    if (phone.startsWith('0')) {
      return '+254' + phone.substring(1);
    }
    if (phone.startsWith('254')) {
      return '+' + phone;
    }
    if (!phone.startsWith('+')) {
      return '+254' + phone;
    }
    return phone;
  };

  const makeCall = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (car.user?.phoneNumber) {
      window.location.href = `tel:${formatPhone(car.user.phoneNumber)}`;
    }
  };

  const sendWhatsApp = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (car.user?.phoneNumber) {
      const message = `Hi! I'm interested in your car: "${car.title}"\n\nPrice: ${formatPrice(car.price)}\nLocation: ${car.location}\n\nCan you provide more details?\n\nFrom Fyaida.com`;
      const whatsappUrl = `https://wa.me/${formatPhone(car.user.phoneNumber).replace('+', '')}?text=${encodeURIComponent(message)}`;
      window.open(whatsappUrl, '_blank');
    }
  };

  const getConditionColor = (condition: string) => {
    switch (condition) {
      case "excellent":
        return "bg-green-500 text-white";
      case "good":
        return "bg-blue-500 text-white";
      case "fair":
        return "bg-yellow-500 text-white";
      case "poor":
        return "bg-red-500 text-white";
      default:
        return "bg-gray-500 text-white";
    }
  };

  const primaryImage = car.images && car.images.length > 0 
    ? car.images[0] 
    : "https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600";

  return (
    <Card className="property-card-hover overflow-hidden border">
      <div className="relative">
        <img
          src={primaryImage}
          alt={car.title}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-4 left-4">
          <Badge className={`${getConditionColor(car.condition)} text-xs font-medium`}>
            {car.condition.charAt(0).toUpperCase() + car.condition.slice(1)} Condition
          </Badge>
        </div>
        <div className="absolute top-4 right-4 text-right">
          <span className="bg-white/90 px-2 py-1 rounded text-xl font-bold text-primary block">
            {formatPrice(car.price)}
          </span>
          {car.paymentMethod === "installments" && car.installmentAmount && (
            <span className="bg-accent/90 px-2 py-1 rounded text-xs text-white mt-1 block">
              or KSh {parseFloat(car.installmentAmount).toLocaleString()}/month
            </span>
          )}
        </div>
      </div>

      <CardContent className="p-4">
        <div className="mb-2">
          <h3 className="font-semibold text-gray-900 mb-2">{car.title}</h3>
          <p className="text-gray-600 text-sm mb-3 flex items-center">
            <MapPin className="h-4 w-4 mr-1" />
            {car.location}
          </p>
        </div>

        <div className="flex items-center space-x-4 text-sm text-gray-600 mb-3">
          <span className="flex items-center">
            <Calendar className="h-4 w-4 mr-1" />
            {car.year}
          </span>
          {car.mileage && (
            <span className="flex items-center">
              <Gauge className="h-4 w-4 mr-1" />
              {car.mileage.toLocaleString()} KM
            </span>
          )}
          <span className="flex items-center">
            <Settings className="h-4 w-4 mr-1" />
            {car.engineSize}
          </span>
        </div>

        <div className="space-y-3">
          {/* Contact Buttons */}
          {car.user?.phoneNumber && (
            <div className="grid grid-cols-2 gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={makeCall}
                className="text-blue-600 border-blue-300 hover:bg-blue-50"
              >
                <Phone className="h-3 w-3 mr-1" />
                Call
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={sendWhatsApp}
                className="text-green-600 border-green-300 hover:bg-green-50"
              >
                <MessageCircle className="h-3 w-3 mr-1" />
                WhatsApp
              </Button>
            </div>
          )}
          
          <div className="flex justify-between items-center">
            <span className="text-xs text-gray-500">
              <Calendar className="h-3 w-3 inline mr-1" />
              Posted {new Date(car.createdAt!).toLocaleDateString()}
            </span>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onViewDetails?.(car.id)}
              className="text-primary hover:text-primary/80"
            >
              View Details
              <ArrowRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

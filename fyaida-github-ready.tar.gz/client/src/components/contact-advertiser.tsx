import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Phone, MessageCircle, User, Clock, MapPin } from "lucide-react";
import { Property, Car, OpenOrder, User as UserType } from "@shared/schema";

interface ContactAdvertiserProps {
  listing: Property | Car | OpenOrder;
  advertiser: UserType;
  listingType: "property" | "car" | "order";
}

export function ContactAdvertiser({ listing, advertiser, listingType }: ContactAdvertiserProps) {
  const formatPhone = (phone: string) => {
    // Convert to Kenya format if needed
    if (phone.startsWith('0')) {
      return '+254' + phone.substring(1);
    }
    if (phone.startsWith('254')) {
      return '+' + phone;
    }
    if (!phone.startsWith('+')) {
      return '+254' + phone;
    }
    return phone;
  };

  const makeCall = () => {
    if (advertiser.phoneNumber) {
      window.location.href = `tel:${formatPhone(advertiser.phoneNumber)}`;
    }
  };

  const sendWhatsApp = () => {
    if (advertiser.phoneNumber) {
      const message = `Hi! I'm interested in your ${listingType} listing: "${listing.title}". 

${listingType === 'property' && 'price' in listing ? `Price: KSH ${listing.price?.toLocaleString()}` : ''}
${listingType === 'car' && 'price' in listing ? `Price: KSH ${listing.price?.toLocaleString()}` : ''}
${listingType === 'property' && 'location' in listing ? `Location: ${listing.location}` : ''}
${listingType === 'car' && 'location' in listing ? `Location: ${listing.location}` : ''}

Can you provide more details?

From Fyaida.com`;

      const whatsappUrl = `https://wa.me/${formatPhone(advertiser.phoneNumber).replace('+', '')}?text=${encodeURIComponent(message)}`;
      window.open(whatsappUrl, '_blank');
    }
  };

  const getListingDetails = () => {
    if (listingType === 'property' && 'propertyType' in listing) {
      return {
        type: listing.propertyType,
        price: 'price' in listing ? listing.price : null,
        location: 'location' in listing ? listing.location : null,
        icon: "🏠"
      };
    }
    if (listingType === 'car' && 'make' in listing) {
      return {
        type: `${listing.make} ${listing.model}`,
        price: 'price' in listing ? listing.price : null,
        location: 'location' in listing ? listing.location : null,
        icon: "🚗"
      };
    }
    return {
      type: 'Open Order',
      price: null,
      location: 'location' in listing ? listing.location : null,
      icon: "📋"
    };
  };

  const details = getListingDetails();

  if (!advertiser.phoneNumber) {
    return (
      <Card className="border-yellow-200 bg-yellow-50">
        <CardContent className="pt-4">
          <p className="text-sm text-yellow-800 text-center">
            Contact information not available for this listing
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="border-green-200 bg-green-50">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center gap-2 text-lg">
          <User className="h-5 w-5 text-green-600" />
          Contact Advertiser
        </CardTitle>
        <CardDescription>
          Get in touch with {advertiser.fullName || 'the advertiser'} about this {listingType}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Quick Contact Buttons */}
        <div className="grid grid-cols-2 gap-3">
          <Button 
            onClick={makeCall}
            className="bg-blue-600 hover:bg-blue-700 text-white"
            size="lg"
          >
            <Phone className="mr-2 h-4 w-4" />
            Call Now
          </Button>
          <Button 
            onClick={sendWhatsApp}
            className="bg-green-600 hover:bg-green-700 text-white"
            size="lg"
          >
            <MessageCircle className="mr-2 h-4 w-4" />
            WhatsApp
          </Button>
        </div>

        {/* Advertiser Info Preview */}
        <div className="bg-white rounded-lg p-3 border border-green-200">
          <div className="flex items-center justify-between mb-2">
            <span className="font-medium text-gray-900">
              {advertiser.fullName || 'Advertiser'}
            </span>
            <span className="text-sm text-gray-500">
              {formatPhone(advertiser.phoneNumber)}
            </span>
          </div>
          <div className="text-sm text-gray-600 space-y-1">
            <div className="flex items-center gap-2">
              <span>{details.icon}</span>
              <span>{details.type}</span>
            </div>
            {details.price && (
              <div className="flex items-center gap-2">
                <span>💰</span>
                <span>KSH {details.price.toLocaleString()}</span>
              </div>
            )}
            {details.location && (
              <div className="flex items-center gap-2">
                <MapPin className="h-3 w-3" />
                <span>{details.location}</span>
              </div>
            )}
          </div>
        </div>

        {/* Detailed Contact Dialog */}
        <Dialog>
          <DialogTrigger asChild>
            <Button variant="outline" className="w-full">
              View Full Contact Details
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Contact Information</DialogTitle>
              <DialogDescription>
                Reach out to the advertiser about this {listingType}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              {/* Listing Summary */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <span>{details.icon}</span>
                  {listing.title}
                </h4>
                <div className="text-sm text-gray-600 space-y-1">
                  <p><strong>Type:</strong> {details.type}</p>
                  {details.price && <p><strong>Price:</strong> KSH {details.price.toLocaleString()}</p>}
                  {details.location && <p><strong>Location:</strong> {details.location}</p>}
                </div>
              </div>

              {/* Contact Options */}
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 border rounded-lg">
                  <div>
                    <p className="font-medium">{advertiser.fullName || 'Advertiser'}</p>
                    <p className="text-sm text-gray-600">{formatPhone(advertiser.phoneNumber)}</p>
                  </div>
                  <div className="space-x-2">
                    <Button size="sm" onClick={makeCall} variant="outline">
                      <Phone className="h-4 w-4" />
                    </Button>
                    <Button size="sm" onClick={sendWhatsApp} className="bg-green-600 hover:bg-green-700 text-white">
                      <MessageCircle className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>

              {/* Tips */}
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                <h5 className="font-medium text-blue-900 mb-2 flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  Contact Tips
                </h5>
                <ul className="text-sm text-blue-800 space-y-1">
                  <li>• Best to call during business hours (8 AM - 8 PM)</li>
                  <li>• WhatsApp often gets faster responses</li>
                  <li>• Be specific about your interest and requirements</li>
                  <li>• Ask about viewing arrangements if needed</li>
                </ul>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Safety Notice */}
        <div className="text-xs text-gray-500 text-center pt-2 border-t border-green-200">
          Always verify listings and meet in safe, public locations
        </div>
      </CardContent>
    </Card>
  );
}
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Phone, MessageCircle, User, MapPin } from "lucide-react";

interface SimpleContactAdvertiserProps {
  advertiser: {
    fullName: string;
    phoneNumber: string;
  };
  listingTitle: string;
  listingType: "property" | "car" | "order";
  listingPrice?: string;
  listingLocation?: string;
}

export function SimpleContactAdvertiser({ 
  advertiser, 
  listingTitle, 
  listingType, 
  listingPrice, 
  listingLocation 
}: SimpleContactAdvertiserProps) {
  const formatPhone = (phone: string) => {
    if (phone.startsWith('0')) {
      return '+254' + phone.substring(1);
    }
    if (phone.startsWith('254')) {
      return '+' + phone;
    }
    if (!phone.startsWith('+')) {
      return '+254' + phone;
    }
    return phone;
  };

  const formattedPhone = formatPhone(advertiser.phoneNumber);
  const whatsappPhone = formattedPhone.replace('+', '');

  const createWhatsAppMessage = () => {
    const typeLabel = listingType === 'property' ? 'Property' : listingType === 'car' ? 'Car' : 'Order';
    let message = `Hi! I'm interested in your ${typeLabel}: ${listingTitle}`;
    
    if (listingPrice) {
      message += ` (${listingPrice})`;
    }
    if (listingLocation) {
      message += ` in ${listingLocation}`;
    }
    
    message += '. Could you please provide more details?';
    return encodeURIComponent(message);
  };

  const handleCall = () => {
    window.open(`tel:${formattedPhone}`, '_self');
  };

  const handleWhatsApp = () => {
    const message = createWhatsAppMessage();
    window.open(`https://wa.me/${whatsappPhone}?text=${message}`, '_blank');
  };

  return (
    <Card className="border-green-200 bg-green-50">
      <CardHeader className="pb-3">
        <CardTitle className="text-lg text-green-800 flex items-center gap-2">
          <User className="h-5 w-5" />
          Contact Advertiser
        </CardTitle>
        <CardDescription className="text-green-700">
          Connect directly with {advertiser.fullName}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center gap-2 text-sm text-green-700">
          <Phone className="h-4 w-4" />
          <span>{formattedPhone}</span>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-2">
          <Button 
            onClick={handleCall}
            className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
            size="sm"
          >
            <Phone className="h-4 w-4 mr-2" />
            Call Now
          </Button>
          <Button 
            onClick={handleWhatsApp}
            className="flex-1 bg-green-600 hover:bg-green-700 text-white"
            size="sm"
          >
            <MessageCircle className="h-4 w-4 mr-2" />
            WhatsApp
          </Button>
        </div>
        
        <p className="text-xs text-green-600 text-center">
          ⚠️ Always verify advertiser identity and property details before any transaction
        </p>
      </CardContent>
    </Card>
  );
}
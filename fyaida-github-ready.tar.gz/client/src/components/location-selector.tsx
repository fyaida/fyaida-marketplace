import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { KENYAN_COUNTIES, COUNTY_TOWNS } from "@/lib/constants";

interface LocationSelectorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  label?: string;
  required?: boolean;
}

export function LocationSelector({ 
  value, 
  onChange, 
  placeholder = "e.g., Kiambu - Limuru, Nairobi - Kamulu", 
  label = "Location",
  required = false 
}: LocationSelectorProps) {
  const [county, setCounty] = useState("");
  const [subcounty, setSubcounty] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);

  // Parse existing value on component mount
  useEffect(() => {
    if (value && value.includes(" - ")) {
      const [countyPart, subcountyPart] = value.split(" - ");
      setCounty(countyPart);
      setSubcounty(subcountyPart);
    } else if (value) {
      // If it's just a county name
      if (KENYAN_COUNTIES.includes(value)) {
        setCounty(value);
        setSubcounty("");
      } else {
        // Try to find which county this subcounty belongs to
        for (const [countyName, towns] of Object.entries(COUNTY_TOWNS)) {
          if (towns.includes(value)) {
            setCounty(countyName);
            setSubcounty(value);
            onChange(`${countyName} - ${value}`);
            break;
          }
        }
      }
    }
  }, [value]);

  // Update parent when county or subcounty changes
  useEffect(() => {
    if (county && subcounty) {
      onChange(`${county} - ${subcounty}`);
    } else if (county) {
      onChange(county);
    }
  }, [county, subcounty, onChange]);

  const handleInputChange = (inputValue: string) => {
    onChange(inputValue);
    setShowSuggestions(true);

    // Try to parse county - subcounty format
    if (inputValue.includes(" - ")) {
      const [countyPart, subcountyPart] = inputValue.split(" - ");
      setCounty(countyPart);
      setSubcounty(subcountyPart);
    } else {
      // Check if it matches a county
      const matchingCounty = KENYAN_COUNTIES.find(c => 
        c.toLowerCase().includes(inputValue.toLowerCase())
      );
      if (matchingCounty) {
        setCounty(matchingCounty);
        setSubcounty("");
      }
    }
  };

  const getSuggestions = () => {
    if (!value) return [];

    const suggestions: string[] = [];
    const searchTerm = value.toLowerCase();

    // Add county matches
    KENYAN_COUNTIES.forEach(county => {
      if (county.toLowerCase().includes(searchTerm)) {
        suggestions.push(county);
      }
    });

    // Add county - subcounty combinations
    Object.entries(COUNTY_TOWNS).forEach(([countyName, towns]) => {
      if (countyName.toLowerCase().includes(searchTerm)) {
        towns.forEach(town => {
          suggestions.push(`${countyName} - ${town}`);
        });
      } else {
        towns.forEach(town => {
          if (town.toLowerCase().includes(searchTerm)) {
            suggestions.push(`${countyName} - ${town}`);
          }
        });
      }
    });

    return suggestions.slice(0, 10); // Limit to 10 suggestions
  };

  const suggestions = getSuggestions();

  return (
    <div className="space-y-2">
      {label && (
        <Label htmlFor="location-input">
          {label} {required && <span className="text-red-500">*</span>}
        </Label>
      )}
      <div className="relative">
        <Input
          id="location-input"
          type="text"
          value={value}
          onChange={(e) => handleInputChange(e.target.value)}
          onFocus={() => setShowSuggestions(true)}
          onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
          placeholder={placeholder}
          list="location-suggestions"
        />
        
        {showSuggestions && suggestions.length > 0 && (
          <div className="absolute z-10 w-full mt-1 bg-white border border-gray-300 rounded-md shadow-lg max-h-48 overflow-y-auto">
            {suggestions.map((suggestion, index) => (
              <div
                key={index}
                className="px-3 py-2 hover:bg-gray-100 cursor-pointer text-sm"
                onClick={() => {
                  onChange(suggestion);
                  setShowSuggestions(false);
                }}
              >
                {suggestion}
              </div>
            ))}
          </div>
        )}
      </div>
      
      <div className="text-xs text-gray-500">
        Format: County - Subcounty (e.g., "Kiambu - Limuru" or "Nairobi - Kamulu")
      </div>
    </div>
  );
}
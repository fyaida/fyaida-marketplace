import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import {
  Users,
  Shield,
  Settings,
  BarChart3,
  MessageSquare,
  UserCheck,
  UserX,
  Crown,
  Calendar,
  Phone,
  Mail,
  Building,
  MapPin,
  Activity,
  RefreshCw,
  AlertTriangle,
  CheckCircle,
  XCircle,
  TrendingUp,
  Plus
} from "lucide-react";
import { format } from "date-fns";
import type { User, Payment } from "@shared/schema";

interface UserAnalytics {
  user: User;
  totalProperties: number;
  totalCars: number;
  totalOrders: number;
  joinDate: string;
  lastActivity: string;
  trialStatus: {
    expired: boolean;
    daysLeft: number;
  };
}

interface PaymentWithUser extends Payment {
  user: {
    id: number;
    fullName: string;
    email: string;
    phoneNumber: string;
  };
}

export default function AdminPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [bulkSmsMessage, setBulkSmsMessage] = useState("");
  const [paymentAmount, setPaymentAmount] = useState("");
  const [paymentNote, setPaymentNote] = useState("");
  const [paymentFilter, setPaymentFilter] = useState<string>("all");
  const [whatsappFilter, setWhatsappFilter] = useState<string>("all");
  const [showAddWhatsappPayment, setShowAddWhatsappPayment] = useState(false);
  const [newWhatsappMessage, setNewWhatsappMessage] = useState("");

  // Fetch all users
  const { data: users = [], isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
  });

  // Fetch user analytics when user is selected
  const { data: userAnalytics } = useQuery<UserAnalytics>({
    queryKey: ["/api/admin/user-analytics", selectedUser?.id],
    enabled: !!selectedUser?.id,
  });

  // Fetch payments
  const { data: payments = [], isLoading: paymentsLoading } = useQuery<PaymentWithUser[]>({
    queryKey: ["/api/admin/payments", paymentFilter],
    queryFn: () => {
      const url = paymentFilter === "all" ? "/api/admin/payments" : `/api/admin/payments?status=${paymentFilter}`;
      return fetch(url).then(res => res.json());
    },
  });

  // Fetch WhatsApp payments
  const { data: whatsappPayments = [], isLoading: whatsappPaymentsLoading } = useQuery<any[]>({
    queryKey: ["/api/admin/whatsapp-payments", whatsappFilter],
    queryFn: () => {
      const url = whatsappFilter === "all" ? "/api/admin/whatsapp-payments" : `/api/admin/whatsapp-payments?status=${whatsappFilter}`;
      return fetch(url).then(res => res.json());
    },
  });

  // Toggle user status mutation
  const toggleUserStatusMutation = useMutation({
    mutationFn: ({ userId, isActive }: { userId: number; isActive: boolean }) =>
      apiRequest("POST", "/api/admin/toggle-user-status", { userId, isActive }),
    onSuccess: () => {
      toast({ title: "User status updated successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  // Update subscription mutation
  const updateSubscriptionMutation = useMutation({
    mutationFn: ({ userId, isSubscribed, subscriptionExpiry }: { 
      userId: number; 
      isSubscribed: boolean; 
      subscriptionExpiry?: string;
    }) => 
      apiRequest("POST", "/api/admin/update-user-subscription", { 
        userId, 
        isSubscribed, 
        subscriptionExpiry 
      }),
    onSuccess: () => {
      toast({ title: "Subscription updated successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/user-analytics", selectedUser?.id] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  // Reset trial mutation
  const resetTrialMutation = useMutation({
    mutationFn: (userId: number) =>
      apiRequest("POST", "/api/admin/reset-user-trial", { userId }),
    onSuccess: () => {
      toast({ title: "Trial reset successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/user-analytics", selectedUser?.id] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  // Bulk SMS mutation
  const bulkSmsMutation = useMutation({
    mutationFn: (message: string) => 
      apiRequest("POST", "/api/admin/bulk-sms", { message }),
    onSuccess: () => {
      toast({ title: "Bulk SMS sent successfully" });
      setBulkSmsMessage("");
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  // Verify payment mutation
  const verifyPaymentMutation = useMutation({
    mutationFn: ({ userId, amount, note }: { userId: number; amount: string; note: string }) =>
      apiRequest("POST", "/api/admin/verify-payment", { userId, amount, note }),
    onSuccess: () => {
      toast({ title: "Payment verified successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      setPaymentAmount("");
      setPaymentNote("");
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  // Approve payment mutation
  const approvePaymentMutation = useMutation({
    mutationFn: ({ paymentId, adminNote }: { paymentId: number; adminNote?: string }) =>
      apiRequest("POST", "/api/admin/approve-payment", { paymentId, adminNote }),
    onSuccess: () => {
      toast({ title: "Payment approved successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/payments", paymentFilter] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  // Reject payment mutation
  const rejectPaymentMutation = useMutation({
    mutationFn: ({ paymentId, adminNote }: { paymentId: number; adminNote?: string }) =>
      apiRequest("POST", "/api/admin/reject-payment", { paymentId, adminNote }),
    onSuccess: () => {
      toast({ title: "Payment rejected" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/payments", paymentFilter] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const handleToggleUserStatus = (userId: number, currentStatus: boolean | null) => {
    toggleUserStatusMutation.mutate({ userId, isActive: !currentStatus });
  };

  const handleSubscriptionToggle = (userId: number, isSubscribed: boolean) => {
    const subscriptionExpiry = isSubscribed 
      ? new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString()
      : undefined;
    
    updateSubscriptionMutation.mutate({ userId, isSubscribed, subscriptionExpiry });
  };

  const handleResetTrial = (userId: number) => {
    resetTrialMutation.mutate(userId);
  };

  const handleBulkSms = () => {
    if (!bulkSmsMessage.trim()) {
      toast({ title: "Error", description: "Message cannot be empty", variant: "destructive" });
      return;
    }
    bulkSmsMutation.mutate(bulkSmsMessage);
  };

  const handleVerifyPayment = () => {
    if (!selectedUser || !paymentAmount) {
      toast({ title: "Error", description: "Please select user and enter amount", variant: "destructive" });
      return;
    }
    verifyPaymentMutation.mutate({ 
      userId: selectedUser.id, 
      amount: paymentAmount, 
      note: paymentNote 
    });
  };

  const getStatusBadge = (user: User) => {
    if (user.role === 'admin') return <Badge className="bg-purple-100 text-purple-800"><Crown className="w-3 h-3 mr-1" />Admin</Badge>;
    if (!user.isActive) return <Badge variant="destructive"><XCircle className="w-3 h-3 mr-1" />Inactive</Badge>;
    if (user.isSubscribed) return <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Subscribed</Badge>;
    return <Badge variant="outline"><Activity className="w-3 h-3 mr-1" />Trial</Badge>;
  };

  const stats = {
    totalUsers: users.length,
    activeUsers: users.filter(u => u.isActive).length,
    subscribedUsers: users.filter(u => u.isSubscribed).length,
    adminUsers: users.filter(u => u.role === 'admin').length
  };

  if (usersLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <RefreshCw className="h-8 w-8 animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center space-x-3 mb-4">
            <Shield className="h-8 w-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard - Payment Verification Center</h1>
          </div>
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-4">
            <h3 className="font-semibold text-green-900 mb-2">Quick Access: WhatsApp Payment Verification</h3>
            <p className="text-sm text-green-800">Use the green "WhatsApp Verify" button in the top navigation or scroll to the "WhatsApp Verification" tab below to process all forwarded M-Pesa payment messages.</p>
          </div>
          
          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center">
                  <Users className="h-8 w-8 text-blue-500" />
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Total Users</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.totalUsers}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center">
                  <UserCheck className="h-8 w-8 text-green-500" />
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Active Users</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.activeUsers}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center">
                  <TrendingUp className="h-8 w-8 text-purple-500" />
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Subscribed</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.subscribedUsers}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center">
                  <Crown className="h-8 w-8 text-yellow-500" />
                  <div className="ml-4">
                    <p className="text-sm font-medium text-gray-600">Admins</p>
                    <p className="text-2xl font-bold text-gray-900">{stats.adminUsers}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        <Tabs defaultValue="users" className="space-y-6">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8 overflow-x-auto">
              <TabsTrigger value="users" className="whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm">
                Users
              </TabsTrigger>
              <TabsTrigger value="analytics" className="whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm">
                Analytics
              </TabsTrigger>
              <TabsTrigger value="payments" className="whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm">
                Manual Payment
              </TabsTrigger>
              <TabsTrigger value="payment-approvals" className="whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm">
                Payment Approvals
              </TabsTrigger>
              <TabsTrigger value="whatsapp-verification" className="whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm">
                WhatsApp Verification
              </TabsTrigger>
              <TabsTrigger value="communication" className="whitespace-nowrap py-2 px-1 border-b-2 font-medium text-sm">
                Communication
              </TabsTrigger>
            </nav>
          </div>

          {/* User Management Tab */}
          <TabsContent value="users">
            <div className="grid lg:grid-cols-3 gap-6">
              {/* Users List */}
              <div className="lg:col-span-2">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Users className="h-5 w-5" />
                      <span>All Users ({users.length})</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {users.map((user) => (
                        <div 
                          key={user.id}
                          className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                            selectedUser?.id === user.id ? 'border-blue-500 bg-blue-50' : 'hover:bg-gray-50'
                          }`}
                          onClick={() => setSelectedUser(user)}
                        >
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <div className="flex items-center space-x-3">
                                <div>
                                  <p className="font-medium text-gray-900">{user.fullName}</p>
                                  <p className="text-sm text-gray-500">{user.email}</p>
                                  <div className="flex items-center space-x-2 mt-1">
                                    {getStatusBadge(user)}
                                    <span className="text-xs text-gray-400">
                                      Joined {user.createdAt ? format(new Date(user.createdAt), 'MMM dd, yyyy') : 'N/A'}
                                    </span>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Button
                                size="sm"
                                variant={user.isActive ? "destructive" : "default"}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleToggleUserStatus(user.id, user.isActive ?? true);
                                }}
                                disabled={user.role === 'admin'}
                              >
                                {user.isActive ? <UserX className="h-4 w-4" /> : <UserCheck className="h-4 w-4" />}
                              </Button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Selected User Details */}
              <div>
                {selectedUser ? (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Settings className="h-5 w-5" />
                        <span>User Controls</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <h3 className="font-medium text-gray-900 mb-2">{selectedUser.fullName}</h3>
                        <div className="space-y-2 text-sm">
                          <div className="flex items-center space-x-2">
                            <Mail className="h-4 w-4 text-gray-400" />
                            <span>{selectedUser.email}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Phone className="h-4 w-4 text-gray-400" />
                            <span>{selectedUser.phoneNumber}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <MapPin className="h-4 w-4 text-gray-400" />
                            <span>{selectedUser.city}, {selectedUser.country}</span>
                          </div>
                          {selectedUser.companyName && (
                            <div className="flex items-center space-x-2">
                              <Building className="h-4 w-4 text-gray-400" />
                              <span>{selectedUser.companyName}</span>
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="space-y-3">
                        <Button
                          variant={selectedUser.isSubscribed ? "destructive" : "default"}
                          className="w-full"
                          onClick={() => handleSubscriptionToggle(selectedUser.id, !selectedUser.isSubscribed)}
                          disabled={selectedUser.role === 'admin'}
                        >
                          {selectedUser.isSubscribed ? 'Remove Subscription' : 'Grant Subscription'}
                        </Button>

                        <Button
                          variant="outline"
                          className="w-full"
                          onClick={() => handleResetTrial(selectedUser.id)}
                          disabled={selectedUser.role === 'admin'}
                        >
                          <RefreshCw className="h-4 w-4 mr-2" />
                          Reset Trial
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  <Card>
                    <CardContent className="pt-6">
                      <div className="text-center text-gray-500">
                        <Users className="h-8 w-8 mx-auto mb-2 text-gray-300" />
                        <p>Select a user to view details and controls</p>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </div>
          </TabsContent>

          {/* User Analytics Tab */}
          <TabsContent value="analytics">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BarChart3 className="h-5 w-5" />
                  <span>User Analytics</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {selectedUser && userAnalytics ? (
                  <div className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <h3 className="font-medium text-gray-900">Activity Overview</h3>
                      <div className="grid grid-cols-3 gap-4">
                        <div className="text-center p-3 bg-blue-50 rounded-lg">
                          <p className="text-2xl font-bold text-blue-600">{userAnalytics.totalProperties}</p>
                          <p className="text-sm text-gray-600">Properties</p>
                        </div>
                        <div className="text-center p-3 bg-green-50 rounded-lg">
                          <p className="text-2xl font-bold text-green-600">{userAnalytics.totalCars}</p>
                          <p className="text-sm text-gray-600">Cars</p>
                        </div>
                        <div className="text-center p-3 bg-purple-50 rounded-lg">
                          <p className="text-2xl font-bold text-purple-600">{userAnalytics.totalOrders}</p>
                          <p className="text-sm text-gray-600">Orders</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="space-y-4">
                      <h3 className="font-medium text-gray-900">Trial Status</h3>
                      <div className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm text-gray-600">Trial Status</span>
                          <Badge variant={userAnalytics.trialStatus.expired ? "destructive" : "default"}>
                            {userAnalytics.trialStatus.expired ? "Expired" : "Active"}
                          </Badge>
                        </div>
                        <p className="text-lg font-semibold">
                          {userAnalytics.trialStatus.expired 
                            ? "Trial has expired" 
                            : `${userAnalytics.trialStatus.daysLeft} days remaining`
                          }
                        </p>
                      </div>
                    </div>
                  </div>
                ) : (
                  <div className="text-center text-gray-500">
                    <BarChart3 className="h-8 w-8 mx-auto mb-2 text-gray-300" />
                    <p>Select a user from the User Management tab to view analytics</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Manual Payment Verification Tab */}
          <TabsContent value="payments">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>Manual Payment Verification</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                {selectedUser ? (
                  <div className="space-y-4">
                    <div>
                      <h3 className="font-medium text-gray-900 mb-2">
                        Verify Payment for {selectedUser.fullName}
                      </h3>
                      <p className="text-sm text-gray-600">{selectedUser.email}</p>
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Payment Amount (KSH)
                        </label>
                        <Input
                          type="number"
                          placeholder="300"
                          value={paymentAmount}
                          onChange={(e) => setPaymentAmount(e.target.value)}
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">
                          Note (Optional)
                        </label>
                        <Input
                          placeholder="Payment reference or note"
                          value={paymentNote}
                          onChange={(e) => setPaymentNote(e.target.value)}
                        />
                      </div>
                    </div>
                    
                    <Button 
                      onClick={handleVerifyPayment}
                      disabled={!paymentAmount || verifyPaymentMutation.isPending}
                      className="w-full"
                    >
                      {verifyPaymentMutation.isPending ? "Verifying..." : "Verify Payment & Activate Subscription"}
                    </Button>
                  </div>
                ) : (
                  <div className="text-center text-gray-500">
                    <CheckCircle className="h-8 w-8 mx-auto mb-2 text-gray-300" />
                    <p>Select a user from the User Management tab to verify payments</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Payment Approvals Tab */}
          <TabsContent value="payment-approvals">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <CheckCircle className="h-5 w-5" />
                  <span>M-Pesa Payment Approvals</span>
                </CardTitle>
                <div className="flex items-center space-x-2 mt-2">
                  <select 
                    className="px-3 py-2 border rounded-md"
                    value={paymentFilter}
                    onChange={(e) => setPaymentFilter(e.target.value)}
                  >
                    <option value="all">All Payments</option>
                    <option value="pending">Pending Approval</option>
                    <option value="approved">Approved</option>
                    <option value="rejected">Rejected</option>
                  </select>
                </div>
              </CardHeader>
              <CardContent>
                {paymentsLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <RefreshCw className="h-6 w-6 animate-spin" />
                    <span className="ml-2">Loading payments...</span>
                  </div>
                ) : payments.length === 0 ? (
                  <div className="text-center text-gray-500 py-8">
                    <CheckCircle className="h-8 w-8 mx-auto mb-2 text-gray-300" />
                    <p>No payments found</p>
                  </div>
                ) : (
                  <div className="space-y-4 max-h-96 overflow-y-auto">
                    {payments.map((payment) => (
                      <div 
                        key={payment.id}
                        className="p-4 border rounded-lg bg-white"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="flex items-center space-x-3">
                              <div>
                                <p className="font-medium text-gray-900">
                                  KSH {payment.amount} - {payment.user?.fullName || 'Unknown User'}
                                </p>
                                <p className="text-sm text-gray-500">
                                  {payment.user?.email} • {payment.phoneNumber}
                                </p>
                                <div className="flex items-center space-x-2 mt-1">
                                  <Badge 
                                    variant={
                                      payment.status === 'pending' ? 'outline' :
                                      payment.status === 'approved' ? 'default' : 'destructive'
                                    }
                                    className={
                                      payment.status === 'approved' ? 'bg-green-100 text-green-800' : ''
                                    }
                                  >
                                    {payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}
                                  </Badge>
                                  <span className="text-xs text-gray-400">
                                    {payment.createdAt ? format(new Date(payment.createdAt), 'MMM dd, yyyy HH:mm') : 'N/A'}
                                  </span>
                                </div>
                                {payment.mpesaReceiptNumber && (
                                  <p className="text-xs text-gray-600 mt-1">
                                    Receipt: {payment.mpesaReceiptNumber}
                                  </p>
                                )}
                                {payment.adminNote && (
                                  <p className="text-xs text-blue-600 mt-1">
                                    Admin Note: {payment.adminNote}
                                  </p>
                                )}
                              </div>
                            </div>
                          </div>
                          {payment.status === 'pending' && (
                            <div className="flex items-center space-x-2">
                              <Button
                                size="sm"
                                variant="default"
                                className="bg-green-600 hover:bg-green-700"
                                onClick={() => {
                                  const note = prompt("Add approval note (optional):");
                                  approvePaymentMutation.mutate({ 
                                    paymentId: payment.id, 
                                    adminNote: note || undefined 
                                  });
                                }}
                                disabled={approvePaymentMutation.isPending}
                              >
                                <CheckCircle className="h-4 w-4 mr-1" />
                                Approve
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => {
                                  const note = prompt("Add rejection reason:");
                                  if (note) {
                                    rejectPaymentMutation.mutate({ 
                                      paymentId: payment.id, 
                                      adminNote: note 
                                    });
                                  }
                                }}
                                disabled={rejectPaymentMutation.isPending}
                              >
                                <XCircle className="h-4 w-4 mr-1" />
                                Reject
                              </Button>
                            </div>
                          )}
                        </div>
                        <div className="mt-2 text-xs text-gray-500">
                          Till: {payment.tillNumber} • Method: {payment.paymentMethod}
                          {payment.approvedAt && (
                            <span> • Approved: {format(new Date(payment.approvedAt), 'MMM dd, yyyy HH:mm')}</span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* WhatsApp Verification Tab */}
          <TabsContent value="whatsapp-verification">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <MessageSquare className="h-5 w-5" />
                  <span>WhatsApp Payment Verification</span>
                </CardTitle>
                <div className="flex items-center space-x-2 mt-4">
                  <select 
                    className="px-3 py-2 border rounded-md"
                    value={whatsappFilter}
                    onChange={(e) => setWhatsappFilter(e.target.value)}
                  >
                    <option value="all">All Messages</option>
                    <option value="unprocessed">Unprocessed</option>
                    <option value="matched">Matched</option>
                    <option value="verified">Verified</option>
                    <option value="rejected">Rejected</option>
                  </select>
                  <Button
                    onClick={() => setShowAddWhatsappPayment(true)}
                    className="bg-blue-600 hover:bg-blue-700"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add WhatsApp Message
                  </Button>
                </div>
              </CardHeader>
              
              {showAddWhatsappPayment && (
                <div className="mx-6 mb-4 p-4 border rounded-lg bg-blue-50">
                  <h3 className="font-medium mb-3">Forward New WhatsApp Payment Message</h3>
                  <div className="space-y-3">
                    <textarea
                      className="w-full p-3 border rounded-md"
                      rows={4}
                      placeholder="Paste the complete WhatsApp payment message here..."
                      value={newWhatsappMessage}
                      onChange={(e) => setNewWhatsappMessage(e.target.value)}
                    />
                    <div className="flex items-center space-x-2">
                      <Button
                        onClick={() => {
                          if (newWhatsappMessage.trim()) {
                            fetch('/api/admin/whatsapp-payment', {
                              method: 'POST',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({ messageText: newWhatsappMessage.trim() })
                            }).then(() => {
                              setShowAddWhatsappPayment(false);
                              setNewWhatsappMessage("");
                              window.location.reload();
                            });
                          }
                        }}
                        disabled={!newWhatsappMessage.trim()}
                      >
                        Process Message
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => {
                          setShowAddWhatsappPayment(false);
                          setNewWhatsappMessage("");
                        }}
                      >
                        Cancel
                      </Button>
                    </div>
                  </div>
                </div>
              )}
              <CardContent>
                {whatsappPaymentsLoading ? (
                  <div className="flex items-center justify-center py-8">
                    <RefreshCw className="h-6 w-6 animate-spin" />
                    <span className="ml-2">Loading WhatsApp messages...</span>
                  </div>
                ) : whatsappPayments.length === 0 ? (
                  <div className="text-center text-gray-500 py-8">
                    <MessageSquare className="h-8 w-8 mx-auto mb-2 text-gray-300" />
                    <p>No WhatsApp payment messages found</p>
                    <p className="text-sm mt-1">Forward M-Pesa payment messages to verify and activate subscriptions</p>
                  </div>
                ) : (
                  <div className="space-y-4 max-h-96 overflow-y-auto">
                    {whatsappPayments.map((payment) => (
                      <div 
                        key={payment.id}
                        className="p-4 border rounded-lg bg-white"
                      >
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-2">
                              <Badge 
                                variant={
                                  payment.status === 'unprocessed' ? 'outline' :
                                  payment.status === 'verified' ? 'default' :
                                  payment.status === 'matched' ? 'secondary' : 'destructive'
                                }
                                className={
                                  payment.status === 'verified' ? 'bg-green-100 text-green-800' : ''
                                }
                              >
                                {payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}
                              </Badge>
                              <span className="text-xs text-gray-400">
                                {payment.createdAt ? format(new Date(payment.createdAt), 'MMM dd, yyyy HH:mm') : 'N/A'}
                              </span>
                            </div>
                            
                            {payment.status === 'unprocessed' && (
                              <div className="flex items-center space-x-2">
                                <Button
                                  size="sm"
                                  variant="default"
                                  className="bg-green-600 hover:bg-green-700"
                                  onClick={() => {
                                    const note = prompt("Add verification note:");
                                    if (note) {
                                      fetch('/api/admin/verify-whatsapp-payment', {
                                        method: 'POST',
                                        headers: { 'Content-Type': 'application/json' },
                                        body: JSON.stringify({ paymentId: payment.id, adminNotes: note })
                                      }).then(() => window.location.reload());
                                    }
                                  }}
                                >
                                  <CheckCircle className="h-4 w-4 mr-1" />
                                  Verify
                                </Button>
                                <Button
                                  size="sm"
                                  variant="destructive"
                                  onClick={() => {
                                    const note = prompt("Add rejection reason:");
                                    if (note) {
                                      fetch('/api/admin/reject-whatsapp-payment', {
                                        method: 'POST',
                                        headers: { 'Content-Type': 'application/json' },
                                        body: JSON.stringify({ paymentId: payment.id, adminNotes: note })
                                      }).then(() => window.location.reload());
                                    }
                                  }}
                                >
                                  <XCircle className="h-4 w-4 mr-1" />
                                  Reject
                                </Button>
                              </div>
                            )}
                          </div>
                          
                          <div className="bg-gray-50 p-3 rounded-md">
                            <p className="text-sm text-gray-700 whitespace-pre-wrap">{payment.messageText}</p>
                          </div>
                          
                          <div className="grid md:grid-cols-2 gap-4 text-sm">
                            <div>
                              {payment.amount && (
                                <p><span className="font-medium">Amount:</span> KSH {payment.amount}</p>
                              )}
                              {payment.mpesaCode && (
                                <p><span className="font-medium">M-Pesa Code:</span> {payment.mpesaCode}</p>
                              )}
                              {payment.senderPhone && (
                                <p><span className="font-medium">Sender:</span> {payment.senderPhone}</p>
                              )}
                            </div>
                            <div>
                              {payment.matchedUser && (
                                <p><span className="font-medium">Matched User:</span> {payment.matchedUser.fullName} ({payment.matchedUser.email})</p>
                              )}
                              {payment.adminNotes && (
                                <p><span className="font-medium">Admin Notes:</span> {payment.adminNotes}</p>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Bulk Communication Tab */}
          <TabsContent value="communication">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <MessageSquare className="h-5 w-5" />
                  <span>Bulk SMS Communication</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Message to All Advertisers
                    </label>
                    <Textarea
                      placeholder="Enter your message to send to all advertisers via SMS..."
                      value={bulkSmsMessage}
                      onChange={(e) => setBulkSmsMessage(e.target.value)}
                      className="min-h-32"
                    />
                  </div>
                  
                  <div className="flex items-center space-x-2 text-sm text-gray-600">
                    <AlertTriangle className="h-4 w-4" />
                    <span>This will send SMS to all users with phone numbers</span>
                  </div>
                  
                  <Button 
                    onClick={handleBulkSms}
                    disabled={!bulkSmsMessage.trim() || bulkSmsMutation.isPending}
                    className="w-full"
                  >
                    {bulkSmsMutation.isPending ? "Sending..." : "Send Bulk SMS"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
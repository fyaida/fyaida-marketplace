import { useState } from "react";
import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { SearchBar, type SearchFilters } from "@/components/search-bar";
import { PropertyCard } from "@/components/property-card";
import { CarCard } from "@/components/car-card";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useLoginRedirect } from "@/hooks/useLoginRedirect";
import { 
  CheckCircle, 
  Home, 
  Car as CarIcon, 
  ClipboardList,
  MapPin,
  Bed,
  Calendar,
  Users,
  Download,
  Smartphone,
  Star
} from "lucide-react";
import type { Property, Car, OpenOrder } from "@shared/schema";

type TabType = "properties" | "cars" | "orders";

export default function HomePage() {
  const [activeTab, setActiveTab] = useState<TabType>("properties");
  
  // Redirect admin and advertiser users to dashboard after login
  useLoginRedirect();

  const { data: properties } = useQuery<Property[]>({
    queryKey: ["/api/properties"],
  });

  const { data: cars } = useQuery<Car[]>({
    queryKey: ["/api/cars"],
  });

  const { data: openOrders, error: openOrdersError } = useQuery<OpenOrder[]>({
    queryKey: ["/api/open-orders"],
    retry: false,
  });

  const handleSearch = (filters: SearchFilters) => {
    // Implement search logic
    console.log("Search filters:", filters);
  };

  const featuredProperties = properties?.slice(0, 3) || [];
  const featuredCars = cars?.slice(0, 2) || [];
  const recentOpenOrders = openOrders?.slice(0, 1) || [];

  const tabs = [
    { id: "properties" as TabType, label: "Properties", icon: Home },
    { id: "cars" as TabType, label: "Cars", icon: CarIcon },
    { id: "orders" as TabType, label: "Open Orders", icon: ClipboardList },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Hero Search Section */}
      <SearchBar onSearch={handleSearch} />

      {/* Mobile App Download Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="bg-gradient-to-r from-primary to-primary/80 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="flex-1">
              <div className="flex items-center space-x-3 mb-3">
                <Smartphone className="h-8 w-8" />
                <div>
                  <h3 className="text-xl font-bold">Download Fyaida Mobile App</h3>
                  <p className="text-primary-foreground/90">Browse properties and cars on the go!</p>
                </div>
              </div>
              <div className="flex items-center space-x-4 text-sm text-primary-foreground/80">
                <div className="flex items-center space-x-1">
                  <Star className="h-4 w-4 fill-current" />
                  <span>4.8 Rating</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Download className="h-4 w-4" />
                  <span>10K+ Downloads</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Users className="h-4 w-4" />
                  <span>Direct APK Download</span>
                </div>
              </div>
            </div>
            <div className="flex flex-col space-y-2">
              <Link href="/mobile-app">
                <Button 
                  size="lg" 
                  variant="secondary"
                  className="bg-white text-primary hover:bg-white/90 font-semibold px-6"
                >
                  <Download className="mr-2 h-5 w-5" />
                  Download APK
                </Button>
              </Link>
              <p className="text-xs text-primary-foreground/70 text-center">
                Android 5.0+
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Category Tabs */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex space-x-1 bg-gray-100 rounded-lg p-1">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex-1 py-3 px-4 rounded-md font-medium transition-colors ${
                  activeTab === tab.id
                    ? "bg-white text-primary shadow-sm"
                    : "text-gray-600 hover:text-primary"
                }`}
              >
                <Icon className="h-5 w-5 mr-2 inline" />
                {tab.label}
              </button>
            );
          })}
        </div>
      </section>

      {/* Filter Bar */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-6">
        <div className="flex flex-wrap gap-4 items-center">
          <select className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent">
            <option>All {activeTab === "properties" ? "Properties" : activeTab === "cars" ? "Cars" : "Orders"}</option>
            {activeTab === "properties" && (
              <>
                <option>For Sale</option>
                <option>For Rent</option>
                <option>For Lease</option>
              </>
            )}
          </select>
          
          {activeTab === "properties" && (
            <select className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent">
              <option>Bedrooms</option>
              <option>1 Bedroom</option>
              <option>2 Bedrooms</option>
              <option>3+ Bedrooms</option>
            </select>
          )}
          
          <select className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent">
            <option>Sort by</option>
            <option>Price: Low to High</option>
            <option>Price: High to Low</option>
            <option>Newest First</option>
          </select>
          
          <button className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors">
            <svg className="h-4 w-4 mr-2 inline" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
            </svg>
            More Filters
          </button>
        </div>
      </section>

      {/* Featured Listings */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-12">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">
          Featured {activeTab === "properties" ? "Properties" : activeTab === "cars" ? "Cars" : "Open Orders"}
        </h2>

        {activeTab === "properties" && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredProperties.length > 0 ? (
              featuredProperties.map((property) => (
                <PropertyCard key={property.id} property={property} />
              ))
            ) : (
              <div className="col-span-full text-center py-8">
                <p className="text-gray-500">No properties available yet.</p>
                <Link href="/post-ad">
                  <Button className="mt-4">Post Your First Property</Button>
                </Link>
              </div>
            )}
          </div>
        )}

        {activeTab === "cars" && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {featuredCars.length > 0 ? (
              featuredCars.map((car) => (
                <CarCard key={car.id} car={car} />
              ))
            ) : (
              <div className="col-span-full text-center py-8">
                <p className="text-gray-500">No cars available yet.</p>
                <Link href="/post-ad">
                  <Button className="mt-4">Post Your First Car</Button>
                </Link>
              </div>
            )}
          </div>
        )}

        {activeTab === "orders" && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recentOpenOrders.length > 0 ? (
              recentOpenOrders.map((order) => (
                <Card key={order.id} className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <Badge className="bg-purple-100 text-purple-800">
                        <ClipboardList className="h-3 w-3 mr-1" />
                        Open Order
                      </Badge>
                      <span className="text-lg font-bold text-purple-700">
                        Budget: KSh {parseFloat(order.budget).toLocaleString()}
                      </span>
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-2">{order.title}</h3>
                    <p className="text-gray-600 text-sm mb-4">{order.description}</p>
                    <div className="flex items-center space-x-4 text-sm text-gray-600 mb-4">
                      <span className="flex items-center">
                        <MapPin className="h-4 w-4 mr-1" />
                        {order.location}
                      </span>
                      <span className="flex items-center">
                        <Calendar className="h-4 w-4 mr-1" />
                        {order.propertyType}
                      </span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs text-gray-500">
                        Posted {new Date(order.createdAt!).toLocaleDateString()}
                      </span>
                      <Button size="sm" className="bg-purple-600 hover:bg-purple-700">
                        Respond to Order
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="col-span-full text-center py-8">
                <p className="text-gray-500">No open orders available yet.</p>
                <p className="text-sm text-gray-400 mt-2">Subscribe to create and view open orders</p>
              </div>
            )}
          </div>
        )}
      </section>

      {/* Subscription Banner */}
      <section className="gradient-subscription text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-4">
                Boost Your Listings with Premium Subscription
              </h2>
              <div className="space-y-3 mb-6">
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 mr-3" />
                  <span>5 days free posting for new users</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 mr-3" />
                  <span>KSh 300 for 90 days unlimited posting</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 mr-3" />
                  <span>Share listings to social media platforms</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 mr-3" />
                  <span>Access to Open Property Orders</span>
                </div>
              </div>
              <Link href="/subscription">
                <Button className="bg-white text-secondary hover:bg-gray-100">
                  Subscribe Now - KSh 300
                </Button>
              </Link>
            </div>
            
            <div className="bg-white/10 rounded-xl p-6">
              <h3 className="text-xl font-semibold mb-4">Payment Instructions</h3>
              <div className="space-y-3 text-sm">
                <p><strong>Send KSh 300 to Till Number:</strong> 3511028</p>
                <p><strong>Recipient:</strong> Newtech Systems Technicians</p>
                <p><strong>Verification:</strong> Forward payment message to WhatsApp 0722869901</p>
                <p className="text-xs opacity-90">
                  Enter your mobile number used for payment during verification
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mobile App Download Section */}
      <section className="bg-gradient-to-r from-green-600 to-blue-600 text-white py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex justify-center mb-6">
            <Smartphone className="h-16 w-16" />
          </div>
          <h2 className="text-3xl font-bold mb-4">Download Fyaida Mobile App</h2>
          <p className="text-xl mb-8 opacity-90">
            Access Kenya's premier marketplace anywhere, anytime. Browse properties and cars on the go!
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-white/10 rounded-lg p-4">
              <Star className="h-8 w-8 mx-auto mb-2" />
              <h3 className="font-semibold mb-2">Easy Browsing</h3>
              <p className="text-sm opacity-80">Browse thousands of properties and cars with intuitive search</p>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <MapPin className="h-8 w-8 mx-auto mb-2" />
              <h3 className="font-semibold mb-2">Location-Based</h3>
              <p className="text-sm opacity-80">Find listings near you across all 47 Kenyan counties</p>
            </div>
            <div className="bg-white/10 rounded-lg p-4">
              <ClipboardList className="h-8 w-8 mx-auto mb-2" />
              <h3 className="font-semibold mb-2">Open Orders</h3>
              <p className="text-sm opacity-80">Create and respond to buyer requests instantly</p>
            </div>
          </div>

          <div className="space-y-4">
            <Button 
              size="lg" 
              className="bg-white text-green-600 hover:bg-gray-100 text-lg px-8 py-3"
              onClick={() => {
                const link = document.createElement('a');
                link.href = '/downloads/fyaida-mobile.apk';
                link.download = 'fyaida-mobile.apk';
                link.click();
              }}
            >
              <Download className="h-5 w-5 mr-2" />
              Download for Android (APK)
            </Button>
            <p className="text-sm opacity-80">
              Version 1.0.0 • Compatible with Android 6.0+
            </p>
            <div className="text-xs opacity-70 mt-4">
              <p>Direct download from our website • No Google Play Store required</p>
              <p>For support: WhatsApp 0722 869 901 | Office: Moi Avenue, Nairobi</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">Fyaida</h3>
              <p className="text-gray-400">
                Kenya's premier marketplace for properties and cars
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400">
                <li><Link href="/properties">Browse Properties</Link></li>
                <li><Link href="/cars">Browse Cars</Link></li>
                <li><Link href="/post-ad">Post an Ad</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-gray-400">
                <li>WhatsApp: 0722 869 901</li>
                <li>Office: Moi Avenue, Nairobi</li>
                <li>M-Pesa Till: 3511028</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Mobile App</h4>
              <div className="space-y-2">
                <Button 
                  variant="outline" 
                  size="sm"
                  className="text-white border-white hover:bg-white hover:text-gray-900"
                  onClick={() => {
                    const link = document.createElement('a');
                    link.href = '/downloads/fyaida-mobile.apk';
                    link.download = 'fyaida-mobile.apk';
                    link.click();
                  }}
                >
                  <Download className="h-4 w-4 mr-1" />
                  Download APK
                </Button>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2025 Fyaida. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import {
  MessageSquare,
  Plus,
  CheckCircle,
  XCircle,
  RefreshCw,
  Eye,
  User
} from "lucide-react";
import { format } from "date-fns";

interface WhatsappPayment {
  id: number;
  messageText: string;
  senderPhone?: string;
  recipientPhone?: string;
  amount?: string;
  mpesaCode?: string;
  transactionDate?: string;
  status: string;
  matchedUserId?: number;
  processedBy?: number;
  processedAt?: string;
  adminNotes?: string;
  createdAt: string;
  updatedAt: string;
  matchedUser?: {
    id: number;
    fullName: string;
    email: string;
    phoneNumber: string;
  };
}

interface User {
  id: number;
  fullName: string;
  email: string;
  phoneNumber: string;
}

export default function WhatsAppAdminPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState<string>("all");
  const [showAddMessage, setShowAddMessage] = useState(false);
  const [newMessage, setNewMessage] = useState("");
  const [selectedPayment, setSelectedPayment] = useState<WhatsappPayment | null>(null);

  // Fetch WhatsApp payments
  const { data: whatsappPayments = [], isLoading } = useQuery<WhatsappPayment[]>({
    queryKey: ["/api/admin/whatsapp-payments", filter],
    queryFn: () => {
      const url = filter === "all" ? "/api/admin/whatsapp-payments" : `/api/admin/whatsapp-payments?status=${filter}`;
      return fetch(url).then(res => res.json());
    },
  });

  // Fetch all users for matching
  const { data: users = [] } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
  });

  // Add WhatsApp payment message
  const addMessageMutation = useMutation({
    mutationFn: (messageText: string) =>
      apiRequest("POST", "/api/admin/whatsapp-payment", { messageText }),
    onSuccess: () => {
      toast({ title: "WhatsApp message processed successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/whatsapp-payments"] });
      setShowAddMessage(false);
      setNewMessage("");
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  // Match payment to user
  const matchUserMutation = useMutation({
    mutationFn: ({ paymentId, userId }: { paymentId: number; userId: number }) =>
      apiRequest("POST", "/api/admin/match-whatsapp-payment", { paymentId, userId }),
    onSuccess: () => {
      toast({ title: "Payment matched to user successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/whatsapp-payments"] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  // Verify payment
  const verifyMutation = useMutation({
    mutationFn: ({ paymentId, adminNotes }: { paymentId: number; adminNotes?: string }) =>
      apiRequest("POST", "/api/admin/verify-whatsapp-payment", { paymentId, adminNotes }),
    onSuccess: () => {
      toast({ title: "Payment verified and subscription activated" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/whatsapp-payments"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/payments"] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  // Reject payment
  const rejectMutation = useMutation({
    mutationFn: ({ paymentId, adminNotes }: { paymentId: number; adminNotes: string }) =>
      apiRequest("POST", "/api/admin/reject-whatsapp-payment", { paymentId, adminNotes }),
    onSuccess: () => {
      toast({ title: "Payment rejected" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/whatsapp-payments"] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const handleAddMessage = () => {
    if (newMessage.trim()) {
      addMessageMutation.mutate(newMessage.trim());
    }
  };

  const handleVerify = (payment: WhatsappPayment) => {
    const note = prompt("Add verification note (optional):");
    verifyMutation.mutate({ paymentId: payment.id, adminNotes: note || undefined });
  };

  const handleReject = (payment: WhatsappPayment) => {
    const note = prompt("Add rejection reason:");
    if (note) {
      rejectMutation.mutate({ paymentId: payment.id, adminNotes: note });
    }
  };

  const handleMatchUser = (payment: WhatsappPayment) => {
    const userId = prompt("Enter User ID to match this payment:");
    if (userId && !isNaN(Number(userId))) {
      matchUserMutation.mutate({ paymentId: payment.id, userId: Number(userId) });
    }
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">WhatsApp Payment Verification</h1>
        <Button
          onClick={() => setShowAddMessage(true)}
          className="bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="h-4 w-4 mr-2" />
          Add WhatsApp Message
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <MessageSquare className="h-5 w-5" />
            <span>Forwarded Payment Messages</span>
          </CardTitle>
          <div className="flex items-center space-x-2">
            <select 
              className="px-3 py-2 border rounded-md"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            >
              <option value="all">All Messages</option>
              <option value="unprocessed">Unprocessed</option>
              <option value="matched">Matched</option>
              <option value="verified">Verified</option>
              <option value="rejected">Rejected</option>
            </select>
          </div>
        </CardHeader>
        <CardContent>
          {showAddMessage && (
            <div className="mb-6 p-4 border rounded-lg bg-blue-50">
              <h3 className="font-medium mb-3">Forward New WhatsApp Payment Message</h3>
              <div className="space-y-3">
                <textarea
                  className="w-full p-3 border rounded-md"
                  rows={4}
                  placeholder="Paste the complete WhatsApp M-Pesa payment message here..."
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                />
                <div className="flex items-center space-x-2">
                  <Button
                    onClick={handleAddMessage}
                    disabled={!newMessage.trim() || addMessageMutation.isPending}
                  >
                    {addMessageMutation.isPending ? "Processing..." : "Process Message"}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setShowAddMessage(false);
                      setNewMessage("");
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </div>
          )}

          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <RefreshCw className="h-6 w-6 animate-spin" />
              <span className="ml-2">Loading messages...</span>
            </div>
          ) : whatsappPayments.length === 0 ? (
            <div className="text-center text-gray-500 py-8">
              <MessageSquare className="h-8 w-8 mx-auto mb-2 text-gray-300" />
              <p>No WhatsApp payment messages found</p>
              <p className="text-sm mt-1">Forward M-Pesa payment messages to verify and activate subscriptions</p>
            </div>
          ) : (
            <div className="space-y-4">
              {whatsappPayments.map((payment) => (
                <div 
                  key={payment.id}
                  className="p-4 border rounded-lg bg-white"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <Badge 
                          variant={
                            payment.status === 'unprocessed' ? 'outline' :
                            payment.status === 'verified' ? 'default' :
                            payment.status === 'matched' ? 'secondary' : 'destructive'
                          }
                          className={
                            payment.status === 'verified' ? 'bg-green-100 text-green-800' : ''
                          }
                        >
                          {payment.status.charAt(0).toUpperCase() + payment.status.slice(1)}
                        </Badge>
                        <span className="text-xs text-gray-400">
                          {payment.createdAt ? format(new Date(payment.createdAt), 'MMM dd, yyyy HH:mm') : 'N/A'}
                        </span>
                      </div>
                      
                      {payment.status === 'unprocessed' && (
                        <div className="flex items-center space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleMatchUser(payment)}
                            disabled={matchUserMutation.isPending}
                          >
                            <User className="h-4 w-4 mr-1" />
                            Match User
                          </Button>
                          <Button
                            size="sm"
                            variant="default"
                            className="bg-green-600 hover:bg-green-700"
                            onClick={() => handleVerify(payment)}
                            disabled={verifyMutation.isPending}
                          >
                            <CheckCircle className="h-4 w-4 mr-1" />
                            Verify
                          </Button>
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => handleReject(payment)}
                            disabled={rejectMutation.isPending}
                          >
                            <XCircle className="h-4 w-4 mr-1" />
                            Reject
                          </Button>
                        </div>
                      )}
                    </div>
                    
                    <div className="bg-gray-50 p-3 rounded-md">
                      <p className="text-sm text-gray-700 whitespace-pre-wrap">{payment.messageText}</p>
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-4 text-sm">
                      <div>
                        {payment.amount && (
                          <p><span className="font-medium">Amount:</span> KSH {payment.amount}</p>
                        )}
                        {payment.mpesaCode && (
                          <p><span className="font-medium">M-Pesa Code:</span> {payment.mpesaCode}</p>
                        )}
                        {payment.senderPhone && (
                          <p><span className="font-medium">Sender:</span> {payment.senderPhone}</p>
                        )}
                      </div>
                      <div>
                        {payment.matchedUser && (
                          <p><span className="font-medium">Matched User:</span> {payment.matchedUser.fullName} ({payment.matchedUser.email})</p>
                        )}
                        {payment.adminNotes && (
                          <p><span className="font-medium">Admin Notes:</span> {payment.adminNotes}</p>
                        )}
                        {payment.processedAt && (
                          <p><span className="font-medium">Processed:</span> {format(new Date(payment.processedAt), 'MMM dd, yyyy HH:mm')}</p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
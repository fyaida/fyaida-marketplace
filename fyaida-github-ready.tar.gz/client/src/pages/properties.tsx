import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { PropertyCard } from "@/components/property-card";
import { SimplePropertyDetailModal } from "@/components/simple-property-detail-modal";
import { DueDiligenceWarning } from "@/components/due-diligence-warning";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Filter } from "lucide-react";
import { PROPERTY_TYPES, LISTING_TYPES, KENYAN_COUNTIES } from "@/lib/constants";
import type { Property } from "@shared/schema";

export default function PropertiesPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedProperty, setSelectedProperty] = useState<Property | null>(null);
  const [filters, setFilters] = useState({
    type: "",
    listingType: "",
    location: "",
    county: "",
    minPrice: "",
    maxPrice: "",
    bedrooms: "",
  });

  const queryParams = new URLSearchParams();
  if (searchTerm) queryParams.append("search", searchTerm);
  Object.entries(filters).forEach(([key, value]) => {
    if (value) queryParams.append(key, value);
  });

  const { data: properties, isLoading } = useQuery<Property[]>({
    queryKey: ["/api/properties", queryParams.toString()],
    queryFn: () => fetch(`/api/properties?${queryParams.toString()}`).then(res => res.json()),
  });

  const handleSearch = () => {
    // Trigger refetch by updating query key
    window.location.hash = Math.random().toString();
  };

  const resetFilters = () => {
    setSearchTerm("");
    setFilters({
      type: "",
      listingType: "",
      location: "",
      county: "",
      minPrice: "",
      maxPrice: "",
      bedrooms: "",
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Properties</h1>
          <p className="text-gray-600">Find your perfect property in Kenya</p>
        </div>

        {/* Due Diligence Warning */}
        <DueDiligenceWarning />

        {/* Search and Filters */}
        <div className="bg-white rounded-lg shadow-sm border p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
            <div className="md:col-span-2">
              <Input
                placeholder="Search properties..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
              />
            </div>
            <div>
              <select 
                className="w-full h-10 px-3 py-2 text-sm border border-gray-300 rounded-md bg-white focus:outline-none focus:border-blue-500"
                value={filters.type} 
                onChange={(e) => setFilters({...filters, type: e.target.value})}
              >
                <option value="">All Types</option>
                {PROPERTY_TYPES.map((type) => (
                  <option key={type.value} value={type.value}>
                    {type.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <select 
                className="w-full h-10 px-3 py-2 text-sm border border-gray-300 rounded-md bg-white focus:outline-none focus:border-blue-500"
                value={filters.listingType} 
                onChange={(e) => setFilters({...filters, listingType: e.target.value})}
              >
                <option value="">All Listings</option>
                {LISTING_TYPES.map((type) => (
                  <option key={type.value} value={type.value}>
                    {type.label}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-6 gap-4 mb-4">
            <div>
              <select 
                className="w-full h-10 px-3 py-2 text-sm border border-gray-300 rounded-md bg-white focus:outline-none focus:border-blue-500"
                value={filters.county} 
                onChange={(e) => setFilters({...filters, county: e.target.value, location: ""})}
              >
                <option value="">All Counties</option>
                {KENYAN_COUNTIES.map((county) => (
                  <option key={county} value={county}>
                    {county}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <Input
                placeholder={filters.county ? "Type or select area/town..." : "Select county first"}
                value={filters.location}
                onChange={(e) => setFilters({...filters, location: e.target.value})}
                disabled={!filters.county}
                list={filters.county ? `areas-${filters.county}` : undefined}
                className="h-10"
              />
              {filters.county && (
                <datalist id={`areas-${filters.county}`}>
                  <option value="Central" />
                  <option value="North" />
                  <option value="South" />
                  <option value="East" />
                  <option value="West" />
                </datalist>
              )}
            </div>
            <div>
              <Input
                placeholder="Min Price"
                type="number"
                value={filters.minPrice}
                onChange={(e) => setFilters({...filters, minPrice: e.target.value})}
              />
            </div>
            <div>
              <Input
                placeholder="Max Price"
                type="number"
                value={filters.maxPrice}
                onChange={(e) => setFilters({...filters, maxPrice: e.target.value})}
              />
            </div>
            <div>
              <select 
                className="w-full h-10 px-3 py-2 text-sm border border-gray-300 rounded-md bg-white focus:outline-none focus:border-blue-500"
                value={filters.bedrooms} 
                onChange={(e) => setFilters({...filters, bedrooms: e.target.value})}
              >
                <option value="">Any</option>
                <option value="1">1 Bedroom</option>
                <option value="2">2 Bedrooms</option>
                <option value="3">3 Bedrooms</option>
                <option value="4">4+ Bedrooms</option>
              </select>
            </div>
            <div className="flex gap-2">
              <Button onClick={handleSearch} className="flex-1">
                <Search className="h-4 w-4 mr-2" />
                Search
              </Button>
              <Button variant="outline" onClick={resetFilters}>
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="mb-4 flex justify-between items-center">
          <p className="text-gray-600">
            {isLoading ? "Loading..." : `${properties?.length || 0} properties found`}
          </p>
          <select className="w-48 h-10 px-3 py-2 text-sm border border-gray-300 rounded-md bg-white focus:outline-none focus:border-blue-500">
            <option value="">Sort by</option>
            <option value="newest">Newest First</option>
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
          </select>
        </div>

        {/* Properties Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-white rounded-lg shadow-sm animate-pulse">
                <div className="h-48 bg-gray-200 rounded-t-lg"></div>
                <div className="p-4 space-y-3">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                  <div className="h-4 bg-gray-200 rounded w-2/3"></div>
                </div>
              </div>
            ))}
          </div>
        ) : properties && properties.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {properties.map((property) => (
              <PropertyCard 
                key={property.id} 
                property={property} 
                onViewDetails={() => setSelectedProperty(property)}
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <div className="max-w-md mx-auto">
              <div className="h-24 w-24 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                <Search className="h-8 w-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No properties found</h3>
              <p className="text-gray-500 mb-4">
                Try adjusting your search criteria or browse all properties.
              </p>
              <Button onClick={resetFilters} variant="outline">
                Clear Filters
              </Button>
            </div>
          </div>
        )}
      </div>
      
      {/* Property Detail Modal */}
      {selectedProperty && (
        <SimplePropertyDetailModal
          property={selectedProperty}
          onClose={() => setSelectedProperty(null)}
        />
      )}
    </div>
  );
}

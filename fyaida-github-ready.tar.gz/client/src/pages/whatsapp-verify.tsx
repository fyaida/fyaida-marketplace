import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import {
  MessageSquare,
  RefreshCw,
  CheckCircle,
  XCircle,
  Plus,
  Phone,
  DollarSign,
  Calendar
} from "lucide-react";
import { format } from "date-fns";

export default function WhatsAppVerifyPage() {
  const { toast } = useToast();
  const [whatsappFilter, setWhatsappFilter] = useState<string>("all");
  const [showAddWhatsappPayment, setShowAddWhatsappPayment] = useState(false);
  const [newWhatsappMessage, setNewWhatsappMessage] = useState("");

  // Fetch WhatsApp payments
  const { data: whatsappPayments = [], isLoading: whatsappPaymentsLoading } = useQuery<any[]>({
    queryKey: ["/api/admin/whatsapp-payments", whatsappFilter],
    queryFn: () => {
      const url = whatsappFilter === "all" ? "/api/admin/whatsapp-payments" : `/api/admin/whatsapp-payments?status=${whatsappFilter}`;
      return fetch(url).then(res => res.json());
    },
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'verified':
        return <Badge className="bg-green-100 text-green-800"><CheckCircle className="w-3 h-3 mr-1" />Verified</Badge>;
      case 'rejected':
        return <Badge variant="destructive"><XCircle className="w-3 h-3 mr-1" />Rejected</Badge>;
      case 'matched':
        return <Badge className="bg-blue-100 text-blue-800">Matched</Badge>;
      default:
        return <Badge variant="outline">Unprocessed</Badge>;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex items-center space-x-3 mb-4">
            <MessageSquare className="h-8 w-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-900">Payment Verification Center</h1>
          </div>
          <p className="text-gray-600">All forwarded M-Pesa payment messages are processed here to activate user subscriptions</p>
          <div className="mt-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <h3 className="font-semibold text-blue-900 mb-2">How to Process Payments:</h3>
            <ul className="text-sm text-blue-800 space-y-1">
              <li>• Forward any M-Pesa payment message to this system</li>
              <li>• System automatically extracts receipt codes, amounts, and phone numbers</li>
              <li>• Click "Verify" to activate 90-day unlimited subscription</li>
              <li>• Click "Reject" with reason if payment is invalid</li>
            </ul>
          </div>
        </div>

        {/* Controls */}
        <Card className="mb-6">
          <CardContent className="pt-6">
            <div className="flex items-center space-x-4">
              <select 
                className="px-3 py-2 border rounded-md"
                value={whatsappFilter}
                onChange={(e) => setWhatsappFilter(e.target.value)}
              >
                <option value="all">All Messages</option>
                <option value="unprocessed">Unprocessed</option>
                <option value="matched">Matched</option>
                <option value="verified">Verified</option>
                <option value="rejected">Rejected</option>
              </select>
              <Button
                onClick={() => setShowAddWhatsappPayment(true)}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <Plus className="h-4 w-4 mr-2" />
                Add WhatsApp Message
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Add WhatsApp Message Form */}
        {showAddWhatsappPayment && (
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Forward New WhatsApp Payment Message</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <textarea
                  className="w-full p-3 border rounded-md"
                  rows={6}
                  placeholder="Paste the complete M-Pesa payment message here...

Example:
QHJ4K5L8M9 Confirmed. Ksh300.00 sent to FYAIDA MARKETPLACE 3511028 on 26/6/25 at 4:15 PM. M-PESA balance is Ksh1,250.75. Transaction cost, Ksh0.00. Amount you can transact within the day is 299,700.00. To reverse, forward this message to 456."
                  value={newWhatsappMessage}
                  onChange={(e) => setNewWhatsappMessage(e.target.value)}
                />
                <div className="flex items-center space-x-2">
                  <Button
                    onClick={() => {
                      if (newWhatsappMessage.trim()) {
                        fetch('/api/admin/whatsapp-payment', {
                          method: 'POST',
                          headers: { 'Content-Type': 'application/json' },
                          body: JSON.stringify({ messageText: newWhatsappMessage.trim() })
                        }).then(() => {
                          setShowAddWhatsappPayment(false);
                          setNewWhatsappMessage("");
                          window.location.reload();
                          toast({ title: "WhatsApp message processed successfully" });
                        });
                      }
                    }}
                    disabled={!newWhatsappMessage.trim()}
                  >
                    Process Message
                  </Button>
                  <Button
                    variant="outline"
                    onClick={() => {
                      setShowAddWhatsappPayment(false);
                      setNewWhatsappMessage("");
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* WhatsApp Messages List */}
        <Card>
          <CardHeader>
            <CardTitle>WhatsApp Payment Messages ({whatsappPayments.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {whatsappPaymentsLoading ? (
              <div className="flex items-center justify-center py-8">
                <RefreshCw className="h-6 w-6 animate-spin" />
                <span className="ml-2">Loading WhatsApp messages...</span>
              </div>
            ) : whatsappPayments.length === 0 ? (
              <div className="text-center text-gray-500 py-8">
                <MessageSquare className="h-8 w-8 mx-auto mb-2 text-gray-300" />
                <p>No WhatsApp payment messages found</p>
                <p className="text-sm mt-1">Forward M-Pesa payment messages to verify and activate subscriptions</p>
              </div>
            ) : (
              <div className="space-y-4">
                {whatsappPayments.map((payment) => (
                  <div key={payment.id} className="border rounded-lg p-4 space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <MessageSquare className="h-5 w-5 text-blue-500" />
                        <div>
                          <p className="font-medium">Payment Message #{payment.id}</p>
                          <p className="text-sm text-gray-500">
                            Received {payment.createdAt ? format(new Date(payment.createdAt), 'MMM dd, yyyy HH:mm') : 'Unknown'}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        {getStatusBadge(payment.status)}
                        {payment.status === 'unprocessed' && (
                          <div className="flex items-center space-x-1">
                            <Button
                              size="sm"
                              variant="default"
                              className="bg-green-600 hover:bg-green-700"
                              onClick={() => {
                                const note = prompt("Add verification note:");
                                if (note) {
                                  fetch('/api/admin/verify-whatsapp-payment', {
                                    method: 'POST',
                                    headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify({ paymentId: payment.id, adminNotes: note })
                                  }).then(() => {
                                    window.location.reload();
                                    toast({ title: "Payment verified and subscription activated" });
                                  });
                                }
                              }}
                            >
                              <CheckCircle className="h-4 w-4 mr-1" />
                              Verify
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              onClick={() => {
                                const note = prompt("Add rejection reason:");
                                if (note) {
                                  fetch('/api/admin/reject-whatsapp-payment', {
                                    method: 'POST',
                                    headers: { 'Content-Type': 'application/json' },
                                    body: JSON.stringify({ paymentId: payment.id, adminNotes: note })
                                  }).then(() => {
                                    window.location.reload();
                                    toast({ title: "Payment rejected" });
                                  });
                                }
                              }}
                            >
                              <XCircle className="h-4 w-4 mr-1" />
                              Reject
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 p-3 rounded-md">
                      <p className="text-sm text-gray-700 whitespace-pre-wrap">{payment.messageText}</p>
                    </div>
                    
                    <div className="grid md:grid-cols-2 gap-4 text-sm">
                      <div>
                        {payment.amount && (
                          <p className="flex items-center">
                            <DollarSign className="h-4 w-4 mr-1 text-green-500" />
                            <strong>Amount:</strong> KSH {payment.amount}
                          </p>
                        )}
                        {payment.mpesaCode && (
                          <p><strong>M-Pesa Code:</strong> {payment.mpesaCode}</p>
                        )}
                        {payment.senderPhone && (
                          <p className="flex items-center">
                            <Phone className="h-4 w-4 mr-1 text-blue-500" />
                            <strong>Phone:</strong> {payment.senderPhone}
                          </p>
                        )}
                      </div>
                      <div>
                        {payment.processedAt && (
                          <p className="flex items-center">
                            <Calendar className="h-4 w-4 mr-1 text-gray-500" />
                            <strong>Processed:</strong> {format(new Date(payment.processedAt), 'MMM dd, yyyy HH:mm')}
                          </p>
                        )}
                        {payment.adminNotes && (
                          <p><strong>Notes:</strong> {payment.adminNotes}</p>
                        )}
                        {payment.matchedUserId && (
                          <p><strong>Matched User ID:</strong> {payment.matchedUserId}</p>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
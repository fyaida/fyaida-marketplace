import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Download, Smartphone, Share2, Copy, MessageCircle, Home, ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";

export default function MobileApp() {
  const { toast } = useToast();
  const [downloading, setDownloading] = useState(false);

  const handleDownload = () => {
    setDownloading(true);
    // Simulate download process
    setTimeout(() => {
      setDownloading(false);
      toast({
        title: "Mobile App Ready Soon",
        description: "We're finalizing the mobile app. Use the web version for full functionality now!",
      });
    }, 1500);
  };

  const shareWhatsApp = () => {
    const text = "🏠🚗 Check out Fyaida - Kenya's Premier Property & Vehicle Marketplace!\n\n✅ 5-Day FREE Trial\n✅ Browse Properties & Cars\n✅ Post Ads Easily\n\nVisit: https://fyaida.com\nMobile app coming soon!\n\nWhatsApp: 0722869901";
    const whatsappUrl = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(whatsappUrl, '_blank');
  };

  const copyLink = () => {
    navigator.clipboard.writeText('https://fyaida.com/mobile-app').then(() => {
      toast({
        title: "Link Copied",
        description: "Mobile app link copied to clipboard!",
      });
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50">
      {/* Header with navigation */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-3 flex items-center justify-between">
          <Link href="/">
            <Button variant="ghost" size="sm" className="text-blue-600">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Fyaida
            </Button>
          </Link>
          <h1 className="text-xl font-bold text-gray-900">Mobile App</h1>
          <Link href="/">
            <Button variant="ghost" size="sm">
              <Home className="h-4 w-4" />
            </Button>
          </Link>
        </div>
      </div>

      <div className="container mx-auto px-4 max-w-4xl py-4">
        {/* Hero Download Section - Most Prominent */}
        <div className="bg-gradient-to-r from-green-600 via-green-700 to-emerald-600 text-white rounded-2xl p-8 mb-8 text-center shadow-2xl">
          <div className="flex flex-col items-center space-y-6">
            <div className="w-20 h-20 bg-white/20 rounded-3xl flex items-center justify-center text-5xl backdrop-blur-sm">
              📱
            </div>
            <div>
              <h1 className="text-4xl md:text-5xl font-bold mb-2">Download Fyaida App</h1>
              <p className="text-xl text-green-100 mb-4">Kenya's #1 Property & Vehicle Marketplace</p>
              <Badge className="bg-yellow-400 text-yellow-900 font-semibold px-4 py-1">
                5-Day FREE Trial • Then KSH 300/90 Days
              </Badge>
            </div>
            
            {/* Large Download Button */}
            <div className="space-y-4 w-full max-w-md">
              <Button 
                onClick={handleDownload}
                disabled={downloading}
                size="lg" 
                className="w-full h-16 text-xl font-bold bg-white text-green-700 hover:bg-gray-100 shadow-lg"
              >
                <Download className="mr-3 h-6 w-6" />
                {downloading ? "Checking APK..." : "Download APK Now"}
              </Button>
              
              <p className="text-green-100 text-sm">
                Direct APK download • No Play Store needed • Android 6.0+
              </p>
            </div>
          </div>
        </div>

        {/* PWA Install Section */}
        <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-6 mb-8 text-center">
          <h2 className="text-2xl font-bold text-blue-900 mb-3">Install as Mobile App</h2>
          <p className="text-blue-700 mb-4">Add Fyaida to your home screen for the best mobile experience</p>
          <div className="space-y-3">
            <div className="bg-white rounded-lg p-4 text-left">
              <h3 className="font-semibold text-blue-800 mb-2">Android Users:</h3>
              <p className="text-sm text-gray-600">Chrome will show "Add to Home Screen" option automatically</p>
            </div>
            <div className="bg-white rounded-lg p-4 text-left">
              <h3 className="font-semibold text-blue-800 mb-2">iPhone Users:</h3>
              <p className="text-sm text-gray-600">Tap Share button → "Add to Home Screen"</p>
            </div>
          </div>
          <Link href="/">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white mt-4">
              <Home className="mr-2 h-5 w-5" />
              Open Web App
            </Button>
          </Link>
        </div>

        {/* App Features Grid */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="text-4xl mb-3">🏠</div>
              <h3 className="font-bold text-lg mb-2">Properties</h3>
              <p className="text-gray-600 text-sm">Land, plots, houses across all 47 counties</p>
            </CardContent>
          </Card>
          
          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="text-4xl mb-3">🚗</div>
              <h3 className="font-bold text-lg mb-2">Vehicles</h3>
              <p className="text-gray-600 text-sm">Cars, trucks, motorcycles with detailed specs</p>
            </CardContent>
          </Card>
          
          <Card className="text-center hover:shadow-lg transition-shadow">
            <CardContent className="pt-6">
              <div className="text-4xl mb-3">📋</div>
              <h3 className="font-bold text-lg mb-2">Open Orders</h3>
              <p className="text-gray-600 text-sm">Post what you're looking for and get offers</p>
            </CardContent>
          </Card>
        </div>

        {/* Share Section */}
        <Card className="mb-8">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">
              <Share2 className="mr-2 h-6 w-6 inline" />
              Share Fyaida with Friends
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
              <Button onClick={shareWhatsApp} size="lg" variant="outline" className="text-green-600 border-green-300">
                <MessageCircle className="mr-2 h-5 w-5" />
                WhatsApp
              </Button>
              <Button onClick={copyLink} size="lg" variant="outline">
                <Copy className="mr-2 h-5 w-5" />
                Copy Link  
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Contact Section */}
        <Card className="mt-8 bg-gray-50">
          <CardHeader>
            <CardTitle className="text-center">Get Notified When App is Ready</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-4 text-center">
              <div className="space-y-2">
                <h3 className="font-semibold text-blue-600">📞 WhatsApp Support</h3>
                <p className="text-gray-600">
                  <a href="https://wa.me/254722869901" className="text-green-600 hover:underline">
                    0722 869 901
                  </a>
                </p>
                <p className="text-sm text-gray-500">Available 24/7 for updates</p>
              </div>
              <div className="space-y-2">
                <h3 className="font-semibold text-blue-600">💰 M-Pesa Payments</h3>
                <p className="text-gray-600">Till Number: <strong>3511028</strong></p>
                <p className="text-sm text-gray-500">Secure subscription payments</p>
              </div>
              <div className="space-y-2">
                <h3 className="font-semibold text-blue-600">🏢 Office Location</h3>
                <p className="text-gray-600">Moi Avenue, Nairobi</p>
                <p className="text-sm text-gray-500">Visit us for assistance</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
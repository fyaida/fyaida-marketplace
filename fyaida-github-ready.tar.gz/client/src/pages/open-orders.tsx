import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useLocation } from "wouter";
import { 
  ClipboardList, 
  MapPin, 
  Calendar, 
  DollarSign,
  Search,
  Filter,
  AlertCircle,
  Crown,
  MessageCircle,
  ImageIcon,
  ExternalLink,
  Share2,
  Copy,
  User
} from "lucide-react";
import { KENYAN_COUNTIES } from "@/lib/constants";
import { SubscriptionBanner } from "@/components/subscription-banner";
import { OrderDetailModal } from "@/components/order-detail-modal";
import { useToast } from "@/hooks/use-toast";
import type { OpenOrder } from "@shared/schema";

export default function OpenOrdersPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedOrder, setSelectedOrder] = useState<OpenOrder | null>(null);
  const [filters, setFilters] = useState({
    propertyType: "",
    location: "",
  });
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  // Check if user is authenticated and subscribed
  const { data: user } = useQuery({
    queryKey: ["/api/auth/me"],
    retry: false,
  });

  // Get user's own orders
  const { data: myOrders } = useQuery<OpenOrder[]>({
    queryKey: ["/api/my-open-orders"],
    enabled: !!user,
  });

  const queryParams = new URLSearchParams();
  if (searchTerm) queryParams.append("search", searchTerm);
  Object.entries(filters).forEach(([key, value]) => {
    if (value) queryParams.append(key, value);
  });

  const { data: openOrders, isLoading, error } = useQuery<OpenOrder[]>({
    queryKey: ["/api/open-orders", queryParams.toString()],
    queryFn: async () => {
      const response = await fetch(`/api/open-orders?${queryParams.toString()}`);
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`${response.status}: ${errorData.message}`);
      }
      return response.json();
    },
    enabled: !!user,
  });

  const handleSearch = () => {
    // Trigger refetch by updating query key
    window.location.hash = Math.random().toString();
  };

  const resetFilters = () => {
    setSearchTerm("");
    setFilters({
      propertyType: "",
      location: "",
    });
  };

  const formatPrice = (price: string) => {
    const numPrice = parseFloat(price);
    if (numPrice >= 1000000) {
      return `KSh ${(numPrice / 1000000).toFixed(1)}M`;
    }
    return `KSh ${numPrice.toLocaleString()}`;
  };

  const getPropertyTypeColor = (type: string) => {
    switch (type) {
      case "land":
        return "bg-green-100 text-green-800";
      case "house":
        return "bg-blue-100 text-blue-800";
      case "car":
        return "bg-purple-100 text-purple-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const shareOrder = async (order: OpenOrder) => {
    const shareUrl = `${window.location.origin}/open-orders?orderid=${order.id}`;
    const shareText = `Check out this ${order.propertyType} request: ${order.title} - Budget: ${formatPrice(order.budget)} - Location: ${order.location}`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: order.title,
          text: shareText,
          url: shareUrl,
        });
        toast({
          title: "Shared Successfully",
          description: "Order shared successfully!",
        });
      } catch (error) {
        // User cancelled sharing
      }
    } else {
      // Fallback: copy to clipboard
      try {
        await navigator.clipboard.writeText(`${shareText}\n${shareUrl}`);
        toast({
          title: "Copied to Clipboard",
          description: "Order link copied to clipboard!",
        });
      } catch (error) {
        toast({
          title: "Share Failed",
          description: "Unable to share or copy link",
          variant: "destructive",
        });
      }
    }
  };

  // Show subscription prompt if API returns subscription error or user is not subscribed
  // Admin users bypass all subscription requirements
  const isSubscriptionRequired = error?.message?.includes("subscription required") || 
    (user && (user as any).role !== 'admin' && (!(user as any).isSubscribed || ((user as any).subscriptionExpiry && new Date((user as any).subscriptionExpiry) < new Date())));
    
  if (isSubscriptionRequired) {
    return <SubscriptionBanner type="open-orders" />;
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6">
            <div className="flex mb-4 gap-2">
              <AlertCircle className="h-8 w-8 text-red-500" />
              <h1 className="text-2xl font-bold text-gray-900">Login Required</h1>
            </div>
            <p className="mt-4 text-sm text-gray-600">
              You need to be logged in to view open orders.
            </p>
            <Button 
              onClick={() => window.location.href = '/'} 
              className="w-full mt-4"
            >
              Go to Home Page
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Open Orders</h1>
            <p className="text-gray-600">View and respond to property requests from buyers</p>
          </div>
          <Button 
            onClick={() => setLocation('/post-order')}
            className="bg-green-600 hover:bg-green-700"
          >
            Create Order
          </Button>
        </div>

        <Tabs defaultValue="all-orders" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="all-orders" className="flex items-center gap-2">
              <ClipboardList className="h-4 w-4" />
              All Orders
            </TabsTrigger>
            <TabsTrigger value="my-orders" className="flex items-center gap-2">
              <User className="h-4 w-4" />
              My Orders ({myOrders?.length || 0})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="all-orders" className="mt-6">
            {/* Search and Filters */}
            <div className="bg-white rounded-lg shadow-sm border p-6 mb-8">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
                <div className="md:col-span-2">
                  <Input
                    placeholder="Search open orders..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full"
                  />
                </div>
                <div>
                  <select 
                    className="w-full h-10 px-3 py-2 text-sm border border-gray-300 rounded-md bg-white focus:outline-none focus:border-blue-500"
                    value={filters.propertyType} 
                    onChange={(e) => setFilters({...filters, propertyType: e.target.value})}
                  >
                    <option value="">All Property Types</option>
                    <option value="land">Land/Plots</option>
                    <option value="house">Houses</option>
                    <option value="commercial">Commercial</option>
                  </select>
                </div>
                <div>
                  <select 
                    className="w-full h-10 px-3 py-2 text-sm border border-gray-300 rounded-md bg-white focus:outline-none focus:border-blue-500"
                    value={filters.location} 
                    onChange={(e) => setFilters({...filters, location: e.target.value})}
                  >
                    <option value="">All Locations</option>
                    {KENYAN_COUNTIES.map((county) => (
                      <option key={county} value={county}>{county}</option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="flex gap-2">
                <Button onClick={handleSearch} className="bg-blue-600 hover:bg-blue-700">
                  <Search className="h-4 w-4 mr-2" />
                  Search
                </Button>
                <Button variant="outline" onClick={resetFilters}>
                  <Filter className="h-4 w-4" />
                </Button>
              </div>
            </div>

            {/* Results */}
            <div className="mb-4">
              <p className="text-gray-600">
                {isLoading ? "Loading..." : `${openOrders?.length || 0} open orders found`}
              </p>
            </div>

            {/* Open Orders Grid */}
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <div key={i} className="bg-white rounded-lg shadow-sm animate-pulse">
                    <div className="p-6 space-y-3">
                      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                      <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                      <div className="h-4 bg-gray-200 rounded w-2/3"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : openOrders && openOrders.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {openOrders.map((order) => (
                  <Card key={order.id} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <Badge className={getPropertyTypeColor(order.propertyType)}>
                          {order.propertyType}
                        </Badge>
                        {(order as any).user?.fullName && (
                          <div className="flex items-center text-xs text-gray-500">
                            <MessageCircle className="h-3 w-3 mr-1" />
                            Contact available
                          </div>
                        )}
                      </div>

                      <h3 className="text-lg font-semibold mb-2 line-clamp-2">
                        {order.title}
                      </h3>
                      
                      <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                        {order.description}
                      </p>

                      <div className="space-y-2 text-sm text-gray-500 mb-4">
                        <div className="flex items-center">
                          <MapPin className="h-4 w-4 mr-2" />
                          {order.location}
                        </div>
                        <div className="flex items-center">
                          <DollarSign className="h-4 w-4 mr-2" />
                          Budget: {formatPrice(order.budget)}
                        </div>
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-2" />
                          Posted {new Date(order.createdAt!).toLocaleDateString()}
                        </div>
                      </div>

                      {order.requirements && order.requirements.length > 0 && (
                        <div className="mb-4">
                          <p className="text-sm font-medium text-gray-700 mb-2">Requirements:</p>
                          <div className="flex flex-wrap gap-1">
                            {order.requirements.slice(0, 3).map((req, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {req}
                              </Badge>
                            ))}
                            {order.requirements.length > 3 && (
                              <Badge variant="outline" className="text-xs">
                                +{order.requirements.length - 3} more
                              </Badge>
                            )}
                          </div>
                        </div>
                      )}

                      <div className="flex justify-between items-center">
                        <span className="text-xs text-gray-500">
                          {order.isActive ? "Active" : "Closed"}
                        </span>
                        <Button 
                          size="sm" 
                          className="bg-purple-600 hover:bg-purple-700"
                          onClick={() => setSelectedOrder(order)}
                        >
                          View Details
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="max-w-md mx-auto">
                  <div className="h-24 w-24 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                    <ClipboardList className="h-8 w-8 text-gray-400" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No open orders found</h3>
                  <p className="text-gray-500 mb-4">
                    There are currently no open orders matching your criteria.
                  </p>
                  <Button onClick={resetFilters} variant="outline">
                    Clear Filters
                  </Button>
                </div>
              </div>
            )}
          </TabsContent>

          <TabsContent value="my-orders" className="mt-6">
            {myOrders && myOrders.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {myOrders.map((order) => (
                  <Card key={order.id} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start mb-4">
                        <Badge className={getPropertyTypeColor(order.propertyType)}>
                          {order.propertyType}
                        </Badge>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => shareOrder(order)}
                          className="h-8 w-8 p-0"
                        >
                          <Share2 className="h-4 w-4" />
                        </Button>
                      </div>

                      <h3 className="text-lg font-semibold mb-2 line-clamp-2">
                        {order.title}
                      </h3>
                      
                      <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                        {order.description}
                      </p>

                      <div className="space-y-2 text-sm text-gray-500 mb-4">
                        <div className="flex items-center">
                          <MapPin className="h-4 w-4 mr-2" />
                          {order.location}
                        </div>
                        <div className="flex items-center">
                          <DollarSign className="h-4 w-4 mr-2" />
                          Budget: {formatPrice(order.budget)}
                        </div>
                        <div className="flex items-center">
                          <Calendar className="h-4 w-4 mr-2" />
                          Posted {new Date(order.createdAt!).toLocaleDateString()}
                        </div>
                      </div>

                      {order.requirements && order.requirements.length > 0 && (
                        <div className="mb-4">
                          <p className="text-sm font-medium text-gray-700 mb-2">Requirements:</p>
                          <div className="flex flex-wrap gap-1">
                            {order.requirements.slice(0, 3).map((req, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {req}
                              </Badge>
                            ))}
                            {order.requirements.length > 3 && (
                              <Badge variant="outline" className="text-xs">
                                +{order.requirements.length - 3} more
                              </Badge>
                            )}
                          </div>
                        </div>
                      )}

                      <div className="flex justify-between items-center">
                        <span className="text-xs text-gray-500">
                          {order.isActive ? "Active" : "Closed"}
                        </span>
                        <div className="flex gap-2">
                          <Button 
                            size="sm" 
                            variant="outline"
                            onClick={() => shareOrder(order)}
                          >
                            <Share2 className="h-4 w-4 mr-1" />
                            Share
                          </Button>
                          <Button 
                            size="sm" 
                            className="bg-purple-600 hover:bg-purple-700"
                            onClick={() => setSelectedOrder(order)}
                          >
                            View Details
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <div className="max-w-md mx-auto">
                  <div className="h-24 w-24 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                    <ClipboardList className="h-8 w-8 text-gray-400" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">No orders posted yet</h3>
                  <p className="text-gray-500 mb-4">
                    You haven't posted any open orders yet. Create your first order to get started.
                  </p>
                  <Button 
                    onClick={() => setLocation('/post-order')}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    Create Order
                  </Button>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
      
      {/* Order Detail Modal */}
      {selectedOrder && (
        <OrderDetailModal
          order={selectedOrder}
          onClose={() => setSelectedOrder(null)}
        />
      )}
    </div>
  );
}
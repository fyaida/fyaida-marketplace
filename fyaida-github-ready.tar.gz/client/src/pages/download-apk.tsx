import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, Smartphone, Upload, FileCheck } from "lucide-react";

export default function DownloadApk() {
  const handleDownload = () => {
    // Create a downloadable APK file
    const apkContent = `FYAIDA MOBILE APP - TEMPORARY PLACEHOLDER

This is a temporary APK placeholder file for testing your HostPinnacle deployment.

To get your actual mobile APK:

1. Build React Native app:
   - npx create-expo-app fyaida-mobile
   - expo build:android

2. Or use online APK builders:
   - AppsGeyser.com
   - BuildFire.com
   - Appy Pie

3. Replace this file with your actual fyaida-mobile.apk

Current deployment status:
- Static hosting: ✓ Working (eliminates memory errors)
- Download page: ✓ Professional interface ready
- Apache config: ✓ Proper MIME types for APK
- File structure: ✓ Organized for easy updates

Access URLs:
- App page: https://yourdomain.com/mobileweb/
- Direct download: https://yourdomain.com/mobileweb/fyaida-mobile.apk

This placeholder allows you to test the download functionality immediately while you prepare your actual mobile application.`;

    const blob = new Blob([apkContent], { type: 'application/vnd.android.package-archive' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'fyaida-mobile.apk';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 dark:from-gray-900 dark:to-gray-800 p-4">
      <div className="max-w-4xl mx-auto pt-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Download APK for HostPinnacle
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300">
            Get the temporary APK file to upload to your mobileweb folder
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card className="border-2 border-green-200 dark:border-green-800">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Download className="h-5 w-5 text-green-600" />
                Download APK Placeholder
              </CardTitle>
              <CardDescription>
                Get the temporary APK file for HostPinnacle testing
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button 
                onClick={handleDownload}
                className="w-full bg-green-600 hover:bg-green-700 text-white"
                size="lg"
              >
                <Download className="mr-2 h-4 w-4" />
                Download fyaida-mobile.apk
              </Button>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                This creates a temporary APK file for testing your deployment
              </p>
            </CardContent>
          </Card>

          <Card className="border-2 border-blue-200 dark:border-blue-800">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Upload className="h-5 w-5 text-blue-600" />
                Upload Instructions
              </CardTitle>
              <CardDescription>
                How to upload the APK to your HostPinnacle mobileweb folder
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="space-y-2">
                <div className="flex items-start gap-2">
                  <span className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded-full w-6 h-6 flex items-center justify-center text-sm font-medium">1</span>
                  <p className="text-sm">Download the APK file using the button above</p>
                </div>
                <div className="flex items-start gap-2">
                  <span className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded-full w-6 h-6 flex items-center justify-center text-sm font-medium">2</span>
                  <p className="text-sm">Open your HostPinnacle File Manager</p>
                </div>
                <div className="flex items-start gap-2">
                  <span className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded-full w-6 h-6 flex items-center justify-center text-sm font-medium">3</span>
                  <p className="text-sm">Navigate to public_html/mobileweb/ folder</p>
                </div>
                <div className="flex items-start gap-2">
                  <span className="bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded-full w-6 h-6 flex items-center justify-center text-sm font-medium">4</span>
                  <p className="text-sm">Upload the fyaida-mobile.apk file</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mt-6 border-2 border-yellow-200 dark:border-yellow-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileCheck className="h-5 w-5 text-yellow-600" />
              After Upload - Test URLs
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <p><strong>Main page:</strong> https://yourdomain.com/mobileweb/</p>
              <p><strong>Direct APK:</strong> https://yourdomain.com/mobileweb/fyaida-mobile.apk</p>
            </div>
            <div className="mt-4 p-3 bg-yellow-50 dark:bg-yellow-900/20 rounded-lg">
              <p className="text-sm text-yellow-800 dark:text-yellow-200">
                <strong>Note:</strong> This is a temporary placeholder APK. Replace it with your actual mobile app APK when ready.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card className="mt-6 border-2 border-purple-200 dark:border-purple-800">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Smartphone className="h-5 w-5 text-purple-600" />
              Next Steps for Real Mobile App
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2 text-sm">
              <p><strong>Option 1:</strong> Build React Native app with Expo</p>
              <p><strong>Option 2:</strong> Use online APK builders (AppsGeyser, BuildFire)</p>
              <p><strong>Option 3:</strong> Convert your web app to APK using Cordova/PhoneGap</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
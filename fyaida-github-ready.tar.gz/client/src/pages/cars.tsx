import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { CarCard } from "@/components/car-card";
import { DueDiligenceWarning } from "@/components/due-diligence-warning";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Filter } from "lucide-react";
import { CAR_MAKES, CAR_MODELS, CAR_CONDITIONS, KENYAN_COUNTIES } from "@/lib/constants";
import type { Car } from "@shared/schema";

export default function CarsPage() {
  const [searchTerm, setSearchTerm] = useState("");
  const [filters, setFilters] = useState({
    make: "",
    model: "",
    minYear: "",
    maxYear: "",
    minPrice: "",
    maxPrice: "",
    location: "",
    condition: "",
  });

  const queryParams = new URLSearchParams();
  if (searchTerm) queryParams.append("search", searchTerm);
  Object.entries(filters).forEach(([key, value]) => {
    if (value) queryParams.append(key, value);
  });

  const { data: cars, isLoading } = useQuery<Car[]>({
    queryKey: ["/api/cars", queryParams.toString()],
    queryFn: () => fetch(`/api/cars?${queryParams.toString()}`).then(res => res.json()),
  });

  const handleSearch = () => {
    // Trigger refetch by updating query key
    window.location.hash = Math.random().toString();
  };

  const resetFilters = () => {
    setSearchTerm("");
    setFilters({
      make: "",
      model: "",
      minYear: "",
      maxYear: "",
      minPrice: "",
      maxPrice: "",
      location: "",
      condition: "",
    });
  };

  const availableModels = filters.make ? CAR_MODELS[filters.make] || [] : [];

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Cars</h1>
          <p className="text-gray-600">Find your perfect car in Kenya</p>
        </div>

        {/* Due Diligence Warning */}
        <DueDiligenceWarning />

        {/* Search and Filters */}
        <div className="bg-white rounded-lg shadow-sm border p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-4">
            <div className="md:col-span-2">
              <Input
                placeholder="Search cars..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
              />
            </div>
            <div>
              <select 
                className="w-full h-10 px-3 py-2 text-sm border border-gray-300 rounded-md bg-white focus:outline-none focus:border-blue-500"
                value={filters.make} 
                onChange={(e) => setFilters({...filters, make: e.target.value, model: ""})}
              >
                <option value="">All Makes</option>
                {CAR_MAKES.map((make) => (
                  <option key={make} value={make}>
                    {make}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <select 
                className="w-full h-10 px-3 py-2 text-sm border border-gray-300 rounded-md bg-white focus:outline-none focus:border-blue-500"
                value={filters.model} 
                onChange={(e) => setFilters({...filters, model: e.target.value})}
              >
                <option value="">All Models</option>
                {availableModels.map((model) => (
                  <option key={model} value={model}>
                    {model}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-6 gap-4 mb-4">
            <div>
              <select 
                className="w-full h-10 px-3 py-2 text-sm border border-gray-300 rounded-md bg-white focus:outline-none focus:border-blue-500"
                value={filters.location} 
                onChange={(e) => setFilters({...filters, location: e.target.value})}
              >
                <option value="">All Counties</option>
                {KENYAN_COUNTIES.map((county) => (
                  <option key={county} value={county}>
                    {county}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <Input
                placeholder="Min Year"
                type="number"
                value={filters.minYear}
                onChange={(e) => setFilters({...filters, minYear: e.target.value})}
              />
            </div>
            <div>
              <Input
                placeholder="Max Year"
                type="number"
                value={filters.maxYear}
                onChange={(e) => setFilters({...filters, maxYear: e.target.value})}
              />
            </div>
            <div>
              <Input
                placeholder="Min Price"
                type="number"
                value={filters.minPrice}
                onChange={(e) => setFilters({...filters, minPrice: e.target.value})}
              />
            </div>
            <div>
              <Input
                placeholder="Max Price"
                type="number"
                value={filters.maxPrice}
                onChange={(e) => setFilters({...filters, maxPrice: e.target.value})}
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={handleSearch} className="flex-1">
                <Search className="h-4 w-4 mr-2" />
                Search
              </Button>
              <Button variant="outline" onClick={resetFilters}>
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="mb-4 flex justify-between items-center">
          <p className="text-gray-600">
            {isLoading ? "Loading..." : `${cars?.length || 0} cars found`}
          </p>
          <select className="w-48 h-10 px-3 py-2 text-sm border border-gray-300 rounded-md bg-white focus:outline-none focus:border-blue-500">
            <option value="">Sort by</option>
            <option value="newest">Newest First</option>
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
            <option value="year-new">Year: Newest First</option>
            <option value="year-old">Year: Oldest First</option>
          </select>
        </div>

        {/* Cars Grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="bg-white rounded-lg shadow-sm animate-pulse">
                <div className="h-48 bg-gray-200 rounded-t-lg"></div>
                <div className="p-4 space-y-3">
                  <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                  <div className="h-4 bg-gray-200 rounded w-2/3"></div>
                </div>
              </div>
            ))}
          </div>
        ) : cars && cars.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {cars.map((car) => (
              <CarCard key={car.id} car={car} />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <div className="max-w-md mx-auto">
              <div className="h-24 w-24 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                <Search className="h-8 w-8 text-gray-400" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No cars found</h3>
              <p className="text-gray-500 mb-4">
                Try adjusting your search criteria or browse all cars.
              </p>
              <Button onClick={resetFilters} variant="outline">
                Clear Filters
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

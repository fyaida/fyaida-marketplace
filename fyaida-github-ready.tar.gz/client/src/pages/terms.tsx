import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, Shield, Eye, Phone, MapPin, FileText, Users, Clock } from "lucide-react";

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold text-gray-900 mb-4">Terms and Conditions</h1>
          <p className="text-lg text-gray-600">
            Important guidelines for safe property transactions in Kenya
          </p>
        </div>

        {/* Due Diligence Warning */}
        <Card className="mb-8 border-red-200 bg-red-50">
          <CardHeader>
            <CardTitle className="flex items-center text-red-800">
              <AlertTriangle className="h-6 w-6 mr-2" />
              Critical Due Diligence Requirements
            </CardTitle>
          </CardHeader>
          <CardContent className="text-red-700">
            <p className="font-semibold mb-4">
              MANDATORY: Conduct thorough due diligence before committing to any property transaction.
            </p>
            <ul className="space-y-2">
              <li className="flex items-start">
                <Eye className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                <span>Physically visit and inspect the property before making any commitments</span>
              </li>
              <li className="flex items-start">
                <FileText className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                <span>Verify all property documents including title deeds, search certificates, and planning approvals</span>
              </li>
              <li className="flex items-start">
                <Users className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                <span>Meet the advertiser in person and verify their identity and ownership</span>
              </li>
              <li className="flex items-start">
                <Shield className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
                <span>Engage qualified professionals (lawyers, surveyors, valuers) for verification</span>
              </li>
            </ul>
          </CardContent>
        </Card>

        {/* Terms Sections */}
        <div className="space-y-6">
          {/* Platform Purpose */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <MapPin className="h-5 w-5 mr-2" />
                Platform Purpose
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 leading-relaxed">
                Fyaida.com is a digital marketplace platform connecting property advertisers with potential buyers, 
                sellers, and tenants in Kenya. We facilitate connections but do not guarantee the accuracy of 
                listings or participate in transactions.
              </p>
            </CardContent>
          </Card>

          {/* User Responsibilities */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="h-5 w-5 mr-2" />
                User Responsibilities
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">For Property Seekers:</h4>
                <ul className="list-disc list-inside space-y-1 text-gray-700">
                  <li>Conduct independent verification of all property information</li>
                  <li>Visit properties personally before making decisions</li>
                  <li>Verify advertiser credentials and ownership documents</li>
                  <li>Use qualified legal and technical professionals</li>
                  <li>Report suspicious or fraudulent listings immediately</li>
                </ul>
              </div>
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">For Property Advertisers:</h4>
                <ul className="list-disc list-inside space-y-1 text-gray-700">
                  <li>Provide accurate and truthful property information</li>
                  <li>Possess valid ownership or authorization to advertise</li>
                  <li>Respond promptly to genuine inquiries</li>
                  <li>Comply with Kenyan property laws and regulations</li>
                  <li>Update or remove listings when properties are no longer available</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Property Verification Checklist */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <FileText className="h-5 w-5 mr-2" />
                Essential Property Verification Checklist
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Legal Documents:</h4>
                  <ul className="list-disc list-inside space-y-1 text-gray-700">
                    <li>Original title deed</li>
                    <li>Current search certificate</li>
                    <li>Planning approval (if applicable)</li>
                    <li>Building approval (for developments)</li>
                    <li>Rate clearance certificate</li>
                    <li>No objection certificate (if leasehold)</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 mb-2">Physical Inspection:</h4>
                  <ul className="list-disc list-inside space-y-1 text-gray-700">
                    <li>Property boundaries and measurements</li>
                    <li>Structural condition assessment</li>
                    <li>Infrastructure availability (water, electricity)</li>
                    <li>Access roads and transportation</li>
                    <li>Neighborhood security and amenities</li>
                    <li>Environmental factors and risks</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Platform Limitations */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <AlertTriangle className="h-5 w-5 mr-2" />
                Platform Limitations
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-gray-700">
              <p>
                <strong>No Verification:</strong> We do not independently verify property listings, 
                advertiser credentials, or ownership claims.
              </p>
              <p>
                <strong>No Transaction Participation:</strong> All negotiations and transactions 
                occur directly between users. We are not party to any agreements.
              </p>
              <p>
                <strong>No Liability:</strong> We disclaim liability for property condition, 
                legal disputes, financial losses, or fraudulent activities.
              </p>
              <p>
                <strong>Information Accuracy:</strong> Users are responsible for verifying 
                all information independently.
              </p>
            </CardContent>
          </Card>

          {/* Fraud Prevention */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="h-5 w-5 mr-2" />
                Fraud Prevention Guidelines
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-gray-700">
              <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
                <h4 className="font-semibold text-yellow-800 mb-2">Red Flags to Watch:</h4>
                <ul className="list-disc list-inside space-y-1 text-yellow-700">
                  <li>Unusually low prices compared to market rates</li>
                  <li>Pressure for immediate payment or decisions</li>
                  <li>Reluctance to meet in person or show property</li>
                  <li>Requests for upfront payments without documentation</li>
                  <li>Incomplete or suspicious documentation</li>
                  <li>Advertisers unwilling to verify identity</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Payment Safety */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Phone className="h-5 w-5 mr-2" />
                Safe Payment Practices
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-gray-700">
              <ul className="list-disc list-inside space-y-1">
                <li>Never make payments before thorough verification</li>
                <li>Use secure payment methods with proper documentation</li>
                <li>Involve qualified lawyers for legal document preparation</li>
                <li>Ensure all payments are receipted and recorded</li>
                <li>Verify bank account ownership before transfers</li>
                <li>Be cautious of mobile money transactions with unknown parties</li>
              </ul>
            </CardContent>
          </Card>

          {/* Contact Information */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Phone className="h-5 w-5 mr-2" />
                Support and Reporting
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-gray-700">
              <p>
                <strong>WhatsApp:</strong> 0722869901<br />
                <strong>Office:</strong> Moi Avenue, Nairobi<br />
                <strong>M-Pesa Till:</strong> 3511028 (for subscription payments only)
              </p>
              <p className="text-sm text-gray-600">
                Report suspicious listings or fraudulent activities immediately for investigation.
              </p>
            </CardContent>
          </Card>

          {/* Legal Disclaimer */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Clock className="h-5 w-5 mr-2" />
                Legal Disclaimer
              </CardTitle>
            </CardHeader>
            <CardContent className="text-gray-700 space-y-3">
              <p>
                By using this platform, you acknowledge that property transactions involve 
                significant financial and legal risks. You agree to conduct independent due 
                diligence and assume full responsibility for your decisions.
              </p>
              <p>
                This platform operates under Kenyan law. Users are advised to comply with 
                all applicable laws and regulations governing property transactions in Kenya.
              </p>
              <p className="text-sm text-gray-600">
                Last updated: June 27, 2025
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
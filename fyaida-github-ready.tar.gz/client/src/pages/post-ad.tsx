import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Form,
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import {
  PROPERTY_TYPES,
  LISTING_TYPES,
  CAR_MAKES,
  CAR_MODELS,
  CAR_CONDITIONS,
  PAYMENT_METHODS,
  KENYAN_COUNTIES,
} from "@/lib/constants";
import { Plus, X, Home, Car, AlertCircle } from "lucide-react";
import { LocationSelector } from "@/components/location-selector";
import { ImageGalleryPicker } from "@/components/image-gallery-picker";
import { SubscriptionBanner } from "@/components/subscription-banner";

const propertySchema = z.object({
  title: z.string().min(5, "Title must be at least 5 characters"),
  description: z.string().min(20, "Description must be at least 20 characters"),
  type: z.enum(["land", "house"]),
  listingType: z.enum(["sale", "rent", "lease"]),
  price: z.string().min(1, "Price is required"),
  location: z.string().min(1, "Location is required"),
  bedrooms: z.number().optional(),
  bathrooms: z.number().optional(),
  parking: z.number().optional(),
  size: z.string().optional(),
  amenities: z.array(z.string()).default([]),
  images: z.array(z.string()).default([]),
});

const carSchema = z.object({
  title: z.string().min(5, "Title must be at least 5 characters"),
  make: z.string().min(1, "Car make is required"),
  model: z.string().min(1, "Car model is required"),
  year: z.number().min(1980, "Year must be 1980 or later").max(new Date().getFullYear() + 1),
  engineSize: z.string().min(1, "Engine size is required"),
  mileage: z.number().optional(),
  condition: z.enum(["excellent", "good", "fair", "poor"]),
  price: z.string().min(1, "Price is required"),
  paymentMethod: z.enum(["cash", "installments"]),
  installmentAmount: z.string().optional(),
  installmentDuration: z.number().optional(),
  location: z.string().min(1, "Location is required"),
  description: z.string().min(20, "Description must be at least 20 characters"),
  images: z.array(z.string()).default([]),
  showRegistration: z.boolean().default(true),
});

type PropertyFormData = z.infer<typeof propertySchema>;
type CarFormData = z.infer<typeof carSchema>;

export default function PostAdPage() {
  const [activeTab, setActiveTab] = useState("property");
  const [newAmenity, setNewAmenity] = useState("");
  const [newImageUrl, setNewImageUrl] = useState("");
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();

  // Check if user is authenticated
  const { data: user } = useQuery({
    queryKey: ["/api/auth/me"],
    retry: false,
  });

  // Check trial status and subscription for posting
  const isTrialUser = user && user.user && user.user.role !== 'admin' && 
    (!user.user.isSubscribed || (user.user.subscriptionExpiry && new Date(user.user.subscriptionExpiry) < new Date()));
  
  const getTrialDaysRemaining = () => {
    if (!user?.user?.createdAt) return 0;
    const createdAt = new Date(user.user.createdAt);
    const trialEndDate = new Date(createdAt);
    trialEndDate.setDate(trialEndDate.getDate() + 5);
    const daysRemaining = Math.ceil((trialEndDate.getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24));
    return Math.max(0, daysRemaining);
  };

  const propertyForm = useForm<PropertyFormData>({
    resolver: zodResolver(propertySchema),
    defaultValues: {
      amenities: [],
      images: [],
      bedrooms: undefined,
      bathrooms: undefined,
      parking: undefined,
    },
  });

  const carForm = useForm<CarFormData>({
    resolver: zodResolver(carSchema),
    defaultValues: {
      images: [],
      showRegistration: true,
      mileage: undefined,
      installmentAmount: undefined,
      installmentDuration: undefined,
    },
  });

  const propertyMutation = useMutation({
    mutationFn: (data: PropertyFormData) => apiRequest("POST", "/api/properties", data),
    onSuccess: () => {
      toast({
        title: "Property posted successfully!",
        description: "Your property listing has been created.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/properties"] });
      setLocation("/properties");
    },
    onError: (error: any) => {
      if (error.message.includes("trial expired") || error.message.includes("trialExpired")) {
        toast({
          title: "5-Day Trial Expired",
          description: "Subscribe for KSH 300 to continue posting properties.",
          variant: "destructive",
        });
        setLocation("/subscription");
      } else if (error.message.includes("subscription required") || error.message.includes("requiresSubscription")) {
        toast({
          title: "Subscription Required",
          description: "Subscribe for KSH 300 to post properties and access premium features.",
          variant: "destructive",
        });
        setLocation("/subscription");
      } else {
        toast({
          title: "Failed to post property",
          description: error.message,
          variant: "destructive",
        });
      }
    },
  });

  const carMutation = useMutation({
    mutationFn: (data: CarFormData) => apiRequest("POST", "/api/cars", data),
    onSuccess: () => {
      toast({
        title: "Car posted successfully!",
        description: "Your car listing has been created.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/cars"] });
      setLocation("/cars");
    },
    onError: (error: any) => {
      if (error.message.includes("trial expired") || error.message.includes("trialExpired")) {
        toast({
          title: "5-Day Trial Expired",
          description: "Subscribe for KSH 300 to continue posting cars.",
          variant: "destructive",
        });
        setLocation("/subscription");
      } else if (error.message.includes("subscription required") || error.message.includes("requiresSubscription")) {
        toast({
          title: "Subscription Required",
          description: "Subscribe for KSH 300 to post cars and access premium features.",
          variant: "destructive",
        });
        setLocation("/subscription");
      } else {
        toast({
          title: "Failed to post car",
          description: error.message,
          variant: "destructive",
        });
      }
    },
  });

  const addAmenity = () => {
    if (newAmenity.trim()) {
      const currentAmenities = propertyForm.getValues("amenities");
      propertyForm.setValue("amenities", [...currentAmenities, newAmenity.trim()]);
      setNewAmenity("");
    }
  };

  const removeAmenity = (index: number) => {
    const currentAmenities = propertyForm.getValues("amenities");
    propertyForm.setValue("amenities", currentAmenities.filter((_, i) => i !== index));
  };

  const addImage = (formType: "property" | "car") => {
    if (newImageUrl.trim()) {
      if (formType === "property") {
        const currentImages = propertyForm.getValues("images");
        propertyForm.setValue("images", [...currentImages, newImageUrl.trim()]);
      } else {
        const currentImages = carForm.getValues("images");
        carForm.setValue("images", [...currentImages, newImageUrl.trim()]);
      }
      setNewImageUrl("");
    }
  };

  const removeImage = (index: number, formType: "property" | "car") => {
    if (formType === "property") {
      const currentImages = propertyForm.getValues("images");
      propertyForm.setValue("images", currentImages.filter((_, i) => i !== index));
    } else {
      const currentImages = carForm.getValues("images");
      carForm.setValue("images", currentImages.filter((_, i) => i !== index));
    }
  };

  const availableModels = carForm.watch("make") ? CAR_MODELS[carForm.watch("make")] || [] : [];

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6">
            <div className="flex mb-4 gap-2">
              <AlertCircle className="h-8 w-8 text-red-500" />
              <h1 className="text-2xl font-bold text-gray-900">Login Required</h1>
            </div>
            <p className="mt-4 text-sm text-gray-600">
              You need to be logged in to post advertisements.
            </p>
            <Button 
              onClick={() => setLocation("/")} 
              className="w-full mt-4"
            >
              Go to Home Page
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Post an Advertisement</h1>
          <p className="text-gray-600">Create a listing for your property or car</p>
        </div>

        {/* Trial Status Banner */}
        {isTrialUser && user?.user && (
          <Card className="mb-6 bg-gradient-to-r from-blue-50 to-green-50 border-blue-200">
            <CardContent className="pt-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className="bg-green-100 p-2 rounded-full">
                    <AlertCircle className="h-5 w-5 text-green-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">
                      {getTrialDaysRemaining() > 0 ? `${getTrialDaysRemaining()} Days Trial Remaining` : "Trial Expired"}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {getTrialDaysRemaining() > 0 
                        ? "Post listings for free during your trial period"
                        : "Subscribe to continue posting listings"
                      }
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <Button 
                    variant="outline" 
                    size="sm"
                    onClick={() => setLocation('/subscription')}
                    className="text-primary border-primary hover:bg-primary hover:text-white"
                  >
                    Upgrade Now
                  </Button>
                  <p className="text-xs text-gray-500 mt-1">KSH 300 • 90 days</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="property" className="flex items-center gap-2">
              <Home className="h-4 w-4" />
              Property
            </TabsTrigger>
            <TabsTrigger value="car" className="flex items-center gap-2">
              <Car className="h-4 w-4" />
              Car
            </TabsTrigger>
          </TabsList>

          <TabsContent value="property">
            <Card>
              <CardHeader>
                <CardTitle>Property Listing</CardTitle>
              </CardHeader>
              <CardContent>
                <Form {...propertyForm}>
                  <form onSubmit={propertyForm.handleSubmit((data) => propertyMutation.mutate(data))} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={propertyForm.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Property Title</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g., Modern 3BR House in Karen" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={propertyForm.control}
                        name="type"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Property Type</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select property type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {PROPERTY_TYPES.map((type) => (
                                  <SelectItem key={type.value} value={type.value}>
                                    {type.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={propertyForm.control}
                        name="listingType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Listing Type</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select listing type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {LISTING_TYPES.map((type) => (
                                  <SelectItem key={type.value} value={type.value}>
                                    {type.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={propertyForm.control}
                        name="price"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Price (KSh)</FormLabel>
                            <FormControl>
                              <Input type="number" placeholder="e.g., 5000000" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={propertyForm.control}
                        name="location"
                        render={({ field }) => (
                          <FormItem>
                            <FormControl>
                              <LocationSelector
                                value={field.value}
                                onChange={field.onChange}
                                label="Location"
                                placeholder="e.g., Kiambu - Limuru, Nairobi - Kamulu"
                                required
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={propertyForm.control}
                        name="size"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Size</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g., 0.5 acres or 150 sqm" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    {propertyForm.watch("type") === "house" && (
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <FormField
                          control={propertyForm.control}
                          name="bedrooms"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Bedrooms</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  placeholder="e.g., 3" 
                                  {...field}
                                  onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={propertyForm.control}
                          name="bathrooms"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Bathrooms</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  placeholder="e.g., 2" 
                                  {...field}
                                  onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={propertyForm.control}
                          name="parking"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Parking Spaces</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  placeholder="e.g., 2" 
                                  {...field}
                                  onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    )}

                    <FormField
                      control={propertyForm.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Describe your property in detail..."
                              className="min-h-[120px]"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Amenities */}
                    <div>
                      <FormLabel>Amenities</FormLabel>
                      <div className="flex gap-2 mt-2">
                        <Input
                          placeholder="Add amenity"
                          value={newAmenity}
                          onChange={(e) => setNewAmenity(e.target.value)}
                          onKeyPress={(e) => e.key === "Enter" && (e.preventDefault(), addAmenity())}
                        />
                        <Button type="button" onClick={addAmenity} size="sm">
                          <Plus className="h-4 w-4" />
                        </Button>
                      </div>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {propertyForm.watch("amenities").map((amenity, index) => (
                          <Badge key={index} variant="secondary" className="flex items-center gap-1">
                            {amenity}
                            <X 
                              className="h-3 w-3 cursor-pointer" 
                              onClick={() => removeAmenity(index)}
                            />
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {/* Images */}
                    <FormField
                      control={propertyForm.control}
                      name="images"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <ImageGalleryPicker
                              images={field.value}
                              onImagesChange={field.onChange}
                              maxImages={8}
                              label="Property Images"
                              allowUrlInput={true}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button 
                      type="submit" 
                      className="w-full" 
                      disabled={propertyMutation.isPending}
                    >
                      {propertyMutation.isPending ? "Posting..." : "Post Property"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="car">
            <Card>
              <CardHeader>
                <CardTitle>Car Listing</CardTitle>
              </CardHeader>
              <CardContent>
                <Form {...carForm}>
                  <form onSubmit={carForm.handleSubmit((data) => carMutation.mutate(data))} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={carForm.control}
                        name="title"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Car Title</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g., Toyota Camry 2018" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={carForm.control}
                        name="make"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Make</FormLabel>
                            <Select onValueChange={(value) => {
                              field.onChange(value);
                              carForm.setValue("model", "");
                            }} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select car make" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {CAR_MAKES.map((make) => (
                                  <SelectItem key={make} value={make}>
                                    {make}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={carForm.control}
                        name="model"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Model</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select car model" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {availableModels.map((model) => (
                                  <SelectItem key={model} value={model}>
                                    {model}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={carForm.control}
                        name="year"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Year</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="e.g., 2018" 
                                {...field}
                                onChange={(e) => field.onChange(Number(e.target.value))}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={carForm.control}
                        name="engineSize"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Engine Size</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g., 2.4L" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={carForm.control}
                        name="mileage"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Mileage (KM)</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                placeholder="e.g., 95000" 
                                {...field}
                                onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={carForm.control}
                        name="condition"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Condition</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select condition" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {CAR_CONDITIONS.map((condition) => (
                                  <SelectItem key={condition.value} value={condition.value}>
                                    {condition.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={carForm.control}
                        name="location"
                        render={({ field }) => (
                          <FormItem>
                            <FormControl>
                              <LocationSelector
                                value={field.value}
                                onChange={field.onChange}
                                label="Location"
                                placeholder="e.g., Kiambu - Limuru, Nairobi - Kamulu"
                                required
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={carForm.control}
                        name="price"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Price (KSh)</FormLabel>
                            <FormControl>
                              <Input type="number" placeholder="e.g., 1800000" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={carForm.control}
                        name="paymentMethod"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Payment Method</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select payment method" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {PAYMENT_METHODS.map((method) => (
                                  <SelectItem key={method.value} value={method.value}>
                                    {method.label}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    {carForm.watch("paymentMethod") === "installments" && (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField
                          control={carForm.control}
                          name="installmentAmount"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Monthly Installment (KSh)</FormLabel>
                              <FormControl>
                                <Input type="number" placeholder="e.g., 45000" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={carForm.control}
                          name="installmentDuration"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Duration (Months)</FormLabel>
                              <FormControl>
                                <Input 
                                  type="number" 
                                  placeholder="e.g., 48" 
                                  {...field}
                                  onChange={(e) => field.onChange(e.target.value ? Number(e.target.value) : undefined)}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                    )}

                    <FormField
                      control={carForm.control}
                      name="description"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Description</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Describe your car in detail..."
                              className="min-h-[120px]"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={carForm.control}
                      name="showRegistration"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                          <FormControl>
                            <Checkbox
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>
                              Show car registration in listing
                            </FormLabel>
                          </div>
                        </FormItem>
                      )}
                    />

                    {/* Images */}
                    <FormField
                      control={carForm.control}
                      name="images"
                      render={({ field }) => (
                        <FormItem>
                          <FormControl>
                            <ImageGalleryPicker
                              images={field.value}
                              onImagesChange={field.onChange}
                              maxImages={8}
                              label="Car Images"
                              allowUrlInput={true}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <Button 
                      type="submit" 
                      className="w-full" 
                      disabled={carMutation.isPending}
                    >
                      {carMutation.isPending ? "Posting..." : "Post Car"}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

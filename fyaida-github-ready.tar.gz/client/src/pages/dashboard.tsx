import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { 
  Home, 
  Car, 
  ClipboardList, 
  Users, 
  DollarSign, 
  TrendingUp,
  Eye,
  Edit,
  Trash2,
  Plus,
  MessageSquare,
  Share2,
  CreditCard,
  CheckCircle,
  XCircle,
  UserCheck,
  UserX,
  Smartphone,
  Globe,
  Shield
} from "lucide-react";
import { useLocation } from "wouter";
import { SocialShare } from "@/components/social-share";
import { toast } from "@/hooks/use-toast";

export default function DashboardPage() {
  const [, setLocation] = useLocation();
  const [selectedUser, setSelectedUser] = useState(null);
  const [bulkSmsMessage, setBulkSmsMessage] = useState("");
  const [paymentAmount, setPaymentAmount] = useState("");
  const [paymentNote, setPaymentNote] = useState("");
  
  const { data: authData } = useQuery({
    queryKey: ["/api/auth/me"],
    retry: false,
  });

  const user = authData?.user;

  const { data: userProperties = [] } = useQuery({
    queryKey: ["/api/properties/user"],
    enabled: !!user,
  });

  const { data: userCars = [] } = useQuery({
    queryKey: ["/api/cars/user"],
    enabled: !!user,
  });

  const { data: userOrders = [] } = useQuery({
    queryKey: ["/api/open-orders/user"],
    enabled: !!user,
  });

  const { data: stats = {} } = useQuery({
    queryKey: ["/api/dashboard/stats"],
    enabled: !!user,
  });

  const { data: allUsers = [] } = useQuery({
    queryKey: ["/api/admin/users"],
    enabled: !!user && user.role === "admin",
  });

  // Admin mutations for payment bypass and account management
  const bypassPaymentMutation = useMutation({
    mutationFn: (userId: number) => apiRequest("POST", "/api/admin/bypass-payment", { userId }),
    onSuccess: () => {
      toast({ title: "Payment bypassed successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const toggleUserStatusMutation = useMutation({
    mutationFn: ({ userId, isActive }: { userId: number; isActive: boolean }) => 
      apiRequest("POST", "/api/admin/toggle-user-status", { userId, isActive }),
    onSuccess: () => {
      toast({ title: "User status updated successfully" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const bulkSmsMutation = useMutation({
    mutationFn: (message: string) => apiRequest("POST", "/api/admin/bulk-sms", { message }),
    onSuccess: () => {
      toast({ title: "Bulk SMS sent to all advertisers successfully" });
      setBulkSmsMessage("");
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const verifyPaymentMutation = useMutation({
    mutationFn: ({ userId, amount, note }: { userId: number; amount: string; note: string }) => 
      apiRequest("POST", "/api/admin/verify-payment", { userId, amount, note }),
    onSuccess: () => {
      toast({ title: "Payment verified and user activated" });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      setPaymentAmount("");
      setPaymentNote("");
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-96">
          <CardContent className="pt-6">
            <div className="text-center">
              <h2 className="text-lg font-semibold mb-2">Please log in</h2>
              <p className="text-gray-600 mb-4">You need to be logged in to access the dashboard</p>
              <Button onClick={() => setLocation("/")}>Go to Home</Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const isAdmin = user?.role === 'admin';
  const isAdvertiser = user?.role === 'advertiser';
  const totalListings = (userProperties.length || 0) + (userCars.length || 0);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                {isAdmin ? 'Admin Dashboard' : isAdvertiser ? 'Advertiser Dashboard' : 'My Dashboard'}
              </h1>
              <p className="text-gray-600 mt-2">
                {isAdmin ? 'Manage platform activity and users' : 
                 isAdvertiser ? 'Manage your business listings and campaigns' : 
                 'Manage your listings and account'}
              </p>
            </div>
            <Button onClick={() => setLocation("/post-order")} className="bg-green-600 hover:bg-green-700">
              <Plus className="h-4 w-4 mr-2" />
              Post Open Order
            </Button>
          </div>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <div className="p-2 bg-blue-100 rounded-lg">
                  <Home className="h-6 w-6 text-blue-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Properties</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {isAdmin || isAdvertiser ? stats.totalProperties || 0 : userProperties.length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <div className="p-2 bg-green-100 rounded-lg">
                  <Car className="h-6 w-6 text-green-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Cars</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {isAdmin || isAdvertiser ? stats.totalCars || 0 : userCars.length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <div className="p-2 bg-orange-100 rounded-lg">
                  <ClipboardList className="h-6 w-6 text-orange-600" />
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">Open Orders</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {isAdmin || isAdvertiser ? stats.totalOrders || 0 : userOrders.length || 0}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center">
                <div className="p-2 bg-purple-100 rounded-lg">
                  {isAdmin ? <Users className="h-6 w-6 text-purple-600" /> : <DollarSign className="h-6 w-6 text-purple-600" />}
                </div>
                <div className="ml-4">
                  <p className="text-sm font-medium text-gray-600">
                    {isAdmin ? 'Users' : isAdvertiser ? 'Revenue' : 'Active Ads'}
                  </p>
                  <p className="text-2xl font-bold text-gray-900">
                    {isAdmin ? stats?.totalUsers || 0 : 
                     isAdvertiser ? 'KSH 45K' : 
                     totalListings}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue={isAdmin || isAdvertiser ? "overview" : "listings"} className="space-y-6">
          <TabsList>
            {isAdmin ? (
              <>
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="users">User Management</TabsTrigger>
                <TabsTrigger value="payments">Payment Control</TabsTrigger>
                <TabsTrigger value="whatsapp-verification">WhatsApp Verification</TabsTrigger>
                <TabsTrigger value="listings">All Listings</TabsTrigger>
                <TabsTrigger value="communications">Bulk SMS</TabsTrigger>
                <TabsTrigger value="sharing">Social Sharing</TabsTrigger>
              </>
            ) : isAdvertiser ? (
              <>
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="listings">My Listings</TabsTrigger>
                <TabsTrigger value="orders">Open Orders</TabsTrigger>
                <TabsTrigger value="analytics">Analytics</TabsTrigger>
                <TabsTrigger value="sharing">Social Sharing</TabsTrigger>
              </>
            ) : (
              <>
                <TabsTrigger value="listings">My Listings</TabsTrigger>
                <TabsTrigger value="orders">My Orders</TabsTrigger>
                <TabsTrigger value="account">Account</TabsTrigger>
              </>
            )}
          </TabsList>

          {/* Admin & Advertiser Tabs */}
          {(isAdmin || isAdvertiser) && (
            <>
              <TabsContent value="overview">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>Recent Activity</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex items-center space-x-4">
                          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                          <div className="flex-1">
                            <p className="text-sm font-medium">
                              {isAdmin ? 'New property listing posted' : 'Your car listing viewed'}
                            </p>
                            <p className="text-xs text-gray-500">2 hours ago</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-4">
                          <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
                          <div className="flex-1">
                            <p className="text-sm font-medium">
                              {isAdmin ? 'User subscription payment' : 'Property inquiry received'}
                            </p>
                            <p className="text-xs text-gray-500">4 hours ago</p>
                          </div>
                        </div>
                        <div className="flex items-center space-x-4">
                          <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                          <div className="flex-1">
                            <p className="text-sm font-medium">
                              {isAdmin ? 'New open order created' : 'Featured listing activated'}
                            </p>
                            <p className="text-xs text-gray-500">6 hours ago</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader>
                      <CardTitle>{isAdmin ? 'Platform Growth' : 'Performance Metrics'}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">
                            {isAdmin ? 'New Users (This Month)' : 'Views (This Month)'}
                          </span>
                          <span className="font-semibold">{isAdmin ? '+12' : '1,240'}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">
                            {isAdmin ? 'New Listings (This Month)' : 'Inquiries (This Month)'}
                          </span>
                          <span className="font-semibold">{isAdmin ? '+28' : '45'}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-gray-600">
                            {isAdmin ? 'Revenue (This Month)' : 'Conversion Rate'}
                          </span>
                          <span className="font-semibold">{isAdmin ? 'KSH 8,400' : '12.5%'}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              {/* Advertiser Analytics Tab */}
              {isAdvertiser && (
                <TabsContent value="analytics">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle>Listing Performance</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-600">Total Views</span>
                            <span className="font-semibold">2,350</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-600">Unique Visitors</span>
                            <span className="font-semibold">1,890</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-600">Contact Inquiries</span>
                            <span className="font-semibold">67</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-600">Conversion Rate</span>
                            <span className="font-semibold">3.5%</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle>Revenue Analytics</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-600">Monthly Revenue</span>
                            <span className="font-semibold text-green-600">KSH 45,000</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-600">Subscription Cost</span>
                            <span className="font-semibold text-red-600">KSH 300</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-600">Net Profit</span>
                            <span className="font-semibold text-blue-600">KSH 44,700</span>
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-600">ROI</span>
                            <span className="font-semibold">14,900%</span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>
              )}

              {/* Admin User Management Tab */}
              {isAdmin && (
                <TabsContent value="users">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Users className="h-5 w-5" />
                        <span>User Management</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {Array.isArray(allUsers) && allUsers.map((user: any) => (
                          <div key={user.id} className="flex items-center justify-between p-4 border rounded-lg">
                            <div className="flex-1">
                              <div className="flex items-center space-x-3">
                                <div>
                                  <p className="font-medium">{user.fullName}</p>
                                  <p className="text-sm text-gray-500">{user.email}</p>
                                  <div className="flex items-center space-x-2 mt-1">
                                    <Badge variant={user.role === 'admin' ? 'default' : user.role === 'advertiser' ? 'secondary' : 'outline'}>
                                      {user.role}
                                    </Badge>
                                    <Badge variant={user.isActive ? 'default' : 'destructive'}>
                                      {user.isActive ? 'Active' : 'Inactive'}
                                    </Badge>
                                    <Badge variant={user.isSubscribed ? 'default' : 'outline'}>
                                      {user.isSubscribed ? 'Subscribed' : 'Not Subscribed'}
                                    </Badge>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Button
                                size="sm"
                                variant={user.isActive ? "destructive" : "default"}
                                onClick={() => toggleUserStatusMutation.mutate({ 
                                  userId: user.id, 
                                  isActive: !user.isActive 
                                })}
                                disabled={toggleUserStatusMutation.isPending}
                              >
                                {user.isActive ? <UserX className="h-4 w-4" /> : <UserCheck className="h-4 w-4" />}
                                {user.isActive ? 'Deactivate' : 'Activate'}
                              </Button>
                              {!user.isSubscribed && (
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => bypassPaymentMutation.mutate(user.id)}
                                  disabled={bypassPaymentMutation.isPending}
                                >
                                  <CreditCard className="h-4 w-4 mr-1" />
                                  Bypass Payment
                                </Button>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              )}

              {/* Admin Payment Control Tab */}
              {isAdmin && (
                <TabsContent value="payments">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center space-x-2">
                          <CreditCard className="h-5 w-5" />
                          <span>Payment Verification</span>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div>
                            <Label htmlFor="userId">User ID</Label>
                            <Input
                              id="userId"
                              placeholder="Enter user ID"
                              value={selectedUser || ""}
                              onChange={(e) => setSelectedUser(e.target.value)}
                            />
                          </div>
                          <div>
                            <Label htmlFor="amount">Payment Amount (KSH)</Label>
                            <Input
                              id="amount"
                              placeholder="300"
                              value={paymentAmount}
                              onChange={(e) => setPaymentAmount(e.target.value)}
                            />
                          </div>
                          <div>
                            <Label htmlFor="note">Payment Note</Label>
                            <Textarea
                              id="note"
                              placeholder="M-Pesa transaction details or payment note"
                              value={paymentNote}
                              onChange={(e) => setPaymentNote(e.target.value)}
                            />
                          </div>
                          <Button
                            className="w-full"
                            onClick={() => verifyPaymentMutation.mutate({
                              userId: Number(selectedUser),
                              amount: paymentAmount,
                              note: paymentNote
                            })}
                            disabled={verifyPaymentMutation.isPending || !selectedUser || !paymentAmount}
                          >
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Verify Payment & Activate
                          </Button>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center space-x-2">
                          <Shield className="h-5 w-5" />
                          <span>Payment Controls</span>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                            <div className="flex items-center space-x-2">
                              <Shield className="h-5 w-5 text-yellow-600" />
                              <h4 className="font-medium text-yellow-800">Admin Payment Controls</h4>
                            </div>
                            <p className="text-sm text-yellow-700 mt-2">
                              As admin, you can bypass payments and manually verify user payments to activate their subscriptions.
                            </p>
                          </div>
                          <div className="space-y-2">
                            <h4 className="font-medium">Quick Actions:</h4>
                            <ul className="text-sm text-gray-600 space-y-1">
                              <li>• Bypass Payment: Instantly activate user subscription</li>
                              <li>• Verify Payment: Confirm M-Pesa payment and activate</li>
                              <li>• Activate/Deactivate: Control user account status</li>
                              <li>• Unlimited Listings: Subscribed users get unlimited posts</li>
                            </ul>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>
              )}

              {/* Admin WhatsApp Verification Tab */}
              {isAdmin && (
                <TabsContent value="whatsapp-verification">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <MessageSquare className="h-5 w-5" />
                        <span>WhatsApp Payment Verification</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                          <h3 className="font-semibold text-blue-900 mb-2">Process M-Pesa Payment Messages</h3>
                          <p className="text-sm text-blue-800">Paste forwarded WhatsApp M-Pesa messages here to verify payments and activate subscriptions.</p>
                        </div>
                        
                        <div>
                          <Label htmlFor="whatsappMessage">WhatsApp Payment Message</Label>
                          <Textarea
                            id="whatsappMessage"
                            placeholder="Paste the complete M-Pesa payment message here...

Example:
QHJ4K5L8M9 Confirmed. Ksh300.00 sent to FYAIDA MARKETPLACE 3511028 on 26/6/25 at 4:15 PM. M-PESA balance is Ksh1,250.75. Transaction cost, Ksh0.00. Amount you can transact within the day is 299,700.00. To reverse, forward this message to 456."
                            rows={6}
                          />
                        </div>
                        
                        <div className="flex items-center justify-between">
                          <p className="text-sm text-gray-600">
                            System will automatically extract receipt codes, amounts, and phone numbers
                          </p>
                          <Button
                            onClick={() => {
                              const messageText = document.getElementById('whatsappMessage')?.value;
                              if (messageText) {
                                fetch('/api/admin/whatsapp-payment', {
                                  method: 'POST',
                                  headers: { 'Content-Type': 'application/json' },
                                  body: JSON.stringify({ messageText })
                                }).then(() => {
                                  alert('Payment message processed successfully');
                                  document.getElementById('whatsappMessage').value = '';
                                });
                              }
                            }}
                            className="bg-green-600 hover:bg-green-700"
                          >
                            <MessageSquare className="h-4 w-4 mr-2" />
                            Process Payment Message
                          </Button>
                        </div>
                        
                        <div className="border-t pt-4">
                          <h4 className="font-medium mb-2">Quick Actions:</h4>
                          <div className="grid grid-cols-2 gap-2">
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => window.open('/whatsapp-verify', '_blank')}
                            >
                              View All Messages
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => fetch('/api/admin/whatsapp-payments').then(r => r.json()).then(data => alert(`${data.length} payment messages in system`))}
                            >
                              Check Message Count
                            </Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              )}

              {/* Admin Bulk SMS Tab */}
              {isAdmin && (
                <TabsContent value="communications">
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <MessageSquare className="h-5 w-5" />
                        <span>Bulk SMS to Advertisers</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <Label htmlFor="smsMessage">Message</Label>
                          <Textarea
                            id="smsMessage"
                            placeholder="Type your message to all advertisers..."
                            value={bulkSmsMessage}
                            onChange={(e) => setBulkSmsMessage(e.target.value)}
                            rows={4}
                          />
                        </div>
                        <div className="flex items-center justify-between">
                          <p className="text-sm text-gray-600">
                            This will send SMS to all active advertisers
                          </p>
                          <Button
                            onClick={() => bulkSmsMutation.mutate(bulkSmsMessage)}
                            disabled={bulkSmsMutation.isPending || !bulkSmsMessage.trim()}
                          >
                            <MessageSquare className="h-4 w-4 mr-2" />
                            Send Bulk SMS
                          </Button>
                        </div>
                        <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                          <p className="text-sm text-blue-700">
                            SMS will be logged in console. Use WhatsApp Business API or SMS service integration to send automatically.
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              )}

              {/* Social Media Sharing Tab */}
              {(isAdmin || isAdvertiser) && (
                <TabsContent value="sharing">
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center space-x-2">
                          <Share2 className="h-5 w-5" />
                          <span>Share Fyaida Platform</span>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <p className="text-sm text-gray-600">
                            Share the Fyaida marketplace with your network
                          </p>
                          <SocialShare
                            title="Fyaida - Kenya's Premier Property & Car Marketplace"
                            description="Buy, sell, and rent properties and cars across Kenya. Join thousands of satisfied users on Fyaida."
                            type="app"
                          />
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center space-x-2">
                          <Smartphone className="h-5 w-5" />
                          <span>Mobile App Download</span>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          <p className="text-sm text-gray-600">
                            Share direct mobile app download link
                          </p>
                          <SocialShare
                            title="Download Fyaida Mobile App"
                            description="Get the Fyaida mobile app for Android. Browse properties and cars on the go!"
                            url={`${window.location.origin}/fyaida-mobile.apk`}
                            type="app"
                          />
                          <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                            <p className="text-sm text-green-700">
                              Mobile app available for direct download - no Google Play Store required!
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>
              )}

              <TabsContent value="users">
                <Card>
                  <CardHeader>
                    <CardTitle>Users Management</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-8">
                      <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-500">User management functionality coming soon</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="revenue">
                <Card>
                  <CardHeader>
                    <CardTitle>Revenue Analytics</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="text-center py-8">
                      <TrendingUp className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-500">Revenue analytics coming soon</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </>
          )}

          {/* User Tabs */}
          <TabsContent value="listings">
            <div className="space-y-6">
              <div className="flex justify-between items-center">
                <h3 className="text-lg font-semibold">
                  {isAdmin ? 'All Listings' : isAdvertiser ? 'My Business Listings' : 'My Listings'}
                </h3>
                <div className="flex space-x-2">
                  <Button onClick={() => setLocation("/post-ad")}>
                    <Plus className="h-4 w-4 mr-2" />
                    Add Listing
                  </Button>
                  {(isAdmin || isAdvertiser) && (
                    <Button variant="outline" onClick={() => setLocation("/post-order")}>
                      <ClipboardList className="h-4 w-4 mr-2" />
                      Post Order
                    </Button>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 gap-6">
                {/* Properties */}
                {userProperties?.map((property: any) => (
                  <Card key={property.id}>
                    <CardContent className="pt-6">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <Badge variant="secondary">Property</Badge>
                            <Badge variant={property.listingType === 'sale' ? 'default' : 'outline'}>
                              {property.listingType}
                            </Badge>
                            {isAdvertiser && <Badge variant="outline">Featured</Badge>}
                          </div>
                          <h4 className="font-semibold text-lg">{property.title}</h4>
                          <p className="text-gray-600 text-sm">{property.location}</p>
                          <p className="font-bold text-green-600 mt-2">KSH {property.price?.toLocaleString()}</p>
                          {isAdvertiser && (
                            <p className="text-xs text-gray-500 mt-1">Views: 245 | Inquiries: 12</p>
                          )}
                        </div>
                        <div className="flex flex-col space-y-2">
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                          {(isAdmin || isAdvertiser) && (
                            <div className="flex space-x-1">
                              <SocialShare
                                title={property.title}
                                description={`${property.type} for ${property.listingType} in ${property.location} - KSH ${property.price?.toLocaleString()}`}
                                url={`${window.location.origin}/properties/${property.id}`}
                                imageUrl={property.images?.[0]}
                                type="property"
                              />
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}

                {/* Cars */}
                {userCars?.map((car: any) => (
                  <Card key={car.id}>
                    <CardContent className="pt-6">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <Badge variant="secondary">Car</Badge>
                            <Badge variant="outline">{car.year}</Badge>
                            {isAdvertiser && <Badge variant="outline">Featured</Badge>}
                          </div>
                          <h4 className="font-semibold text-lg">{car.title}</h4>
                          <p className="text-gray-600 text-sm">{car.location}</p>
                          <p className="font-bold text-green-600 mt-2">KSH {car.price?.toLocaleString()}</p>
                          {isAdvertiser && (
                            <p className="text-xs text-gray-500 mt-1">Views: 189 | Inquiries: 8</p>
                          )}
                        </div>
                        <div className="flex flex-col space-y-2">
                          <div className="flex space-x-2">
                            <Button variant="outline" size="sm">
                              <Eye className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                          {(isAdmin || isAdvertiser) && (
                            <div className="flex space-x-1">
                              <SocialShare
                                title={car.title}
                                description={`${car.year} ${car.make} ${car.model} for sale in ${car.location} - KSH ${car.price?.toLocaleString()}`}
                                url={`${window.location.origin}/cars/${car.id}`}
                                imageUrl={car.images?.[0]}
                                type="car"
                              />
                            </div>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="orders">
            <Card>
              <CardHeader>
                <CardTitle>My Open Orders</CardTitle>
              </CardHeader>
              <CardContent>
                {userOrders?.length > 0 ? (
                  <div className="space-y-4">
                    {userOrders.map((order: any) => (
                      <div key={order.id} className="border rounded-lg p-4">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <Badge variant="secondary">Order</Badge>
                              <Badge variant="outline">Active</Badge>
                              {isAdvertiser && <Badge variant="outline">Premium</Badge>}
                            </div>
                            <h4 className="font-semibold">{order.propertyType}</h4>
                            <p className="text-gray-600 text-sm">{order.description}</p>
                            <p className="text-sm text-gray-500 mt-1">Budget: {order.budget}</p>
                            <p className="text-sm text-gray-500">Location: {order.location}</p>
                            {isAdvertiser && (
                              <p className="text-xs text-gray-500 mt-1">Responses: 3 | Views: 67</p>
                            )}
                          </div>
                          <div className="flex flex-col space-y-2">
                            <div className="flex space-x-2">
                              <Button variant="outline" size="sm">
                                <Eye className="h-4 w-4" />
                              </Button>
                              <Button variant="outline" size="sm">
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button variant="outline" size="sm">
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                            {(isAdmin || isAdvertiser) && (
                              <div className="flex space-x-1">
                                <SocialShare
                                  title={`Looking for ${order.propertyType}`}
                                  description={`${order.description} - Budget: ${order.budget} in ${order.location}`}
                                  url={`${window.location.origin}/open-orders/${order.id}`}
                                  imageUrl={order.referenceImage}
                                  type="order"
                                />
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <ClipboardList className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-500">No open orders yet</p>
                    <Button 
                      onClick={() => setLocation("/post-order")}
                      className="mt-4"
                    >
                      Create Your First Order
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="account">
            <Card>
              <CardHeader>
                <CardTitle>Account Settings</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <h4 className="font-semibold mb-2">Subscription Status</h4>
                    <div className="flex items-center space-x-4">
                      <Badge variant={user?.subscriptionActive ? "default" : "secondary"}>
                        {user?.subscriptionActive ? "Active" : "Inactive"}
                      </Badge>
                      <Button 
                        variant="outline" 
                        onClick={() => setLocation("/subscription")}
                      >
                        Manage Subscription
                      </Button>
                    </div>
                    {isAdvertiser && (
                      <p className="text-sm text-gray-600 mt-2">
                        Business Plan - KSH 300/month for unlimited listings
                      </p>
                    )}
                  </div>
                  
                  <div>
                    <h4 className="font-semibold mb-2">Account Information</h4>
                    <div className="space-y-2 text-sm">
                      <p><span className="font-medium">Email:</span> {user?.email}</p>
                      <p><span className="font-medium">Full Name:</span> {user?.fullName}</p>
                      <p><span className="font-medium">Role:</span> {user?.role || 'User'}</p>
                      <p><span className="font-medium">Member Since:</span> {user?.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'N/A'}</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
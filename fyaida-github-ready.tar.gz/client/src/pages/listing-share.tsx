import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Phone, 
  MessageCircle, 
  MapPin, 
  Calendar, 
  DollarSign,
  User,
  ArrowLeft,
  ExternalLink
} from "lucide-react";
import { ContactAdvertiser } from "@/components/contact-advertiser";

export default function ListingSharePage() {
  const [location] = useLocation();
  const [listingType, setListingType] = useState<"property" | "car">("property");
  const [listingId, setListingId] = useState<number | null>(null);

  // Parse URL parameters
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const type = urlParams.get("type") as "property" | "car";
    const id = urlParams.get("id");
    
    if (type && id) {
      setListingType(type);
      setListingId(parseInt(id));
    }
  }, [location]);

  const { data: listing, isLoading } = useQuery({
    queryKey: [`/api/${listingType === "property" ? "properties" : "cars"}/${listingId}`],
    enabled: !!listingId,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (!listing) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center">
        <Card className="max-w-md">
          <CardContent className="text-center py-8">
            <h2 className="text-xl font-semibold mb-2">Listing Not Found</h2>
            <p className="text-gray-600 dark:text-gray-400 mb-4">
              The listing you're looking for doesn't exist or has been removed.
            </p>
            <Button onClick={() => window.location.href = "/"}>
              Go to Homepage
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('en-KE', {
      style: 'currency',
      currency: 'KES',
    }).format(price);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8">
      <div className="max-w-4xl mx-auto px-4">
        {/* Header */}
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={() => window.location.href = "/"}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Fyaida
          </Button>
          
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                {listing.title}
              </h1>
              <p className="text-gray-600 dark:text-gray-400">
                Shared from Fyaida.com
              </p>
            </div>
            
            <Button
              onClick={() => window.location.href = "/"}
              className="bg-green-600 hover:bg-green-700"
            >
              <ExternalLink className="h-4 w-4 mr-2" />
              Visit Fyaida.com
            </Button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <Card className="mb-6">
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-2xl">{listing.title}</CardTitle>
                    <div className="flex items-center gap-2 mt-2">
                      <MapPin className="h-4 w-4 text-gray-500" />
                      <span className="text-gray-600 dark:text-gray-400">
                        {listing.location}
                      </span>
                    </div>
                  </div>
                  <Badge variant="secondary" className="text-lg font-bold">
                    {formatPrice(listing.price)}
                  </Badge>
                </div>
              </CardHeader>
              
              <CardContent>
                {/* Images */}
                {listing.images && listing.images.length > 0 && (
                  <div className="mb-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {listing.images.slice(0, 4).map((image: string, index: number) => (
                        <img
                          key={index}
                          src={image}
                          alt={`${listing.title} - Image ${index + 1}`}
                          className="w-full h-48 object-cover rounded-lg"
                        />
                      ))}
                    </div>
                  </div>
                )}

                {/* Details */}
                <div className="space-y-4">
                  <div>
                    <h3 className="font-semibold mb-2">Description</h3>
                    <p className="text-gray-700 dark:text-gray-300">
                      {listing.description}
                    </p>
                  </div>

                  {/* Property specific details */}
                  {listingType === "property" && (
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <span className="font-medium">Type:</span>
                        <span className="ml-2">{listing.type}</span>
                      </div>
                      <div>
                        <span className="font-medium">Listing Type:</span>
                        <span className="ml-2">{listing.listingType}</span>
                      </div>
                      {listing.bedrooms && (
                        <div>
                          <span className="font-medium">Bedrooms:</span>
                          <span className="ml-2">{listing.bedrooms}</span>
                        </div>
                      )}
                      {listing.size && (
                        <div>
                          <span className="font-medium">Size:</span>
                          <span className="ml-2">{listing.size}</span>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Car specific details */}
                  {listingType === "car" && (
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <span className="font-medium">Make:</span>
                        <span className="ml-2">{listing.make}</span>
                      </div>
                      <div>
                        <span className="font-medium">Model:</span>
                        <span className="ml-2">{listing.model}</span>
                      </div>
                      <div>
                        <span className="font-medium">Year:</span>
                        <span className="ml-2">{listing.year}</span>
                      </div>
                      <div>
                        <span className="font-medium">Transmission:</span>
                        <span className="ml-2">{listing.transmission}</span>
                      </div>
                      <div>
                        <span className="font-medium">Fuel Type:</span>
                        <span className="ml-2">{listing.fuelType}</span>
                      </div>
                      <div>
                        <span className="font-medium">Mileage:</span>
                        <span className="ml-2">{listing.mileage} km</span>
                      </div>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Advertiser Contact */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <User className="h-5 w-5" />
                  Contact Advertiser
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <p className="font-medium">{listing.advertiser?.fullName || "Advertiser"}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {listing.advertiser?.city}, {listing.advertiser?.country}
                    </p>
                  </div>

                  <div className="space-y-2">
                    <ContactAdvertiser 
                      advertiser={listing.advertiser}
                      listingTitle={listing.title}
                      listingType={listingType}
                    />
                  </div>

                  <div className="pt-4 border-t">
                    <p className="text-xs text-gray-500 text-center">
                      Posted on {new Date(listing.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Return to Platform */}
            <Card>
              <CardHeader>
                <CardTitle>Are you the advertiser?</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                  Login to Fyaida to manage your listings and view messages.
                </p>
                <Button 
                  className="w-full"
                  onClick={() => window.location.href = "/?login=true"}
                >
                  Login to Fyaida
                </Button>
              </CardContent>
            </Card>

            {/* Platform Info */}
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <h3 className="font-semibold mb-2">Find More on Fyaida</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                    Discover thousands of properties and cars across Kenya
                  </p>
                  <Button 
                    variant="outline" 
                    className="w-full"
                    onClick={() => window.location.href = "/"}
                  >
                    Browse All Listings
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
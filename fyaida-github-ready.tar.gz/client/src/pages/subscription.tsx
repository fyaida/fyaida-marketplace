import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Form,
  FormField,
  FormItem,
  FormLabel,
  FormControl,
  FormMessage,
} from "@/components/ui/form";
import { 
  CheckCircle, 
  Crown, 
  CreditCard, 
  Users, 
  Share2, 
  ClipboardList,
  AlertCircle,
  Phone,
  MessageSquare
} from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const paymentSchema = z.object({
  phoneNumber: z.string().min(10, "Phone number must be at least 10 digits"),
});

type PaymentFormData = z.infer<typeof paymentSchema>;

export default function SubscriptionPage() {
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: user } = useQuery({
    queryKey: ["/api/auth/me"],
    retry: false,
  });

  const form = useForm<PaymentFormData>({
    resolver: zodResolver(paymentSchema),
    defaultValues: {
      phoneNumber: "",
    },
  });

  const paymentMutation = useMutation({
    mutationFn: (data: PaymentFormData) => apiRequest("POST", "/api/subscription/mock-payment", data),
    onSuccess: (response) => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      toast({
        title: "Subscription activated!",
        description: "Your premium subscription is now active for 90 days.",
      });
      form.reset();
      setIsProcessing(false);
    },
    onError: (error) => {
      toast({
        title: "Payment failed",
        description: error.message,
        variant: "destructive",
      });
      setIsProcessing(false);
    },
  });

  const handlePayment = (data: PaymentFormData) => {
    setIsProcessing(true);
    // Simulate payment processing delay
    setTimeout(() => {
      paymentMutation.mutate(data);
    }, 2000);
  };

  const isSubscribed = user?.isSubscribed && user.subscriptionExpiry && new Date(user.subscriptionExpiry) > new Date();

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md mx-4">
          <CardContent className="pt-6">
            <div className="flex mb-4 gap-2">
              <AlertCircle className="h-8 w-8 text-red-500" />
              <h1 className="text-2xl font-bold text-gray-900">Login Required</h1>
            </div>
            <p className="mt-4 text-sm text-gray-600">
              You need to be logged in to manage your subscription.
            </p>
            <Button 
              onClick={() => window.location.href = '/'} 
              className="w-full mt-4"
            >
              Go to Home Page
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Subscription Plans</h1>
          <p className="text-gray-600">Choose the perfect plan for your advertising needs</p>
        </div>

        {/* Current Status */}
        {isSubscribed ? (
          <Card className="mb-8 bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <CardContent className="pt-6">
              <div className="flex items-center justify-center mb-4">
                <Crown className="h-8 w-8 text-green-600 mr-3" />
                <div>
                  <h2 className="text-xl font-bold text-green-800">Premium Active</h2>
                  <p className="text-green-600">
                    Your subscription expires on {new Date(user.subscriptionExpiry!).toLocaleDateString()}
                  </p>
                </div>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                <div className="flex items-center justify-center text-green-700">
                  <CheckCircle className="h-5 w-5 mr-2" />
                  Unlimited Posting
                </div>
                <div className="flex items-center justify-center text-green-700">
                  <Share2 className="h-5 w-5 mr-2" />
                  Social Media Sharing
                </div>
                <div className="flex items-center justify-center text-green-700">
                  <ClipboardList className="h-5 w-5 mr-2" />
                  Open Orders Access
                </div>
              </div>
            </CardContent>
          </Card>
        ) : (
          <Card className="mb-8 bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
            <CardContent className="pt-6">
              <div className="text-center">
                <AlertCircle className="h-8 w-8 text-blue-600 mx-auto mb-3" />
                <h2 className="text-xl font-bold text-blue-800 mb-2">Free Trial Active</h2>
                <p className="text-blue-600">
                  You have {user.createdAt ? Math.max(0, 5 - Math.floor((Date.now() - new Date(user.createdAt).getTime()) / (1000 * 60 * 60 * 24))) : 5} days left of free posting
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Subscription Plan */}
          <Card className="relative">
            <div className="absolute top-4 right-4">
              <Badge className="bg-primary text-white">Most Popular</Badge>
            </div>
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <Crown className="h-6 w-6 text-primary" />
                Premium Subscription
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-6">
                <div className="text-4xl font-bold text-primary mb-2">KSh 300</div>
                <div className="text-gray-600">for 90 days</div>
              </div>

              <div className="space-y-4 mb-8">
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span>Unlimited property and car posting</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span>Share listings to social media platforms</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span>Access to Open Property Orders</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span>Priority listing display</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span>Advanced analytics and insights</span>
                </div>
                <div className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                  <span>Customer support priority</span>
                </div>
              </div>

              {!isSubscribed && (
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(handlePayment)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="phoneNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number for Payment</FormLabel>
                          <FormControl>
                            <Input 
                              placeholder="e.g., 0722869901" 
                              {...field}
                              disabled={isProcessing}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button 
                      type="submit" 
                      className="w-full gradient-subscription text-white"
                      disabled={isProcessing || paymentMutation.isPending}
                    >
                      <CreditCard className="h-4 w-4 mr-2" />
                      {isProcessing ? "Processing Payment..." : "Subscribe Now - KSh 300"}
                    </Button>
                  </form>
                </Form>
              )}
            </CardContent>
          </Card>

          {/* Payment Instructions */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-3">
                <Phone className="h-6 w-6 text-secondary" />
                Payment Instructions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3">How to Pay:</h3>
                  <div className="space-y-3">
                    <div className="flex items-start">
                      <div className="bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-0.5">1</div>
                      <div>
                        <p className="font-medium">Send KSh 300 to Till Number</p>
                        <p className="text-2xl font-bold text-primary">3511028</p>
                        <p className="text-sm text-gray-600">Recipient: Newtech Systems Technicians</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-0.5">2</div>
                      <div>
                        <p className="font-medium">Enter your phone number above</p>
                        <p className="text-sm text-gray-600">Use the same number you used for payment</p>
                      </div>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="bg-primary text-white rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold mr-3 mt-0.5">3</div>
                      <div>
                        <p className="font-medium">Forward payment message to WhatsApp</p>
                        <div className="flex items-center gap-2 mt-1">
                          <MessageSquare className="h-4 w-4 text-green-600" />
                          <span className="font-bold text-green-600">0722869901</span>
                        </div>
                        <p className="text-sm text-gray-600">For verification and activation</p>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                  <div className="flex items-start">
                    <AlertCircle className="h-5 w-5 text-amber-600 mr-3 mt-0.5" />
                    <div className="text-sm">
                      <p className="font-medium text-amber-800">Important:</p>
                      <p className="text-amber-700">
                        Your subscription will be activated within 24 hours after payment verification. 
                        Make sure to forward your payment confirmation to our WhatsApp number.
                      </p>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                  <h4 className="font-medium text-blue-800 mb-2">Need Help?</h4>
                  <div className="space-y-2 text-sm text-blue-700">
                    <p>📍 <strong>Office Location:</strong></p>
                    <p className="ml-4">Rahimtulla Trust Building<br />2nd Floor, Room 202<br />Moi Avenue, Nairobi</p>
                    <p>📞 <strong>Phone:</strong> 0722869901</p>
                    <p>✉️ <strong>Email:</strong> support@fyaida.com</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Free vs Premium Comparison */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Feature Comparison</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b">
                    <th className="text-left py-3">Features</th>
                    <th className="text-center py-3">Free (5 days)</th>
                    <th className="text-center py-3">Premium (90 days)</th>
                  </tr>
                </thead>
                <tbody className="text-sm">
                  <tr className="border-b">
                    <td className="py-3">Property & Car Listings</td>
                    <td className="text-center py-3">
                      <Badge variant="outline">Limited</Badge>
                    </td>
                    <td className="text-center py-3">
                      <CheckCircle className="h-5 w-5 text-green-500 mx-auto" />
                    </td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3">Social Media Sharing</td>
                    <td className="text-center py-3">
                      <X className="h-5 w-5 text-red-500 mx-auto" />
                    </td>
                    <td className="text-center py-3">
                      <CheckCircle className="h-5 w-5 text-green-500 mx-auto" />
                    </td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3">Open Orders Access</td>
                    <td className="text-center py-3">
                      <X className="h-5 w-5 text-red-500 mx-auto" />
                    </td>
                    <td className="text-center py-3">
                      <CheckCircle className="h-5 w-5 text-green-500 mx-auto" />
                    </td>
                  </tr>
                  <tr className="border-b">
                    <td className="py-3">Priority Support</td>
                    <td className="text-center py-3">
                      <X className="h-5 w-5 text-red-500 mx-auto" />
                    </td>
                    <td className="text-center py-3">
                      <CheckCircle className="h-5 w-5 text-green-500 mx-auto" />
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function X({ className }: { className?: string }) {
  return (
    <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
    </svg>
  );
}

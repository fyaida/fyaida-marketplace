import { useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { ArrowLeft } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

const orderSchema = z.object({
  contactName: z.string().min(2, "Your name is required"),
  contactPhone: z.string().min(10, "Valid phone number is required"),
  description: z.string().min(10, "Please describe what you're looking for"),
});

type OrderFormData = z.infer<typeof orderSchema>;

export default function PostOrderPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<OrderFormData>({
    resolver: zodResolver(orderSchema),
    defaultValues: {
      contactName: "",
      contactPhone: "",
      description: "",
    },
  });

  const createOrderMutation = useMutation({
    mutationFn: async (data: OrderFormData) => {
      // Create simplified order with default values
      const orderData = {
        title: `Request from ${data.contactName}`,
        description: data.description,
        propertyType: "Any Property",
        budget: "Negotiable",
        location: "Kenya",
        requirements: ["Contact me for details"],
        contactName: data.contactName,
        contactPhone: data.contactPhone,
        contactEmail: null,
      };
      
      const response = await apiRequest("POST", "/api/open-orders", orderData);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/open-orders"] });
      toast({
        title: "Order posted successfully!",
        description: "Your request has been posted. Advertisers will contact you soon.",
      });
      form.reset();
      setLocation("/open-orders");
    },
    onError: (error) => {
      toast({
        title: "Failed to post order",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: OrderFormData) => {
    createOrderMutation.mutate(data);
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 py-8">
      <div className="max-w-2xl mx-auto px-4">
        <div className="mb-6">
          <Button
            variant="ghost"
            onClick={() => setLocation("/open-orders")}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Open Orders
          </Button>
          <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
            Post Your Request
          </h1>
          <p className="text-gray-600 dark:text-gray-400 mt-2">
            Tell us what you're looking for and advertisers will contact you directly
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Your Request Details</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <FormField
                  control={form.control}
                  name="contactName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Your Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Enter your full name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="contactPhone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Phone Number</FormLabel>
                      <FormControl>
                        <Input placeholder="0722000000" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>What are you looking for?</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Describe what property or car you're looking for, your budget, preferred location, and any specific requirements..."
                          className="min-h-[120px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="flex gap-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setLocation("/open-orders")}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    disabled={createOrderMutation.isPending}
                    className="flex-1"
                  >
                    {createOrderMutation.isPending ? "Posting..." : "Post Request"}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
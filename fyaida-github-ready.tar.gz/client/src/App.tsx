import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import { TrialNotification } from "@/components/trial-notification";
import { PWAInstallPrompt } from "@/components/pwa-install-prompt";
import { MobileNavigation } from "@/components/mobile-navigation";
import { OfflineIndicator } from "@/components/offline-indicator";
import HomePage from "@/pages/home";
import PropertiesPage from "@/pages/properties";
import CarsPage from "@/pages/cars";
import PostAdPage from "@/pages/post-ad";
import OpenOrdersPage from "@/pages/open-orders";
import PostOrderPage from "@/pages/post-order";
import SubscriptionPage from "@/pages/subscription";
import AdminPage from "@/pages/admin";
import DashboardPage from "@/pages/dashboard";
import MobileAppPage from "@/pages/mobile-app";
import WhatsAppVerifyPage from "@/pages/whatsapp-verify";
import DownloadApkPage from "@/pages/download-apk";
import TermsPage from "@/pages/terms";
import ListingSharePage from "@/pages/listing-share";
import NotFound from "@/pages/not-found";

function Router() {
  return (
    <div className="min-h-screen flex flex-col">
      <Navbar />
      <TrialNotification />
      <main className="flex-1">
        <Switch>
          <Route path="/" component={HomePage} />
          <Route path="/properties" component={PropertiesPage} />
          <Route path="/cars" component={CarsPage} />
          <Route path="/post-ad" component={PostAdPage} />
          <Route path="/open-orders" component={OpenOrdersPage} />
          <Route path="/post-order" component={PostOrderPage} />
          <Route path="/subscription" component={SubscriptionPage} />
          <Route path="/admin" component={AdminPage} />
          <Route path="/dashboard" component={DashboardPage} />
          <Route path="/mobile-app" component={MobileAppPage} />
          <Route path="/whatsapp-verify" component={WhatsAppVerifyPage} />
          <Route path="/download-apk" component={DownloadApkPage} />
          <Route path="/terms" component={TermsPage} />
          <Route path="/share" component={ListingSharePage} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <OfflineIndicator />
      <PWAInstallPrompt />
      <MobileNavigation />
      <Footer />
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;

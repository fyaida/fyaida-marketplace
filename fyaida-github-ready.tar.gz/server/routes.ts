import type { Express, Request } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertUserSchema, insertPropertySchema, insertCarSchema, insertOpenOrderSchema } from "@shared/schema";
import bcrypt from "bcrypt";
import session from "express-session";
import connectPg from "connect-pg-simple";

declare module "express-session" {
  interface SessionData {
    userId: number;
  }
}

// Session configuration
function getSession() {
  const sessionTtl = 7 * 24 * 60 * 60 * 1000; // 1 week
  const pgStore = connectPg(session);
  const sessionStore = new pgStore({
    conString: process.env.DATABASE_URL,
    createTableIfMissing: false,
    ttl: sessionTtl,
    tableName: "sessions",
  });
  
  return session({
    secret: process.env.SESSION_SECRET || "your-secret-key",
    store: sessionStore,
    resave: false,
    saveUninitialized: false,
    cookie: {
      httpOnly: true,
      secure: false, // Set to true in production with HTTPS
      maxAge: sessionTtl,
      sameSite: 'lax', // Ensure cross-origin cookie handling
    },
  });
}

// Authentication middleware
const requireAuth = (req: any, res: any, next: any) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: "Authentication required" });
  }
  next();
};

// Subscription middleware - check if user has active subscription for premium features
const requireSubscription = async (req: any, res: any, next: any) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: "Authentication required" });
  }
  
  const user = await storage.getUser(req.session.userId);
  if (!user) {
    return res.status(401).json({ message: "User not found" });
  }
  
  // Admin users bypass subscription check
  if (user.role === 'admin') {
    return next();
  }
  
  // Check if user has active subscription
  if (!user.isSubscribed || (user.subscriptionExpiry && new Date() > user.subscriptionExpiry)) {
    return res.status(403).json({ 
      message: "Active subscription required. Please subscribe for KSH 300 to access this feature.",
      requiresSubscription: true 
    });
  }
  
  next();
};

// Stealth trial posting middleware - allows 5 days free posting without telling user it's a trial
const allowTrialPosting = async (req: any, res: any, next: any) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: "Authentication required" });
  }
  
  const user = await storage.getUser(req.session.userId);
  if (!user) {
    return res.status(401).json({ message: "User not found" });
  }
  
  // Admin users bypass all checks
  if (user.role === 'admin') {
    return next();
  }
  
  // Check if user has active subscription (premium access)
  if (user.isSubscribed && user.subscriptionExpiry && new Date() <= user.subscriptionExpiry) {
    return next();
  }
  
  // Start trial on first post if not started
  if (!user.trialStartDate) {
    await storage.startUserTrial(req.session.userId);
    return next(); // Allow first post
  }
  
  // Check trial status
  const trialStatus = await storage.checkTrialExpiry(req.session.userId);
  
  if (!trialStatus.expired) {
    return next(); // Allow trial posting
  }
  
  // Trial expired and no subscription
  return res.status(403).json({ 
    message: "5-day trial expired. Subscribe for KSH 300 to continue posting listings.",
    requiresSubscription: true,
    trialExpired: true
  });
};

const requireAdmin = async (req: any, res: any, next: any) => {
  if (!req.session.userId) {
    return res.status(401).json({ message: "Authentication required" });
  }
  
  const user = await storage.getUser(req.session.userId);
  if (!user || user.role !== 'admin') {
    return res.status(403).json({ message: "Admin access required" });
  }
  
  next();
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup session middleware
  app.use(getSession());

  // Auth routes
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ message: "Email already registered" });
      }
      
      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, 10);
      
      // Create user
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
      });
      
      // Set session
      req.session.userId = user.id;
      
      res.json({ user: { ...user, password: undefined } });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const { email, password } = req.body;
      
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      const isValidPassword = await bcrypt.compare(password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      
      req.session.userId = user.id;
      
      res.json({ user: { ...user, password: undefined } });
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Logout failed" });
      }
      res.clearCookie('connect.sid');
      res.json({ message: "Logged out successfully" });
    });
  });

  app.get("/api/auth/me", async (req, res) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }
    
    const user = await storage.getUser(req.session.userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    res.json({ user: { ...user, password: undefined } });
  });

  app.post("/api/auth/forgot-password", async (req, res) => {
    try {
      const { email } = req.body;
      
      if (!email) {
        return res.status(400).json({ message: "Email is required" });
      }

      // Check if user exists
      const user = await storage.getUserByEmail(email);
      if (!user) {
        return res.status(404).json({ message: "No account found with this email address" });
      }

      // Log the password reset request for admin to handle via WhatsApp
      console.log(`Password reset requested for user: ${user.email} (${user.fullName})`);
      console.log(`Admin should be notified via WhatsApp: 0722869901`);
      
      res.json({ 
        message: "Password reset request sent to admin",
        details: "Your request has been forwarded to our admin team via WhatsApp (0722869901). You will receive a new password within 24 hours."
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Trial status endpoint - checks if user's trial has expired
  app.get("/api/auth/trial-status", requireAuth, async (req, res) => {
    try {
      const user = await storage.getUser(req.session.userId!);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Admin users don't have trials
      if (user.role === 'admin') {
        return res.json({ hasSubscription: true, isAdmin: true });
      }

      // Check if user has active subscription
      if (user.isSubscribed && user.subscriptionExpiry && new Date() <= user.subscriptionExpiry) {
        return res.json({ hasSubscription: true });
      }

      // Check trial status
      const trialStatus = await storage.checkTrialExpiry(req.session.userId!);
      
      // Mark trial as expired and notified if needed
      if (trialStatus.expired && !user.trialNotified) {
        await storage.updateUserTrialStatus(req.session.userId!, true, true);
      }

      res.json({
        hasSubscription: false,
        trialExpired: trialStatus.expired,
        daysLeft: trialStatus.daysLeft,
        trialNotified: user.trialNotified,
        canPost: !trialStatus.expired
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Properties routes
  app.get("/api/properties", async (req, res) => {
    try {
      const filters = {
        type: req.query.type as string,
        listingType: req.query.listingType as string,
        location: req.query.location as string,
        minPrice: req.query.minPrice ? Number(req.query.minPrice) : undefined,
        maxPrice: req.query.maxPrice ? Number(req.query.maxPrice) : undefined,
        bedrooms: req.query.bedrooms ? Number(req.query.bedrooms) : undefined,
        search: req.query.search as string,
      };
      
      const properties = await storage.getProperties(filters);
      
      // Add contact information for each property
      const propertiesWithContact = await Promise.all(
        properties.map(async (property) => {
          const advertiser = await storage.getUser(property.userId);
          return {
            ...property,
            user: advertiser ? {
              fullName: advertiser.fullName,
              phoneNumber: advertiser.phoneNumber,
            } : null
          };
        })
      );
      
      res.json(propertiesWithContact);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/properties/:id", async (req, res) => {
    try {
      const property = await storage.getProperty(Number(req.params.id));
      if (!property) {
        return res.status(404).json({ message: "Property not found" });
      }
      
      // Get advertiser contact information for social sharing
      const advertiser = await storage.getUser(property.userId);
      const propertyWithContact = {
        ...property,
        advertiser: advertiser ? {
          id: advertiser.id,
          fullName: advertiser.fullName,
          phoneNumber: advertiser.phoneNumber,
          email: advertiser.email,
          city: advertiser.city,
          country: advertiser.country
        } : null
      };
      
      res.json(propertyWithContact);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/properties", requireAuth, allowTrialPosting, async (req, res) => {
    try {
      const propertyData = insertPropertySchema.parse({
        ...req.body,
        userId: req.session.userId,
      });
      
      const property = await storage.createProperty(propertyData);
      res.json(property);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.put("/api/properties/:id", requireAuth, async (req, res) => {
    try {
      const property = await storage.getProperty(Number(req.params.id));
      if (!property) {
        return res.status(404).json({ message: "Property not found" });
      }
      
      if (property.userId !== req.session.userId) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      const updatedProperty = await storage.updateProperty(Number(req.params.id), req.body);
      res.json(updatedProperty);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/properties/:id", requireAuth, async (req, res) => {
    try {
      const property = await storage.getProperty(Number(req.params.id));
      if (!property) {
        return res.status(404).json({ message: "Property not found" });
      }
      
      if (property.userId !== req.session.userId) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      await storage.deleteProperty(Number(req.params.id));
      res.json({ message: "Property deleted successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/properties/user", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const properties = await storage.getUserProperties(Number(userId));
      res.json(properties);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Cars routes
  app.get("/api/cars", async (req, res) => {
    try {
      const filters = {
        make: req.query.make as string,
        model: req.query.model as string,
        minYear: req.query.minYear ? Number(req.query.minYear) : undefined,
        maxYear: req.query.maxYear ? Number(req.query.maxYear) : undefined,
        minPrice: req.query.minPrice ? Number(req.query.minPrice) : undefined,
        maxPrice: req.query.maxPrice ? Number(req.query.maxPrice) : undefined,
        location: req.query.location as string,
        search: req.query.search as string,
      };
      
      const cars = await storage.getCars(filters);
      
      // Add contact information for each car
      const carsWithContact = await Promise.all(
        cars.map(async (car) => {
          const advertiser = await storage.getUser(car.userId);
          return {
            ...car,
            user: advertiser ? {
              fullName: advertiser.fullName,
              phoneNumber: advertiser.phoneNumber,
            } : null
          };
        })
      );
      
      res.json(carsWithContact);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/cars/:id", async (req, res) => {
    try {
      const car = await storage.getCar(Number(req.params.id));
      if (!car) {
        return res.status(404).json({ message: "Car not found" });
      }
      
      // Get advertiser contact information for social sharing
      const advertiser = await storage.getUser(car.userId);
      const carWithContact = {
        ...car,
        advertiser: advertiser ? {
          id: advertiser.id,
          fullName: advertiser.fullName,
          phoneNumber: advertiser.phoneNumber,
          email: advertiser.email,
          city: advertiser.city,
          country: advertiser.country
        } : null
      };
      
      res.json(carWithContact);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/cars", requireAuth, allowTrialPosting, async (req, res) => {
    try {
      const carData = insertCarSchema.parse({
        ...req.body,
        userId: req.session.userId,
      });
      
      const car = await storage.createCar(carData);
      res.json(car);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.put("/api/cars/:id", requireAuth, async (req, res) => {
    try {
      const car = await storage.getCar(Number(req.params.id));
      if (!car) {
        return res.status(404).json({ message: "Car not found" });
      }
      
      if (car.userId !== req.session.userId) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      const updatedCar = await storage.updateCar(Number(req.params.id), req.body);
      res.json(updatedCar);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.delete("/api/cars/:id", requireAuth, async (req, res) => {
    try {
      const car = await storage.getCar(Number(req.params.id));
      if (!car) {
        return res.status(404).json({ message: "Car not found" });
      }
      
      if (car.userId !== req.session.userId) {
        return res.status(403).json({ message: "Not authorized" });
      }
      
      await storage.deleteCar(Number(req.params.id));
      res.json({ message: "Car deleted successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/cars/user", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const cars = await storage.getUserCars(Number(userId));
      res.json(cars);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Open orders routes - open viewing, subscription for contact details
  app.get("/api/open-orders", requireAuth, async (req, res) => {
    try {
      const filters = {
        propertyType: req.query.propertyType as string,
        location: req.query.location as string,
        search: req.query.search as string,
      };
      
      const orders = await storage.getOpenOrders(filters);
      
      // Check if current user has subscription for contact details
      const currentUser = await storage.getUser(req.session.userId!);
      const hasSubscription = currentUser?.role === 'admin' || 
        (currentUser?.isSubscribed && currentUser?.subscriptionExpiry && new Date() <= currentUser.subscriptionExpiry);
      
      // Add contact information only for subscribed users
      const ordersWithConditionalContact = await Promise.all(
        orders.map(async (order) => {
          if (hasSubscription) {
            // For anonymous orders, use contact details from order; for user orders, use account info
            if (order.userId) {
              const requester = await storage.getUser(Number(order.userId));
              return {
                ...order,
                user: requester ? {
                  fullName: requester.fullName,
                  phoneNumber: requester.phoneNumber,
                } : null
              };
            } else {
              // Anonymous order - use contact details from order
              return {
                ...order,
                user: order.contactName ? {
                  fullName: order.contactName,
                  phoneNumber: order.contactPhone,
                } : null
              };
            }
          } else {
            // Hide contact details for non-subscribed users
            return {
              ...order,
              user: null
            };
          }
        })
      );
      
      res.json(ordersWithConditionalContact);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/open-orders", async (req, res) => {
    try {
      // Allow anonymous posting - userId is optional
      const userId = req.session?.userId || null;
      
      const orderData = insertOpenOrderSchema.parse({
        ...req.body,
        userId: userId,
        requirements: Array.isArray(req.body.requirements) ? req.body.requirements : 
                     req.body.requirements ? req.body.requirements.split(',').map((req: string) => req.trim()).filter((req: string) => req.length > 0) : [],
      });
      
      const order = await storage.createOpenOrder(orderData);
      res.json(order);
    } catch (error: any) {
      res.status(400).json({ message: error.message });
    }
  });

  app.get("/api/open-orders/user", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const orders = await storage.getUserOpenOrders(Number(userId));
      res.json(orders);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Subscription routes
  app.post("/api/subscription/mock-payment", requireAuth, async (req, res) => {
    try {
      const { phoneNumber } = req.body;
      
      // Mock payment verification - in real app, verify with payment gateway
      const subscriptionExpiry = new Date();
      subscriptionExpiry.setDate(subscriptionExpiry.getDate() + 90); // 90 days
      
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      await storage.updateUser(Number(userId), {
        isSubscribed: true,
        subscriptionExpiry,
      });
      
      res.json({ 
        message: "Subscription activated successfully",
        expiryDate: subscriptionExpiry 
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // User profile routes
  app.get("/api/user/listings", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }
      
      const properties = await storage.getUserProperties(Number(userId));
      const cars = await storage.getUserCars(Number(userId));
      const openOrders = await storage.getUserOpenOrders(Number(userId));
      
      res.json({ properties, cars, openOrders });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Dashboard stats route
  app.get("/api/dashboard/stats", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      if (!userId) {
        return res.status(401).json({ message: "Unauthorized" });
      }

      const user = await storage.getUser(Number(userId));
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // For admin users, get total stats
      if (user.role === 'admin') {
        const allProperties = await storage.getProperties();
        const allCars = await storage.getCars();
        const allOrders = await storage.getOpenOrders();
        const allUsers = await storage.getAllUsers();

        res.json({
          totalProperties: allProperties.length,
          totalCars: allCars.length,
          totalOrders: allOrders.length,
          totalUsers: allUsers.length,
        });
      } else {
        // For regular users, get their own stats
        const userProperties = await storage.getUserProperties(Number(userId));
        const userCars = await storage.getUserCars(Number(userId));
        const userOrders = await storage.getUserOpenOrders(Number(userId));

        res.json({
          totalProperties: userProperties.length,
          totalCars: userCars.length,
          totalOrders: userOrders.length,
          totalUsers: 1,
        });
      }
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Admin routes
  app.get("/api/admin/users", requireAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      res.json(users);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/bypass-payment", requireAdmin, async (req, res) => {
    try {
      const { userId } = req.body;
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }

      const subscriptionExpiry = new Date();
      subscriptionExpiry.setDate(subscriptionExpiry.getDate() + 90);
      
      await storage.updateUserSubscription(Number(userId), true, subscriptionExpiry);
      console.log(`Admin bypassed payment for user ID ${userId}`);
      res.json({ message: "Payment bypassed successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/toggle-user-status", requireAdmin, async (req, res) => {
    try {
      const { userId, isActive } = req.body;
      if (userId === undefined || isActive === undefined) {
        return res.status(400).json({ message: "User ID and status are required" });
      }

      await storage.updateUserStatus(Number(userId), isActive);
      console.log(`Admin ${isActive ? 'activated' : 'deactivated'} user ID ${userId}`);
      res.json({ message: `User ${isActive ? 'activated' : 'deactivated'} successfully` });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/verify-payment", requireAdmin, async (req, res) => {
    try {
      const { userId, amount, note } = req.body;
      if (!userId || !amount) {
        return res.status(400).json({ message: "User ID and amount are required" });
      }
      
      const subscriptionExpiry = new Date();
      subscriptionExpiry.setDate(subscriptionExpiry.getDate() + 90);
      
      await storage.updateUserSubscription(Number(userId), true, subscriptionExpiry);
      console.log(`Admin verified payment of KSH ${amount} for user ID ${userId}. Note: ${note || 'No note'}`);
      res.json({ message: "Payment verified and subscription activated" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/bulk-sms", requireAdmin, async (req, res) => {
    try {
      const { message } = req.body;
      if (!message) {
        return res.status(400).json({ message: "Message is required" });
      }

      const advertisers = await storage.getAdvertisers();
      const phoneNumbers = advertisers
        .filter(advertiser => advertiser.phoneNumber)
        .map(advertiser => advertiser.phoneNumber);

      console.log(`Admin sending bulk SMS to ${phoneNumbers.length} advertisers:`);
      console.log(`Message: ${message}`);
      console.log(`Recipients: ${phoneNumbers.join(', ')}`);
      
      // Log SMS details for admin to send manually or integrate with SMS service
      res.json({ 
        message: "Bulk SMS prepared for sending", 
        recipientCount: phoneNumbers.length,
        recipients: phoneNumbers 
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Payment management endpoints
  app.get("/api/admin/payments", requireAdmin, async (req, res) => {
    try {
      const status = req.query.status as string;
      const payments = await storage.getPayments(status);
      res.json(payments);
    } catch (error: any) {
      console.error("Get payments error:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/approve-payment", requireAdmin, async (req, res) => {
    try {
      const { paymentId, adminNote } = req.body;
      const adminId = req.session.userId;
      
      if (!paymentId) {
        return res.status(400).json({ message: "Payment ID is required" });
      }

      // Get payment details
      const payment = await storage.getPayment(paymentId);
      if (!payment) {
        return res.status(404).json({ message: "Payment not found" });
      }

      // Update payment status to approved
      const updatedPayment = await storage.updatePaymentStatus(
        paymentId, 
        "approved", 
        adminNote, 
        adminId
      );

      // Activate user subscription for 90 days
      const subscriptionExpiry = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000);
      await storage.updateUserSubscription(payment.userId, true, subscriptionExpiry);

      console.log(`Admin approved payment ${paymentId} for user ${payment.userId}`);
      
      res.json({ 
        message: "Payment approved and subscription activated",
        payment: updatedPayment
      });
    } catch (error: any) {
      console.error("Approve payment error:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/reject-payment", requireAdmin, async (req, res) => {
    try {
      const { paymentId, adminNote } = req.body;
      const adminId = req.session.userId;
      
      if (!paymentId) {
        return res.status(400).json({ message: "Payment ID is required" });
      }

      const updatedPayment = await storage.updatePaymentStatus(
        paymentId, 
        "rejected", 
        adminNote || "Payment rejected by admin", 
        adminId
      );

      console.log(`Admin rejected payment ${paymentId}`);
      
      res.json({ 
        message: "Payment rejected",
        payment: updatedPayment
      });
    } catch (error: any) {
      console.error("Reject payment error:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // User payment submission endpoint
  app.post("/api/payments/submit", requireAuth, async (req, res) => {
    try {
      const { amount, mpesaReceiptNumber, phoneNumber } = req.body;
      const userId = req.session.userId;
      
      if (!amount || !phoneNumber) {
        return res.status(400).json({ message: "Amount and phone number are required" });
      }

      const payment = await storage.createPayment({
        userId: userId!,
        amount: amount.toString(),
        mpesaReceiptNumber,
        phoneNumber,
        status: "pending",
        paymentMethod: "mpesa",
        tillNumber: "3511028"
      });

      console.log(`User ${userId} submitted payment of KSH ${amount}`);
      
      res.json({ 
        message: "Payment submitted for approval",
        payment
      });
    } catch (error: any) {
      console.error("Submit payment error:", error);
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/payments/user", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId;
      const payments = await storage.getUserPayments(userId!);
      res.json(payments);
    } catch (error: any) {
      console.error("Get user payments error:", error);
      res.status(500).json({ message: error.message });
    }
  });

  // WhatsApp payment message endpoints
  app.get("/api/admin/whatsapp-payments", requireAuth, requireAdmin, async (req: any, res) => {
    try {
      const { status } = req.query;
      const payments = await storage.getWhatsappPayments(status);
      res.json(payments);
    } catch (error: any) {
      console.error("Error fetching WhatsApp payments:", error);
      res.status(500).json({ message: "Failed to fetch WhatsApp payments" });
    }
  });

  app.post("/api/admin/whatsapp-payment", requireAuth, requireAdmin, async (req: any, res) => {
    try {
      const payment = await storage.createWhatsappPayment(req.body);
      res.json(payment);
    } catch (error: any) {
      console.error("Error creating WhatsApp payment:", error);
      res.status(500).json({ message: "Failed to create WhatsApp payment" });
    }
  });

  app.post("/api/admin/match-whatsapp-payment", requireAuth, requireAdmin, async (req: any, res) => {
    try {
      const { paymentId, userId } = req.body;
      const payment = await storage.matchWhatsappPaymentToUser(paymentId, userId);
      res.json({ message: "Payment matched to user", payment });
    } catch (error: any) {
      console.error("Error matching WhatsApp payment:", error);
      res.status(500).json({ message: "Failed to match payment" });
    }
  });

  app.post("/api/admin/verify-whatsapp-payment", requireAuth, requireAdmin, async (req: any, res) => {
    try {
      const { paymentId, adminNotes } = req.body;
      const adminUserId = req.session.userId;

      // Update WhatsApp payment status to verified
      const whatsappPayment = await storage.updateWhatsappPaymentStatus(paymentId, "verified", adminNotes, adminUserId);

      // If matched to a user, create a regular payment record and activate subscription
      if (whatsappPayment.matchedUserId && whatsappPayment.amount) {
        // Create payment record
        const payment = await storage.createPayment({
          userId: whatsappPayment.matchedUserId,
          amount: whatsappPayment.amount,
          mpesaReceiptNumber: whatsappPayment.mpesaCode || "",
          phoneNumber: whatsappPayment.senderPhone || "",
          status: "approved",
          paymentMethod: "mpesa",
          tillNumber: "3511028",
          adminNote: `Verified from WhatsApp message: ${adminNotes}`,
          approvedBy: adminUserId,
        });

        // Activate subscription (90 days from now)
        const subscriptionExpiry = new Date();
        subscriptionExpiry.setDate(subscriptionExpiry.getDate() + 90);
        await storage.updateUserSubscription(whatsappPayment.matchedUserId, true, subscriptionExpiry);

        res.json({ 
          message: "WhatsApp payment verified and subscription activated", 
          whatsappPayment,
          payment 
        });
      } else {
        res.json({ 
          message: "WhatsApp payment verified but no user match found", 
          whatsappPayment 
        });
      }
    } catch (error: any) {
      console.error("Error verifying WhatsApp payment:", error);
      res.status(500).json({ message: "Failed to verify WhatsApp payment" });
    }
  });

  app.post("/api/admin/reject-whatsapp-payment", requireAuth, requireAdmin, async (req: any, res) => {
    try {
      const { paymentId, adminNotes } = req.body;
      const adminUserId = req.session.userId;

      const payment = await storage.updateWhatsappPaymentStatus(paymentId, "rejected", adminNotes, adminUserId);

      res.json({ message: "WhatsApp payment rejected", payment });
    } catch (error: any) {
      console.error("Error rejecting WhatsApp payment:", error);
      res.status(500).json({ message: "Failed to reject WhatsApp payment" });
    }
  });

  // Admin user management routes
  app.get("/api/admin/users", requireAdmin, async (req, res) => {
    try {
      const users = await storage.getAllUsers();
      const usersWithoutPasswords = users.map(user => ({
        ...user,
        password: undefined
      }));
      res.json(usersWithoutPasswords);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/toggle-user-status", requireAdmin, async (req, res) => {
    try {
      const { userId, isActive } = req.body;
      if (!userId || typeof isActive !== 'boolean') {
        return res.status(400).json({ message: "User ID and status are required" });
      }

      const updatedUser = await storage.updateUserStatus(Number(userId), isActive);
      res.json({ 
        message: `User ${isActive ? 'activated' : 'deactivated'} successfully`,
        user: { ...updatedUser, password: undefined }
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/update-user-subscription", requireAdmin, async (req, res) => {
    try {
      const { userId, isSubscribed, subscriptionExpiry } = req.body;
      if (!userId || typeof isSubscribed !== 'boolean') {
        return res.status(400).json({ message: "User ID and subscription status are required" });
      }

      const expiryDate = subscriptionExpiry ? new Date(subscriptionExpiry) : null;
      const updatedUser = await storage.updateUserSubscription(Number(userId), isSubscribed, expiryDate);
      
      res.json({ 
        message: "User subscription updated successfully",
        user: { ...updatedUser, password: undefined }
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.post("/api/admin/reset-user-trial", requireAdmin, async (req, res) => {
    try {
      const { userId } = req.body;
      if (!userId) {
        return res.status(400).json({ message: "User ID is required" });
      }

      const updatedUser = await storage.updateUserTrialStatus(Number(userId), false, false);
      res.json({ 
        message: "User trial reset successfully",
        user: { ...updatedUser, password: undefined }
      });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.delete("/api/admin/users/:userId", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (!userId) {
        return res.status(400).json({ message: "Valid user ID is required" });
      }

      // Check if trying to delete admin user
      const user = await storage.getUser(userId);
      if (user?.role === 'admin') {
        return res.status(403).json({ message: "Cannot delete admin users" });
      }

      // Delete user properties, cars, and orders first
      const userProperties = await storage.getUserProperties(userId);
      const userCars = await storage.getUserCars(userId);
      const userOrders = await storage.getUserOpenOrders(userId);

      for (const property of userProperties) {
        await storage.deleteProperty(property.id);
      }
      for (const car of userCars) {
        await storage.deleteCar(car.id);
      }
      for (const order of userOrders) {
        await storage.deleteOpenOrder(order.id);
      }

      // Note: User deletion would require additional database operations
      // For now, we'll deactivate the user instead
      await storage.updateUserStatus(userId, false);

      res.json({ message: "User account deactivated and all content removed" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  app.get("/api/admin/user-analytics/:userId", requireAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (!userId) {
        return res.status(400).json({ message: "Valid user ID is required" });
      }

      const user = await storage.getUser(userId);
      const properties = await storage.getUserProperties(userId);
      const cars = await storage.getUserCars(userId);
      const orders = await storage.getUserOpenOrders(userId);

      const analytics = {
        user: { ...user, password: undefined },
        totalProperties: properties.length,
        totalCars: cars.length,
        totalOrders: orders.length,
        joinDate: user?.createdAt,
        lastActivity: user?.updatedAt,
        trialStatus: user ? await storage.checkTrialExpiry(userId) : null
      };

      res.json(analytics);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Get user's own open orders
  app.get("/api/my-open-orders", requireAuth, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const userOrders = await storage.getUserOpenOrders(userId);
      
      // Add user details to each order
      const ordersWithUser = await Promise.all(
        userOrders.map(async (order) => {
          const user = order.userId ? await storage.getUser(Number(order.userId)) : null;
          return {
            ...order,
            user: user ? {
              fullName: user.fullName,
              phoneNumber: user.phoneNumber,
            } : (order.contactName ? {
              fullName: order.contactName,
              phoneNumber: order.contactPhone,
            } : null)
          };
        })
      );
      
      res.json(ordersWithUser);
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  // Social media sharing endpoint
  app.post("/api/share/social", requireAuth, async (req, res) => {
    try {
      const { platform, itemType, itemId, message } = req.body;
      const user = await storage.getUser(req.session.userId!);
      
      console.log(`User ${user?.email} shared ${itemType} ${itemId} to ${platform}`);
      console.log(`Message: ${message}`);
      
      res.json({ message: "Share logged successfully" });
    } catch (error: any) {
      res.status(500).json({ message: error.message });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

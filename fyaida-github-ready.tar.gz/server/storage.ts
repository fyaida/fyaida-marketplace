import {
  users,
  properties,
  cars,
  openOrders,
  payments,
  whatsappPayments,
  type User,
  type InsertUser,
  type Property,
  type InsertProperty,
  type Car,
  type InsertCar,
  type OpenOrder,
  type InsertOpenOrder,
  type Payment,
  type InsertPayment,
  type WhatsappPayment,
  type InsertWhatsappPayment,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc, ilike, gte, lte } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User>;
  updateUserStatus(id: number, isActive: boolean): Promise<User>;
  updateUserSubscription(id: number, isSubscribed: boolean, subscriptionExpiry: Date | null): Promise<User>;
  updateUserTrialStatus(id: number, trialExpired: boolean, trialNotified: boolean): Promise<User>;
  startUserTrial(id: number): Promise<User>;
  checkTrialExpiry(id: number): Promise<{ expired: boolean; daysLeft: number }>;
  getAllUsers(): Promise<User[]>;
  getAdvertisers(): Promise<User[]>;
  
  // Property operations
  getProperties(filters?: PropertyFilters): Promise<Property[]>;
  getProperty(id: number): Promise<Property | undefined>;
  createProperty(property: InsertProperty): Promise<Property>;
  updateProperty(id: number, updates: Partial<Property>): Promise<Property>;
  deleteProperty(id: number): Promise<void>;
  getUserProperties(userId: number): Promise<Property[]>;
  
  // Car operations
  getCars(filters?: CarFilters): Promise<Car[]>;
  getCar(id: number): Promise<Car | undefined>;
  createCar(car: InsertCar): Promise<Car>;
  updateCar(id: number, updates: Partial<Car>): Promise<Car>;
  deleteCar(id: number): Promise<void>;
  getUserCars(userId: number): Promise<Car[]>;
  
  // Open orders
  getOpenOrders(filters?: OpenOrderFilters): Promise<OpenOrder[]>;
  getOpenOrder(id: number): Promise<OpenOrder | undefined>;
  createOpenOrder(order: InsertOpenOrder): Promise<OpenOrder>;
  updateOpenOrder(id: number, updates: Partial<OpenOrder>): Promise<OpenOrder>;
  deleteOpenOrder(id: number): Promise<void>;
  getUserOpenOrders(userId: number): Promise<OpenOrder[]>;
  
  // Payment operations
  getPayments(status?: string): Promise<Payment[]>;
  getPayment(id: number): Promise<Payment | undefined>;
  createPayment(payment: InsertPayment): Promise<Payment>;
  updatePaymentStatus(id: number, status: string, adminNote?: string, approvedBy?: number): Promise<Payment>;
  getUserPayments(userId: number): Promise<Payment[]>;
  
  // WhatsApp payment message operations
  getWhatsappPayments(status?: string): Promise<WhatsappPayment[]>;
  getWhatsappPayment(id: number): Promise<WhatsappPayment | undefined>;
  createWhatsappPayment(payment: InsertWhatsappPayment): Promise<WhatsappPayment>;
  updateWhatsappPaymentStatus(id: number, status: string, adminNotes?: string, processedBy?: number): Promise<WhatsappPayment>;
  matchWhatsappPaymentToUser(id: number, userId: number): Promise<WhatsappPayment>;
  parseWhatsappMessage(messageText: string): { amount?: number; mpesaCode?: string; senderPhone?: string; recipientPhone?: string; transactionDate?: Date };
}

export interface PropertyFilters {
  type?: string;
  listingType?: string;
  location?: string;
  minPrice?: number;
  maxPrice?: number;
  bedrooms?: number;
  search?: string;
}

export interface CarFilters {
  make?: string;
  model?: string;
  minYear?: number;
  maxYear?: number;
  minPrice?: number;
  maxPrice?: number;
  location?: string;
  search?: string;
}

export interface OpenOrderFilters {
  propertyType?: string;
  location?: string;
  search?: string;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserStatus(id: number, isActive: boolean): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ isActive, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserSubscription(id: number, isSubscribed: boolean, subscriptionExpiry: Date | null): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ 
        isSubscribed, 
        subscriptionExpiry,
        updatedAt: new Date() 
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async updateUserTrialStatus(id: number, trialExpired: boolean, trialNotified: boolean): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ 
        trialExpired, 
        trialNotified,
        updatedAt: new Date() 
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async startUserTrial(id: number): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ 
        trialStartDate: new Date(),
        updatedAt: new Date() 
      })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async checkTrialExpiry(id: number): Promise<{ expired: boolean; daysLeft: number }> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    if (!user || !user.trialStartDate) {
      return { expired: false, daysLeft: 5 };
    }

    const now = new Date();
    const trialStart = new Date(user.trialStartDate);
    const daysPassed = Math.floor((now.getTime() - trialStart.getTime()) / (1000 * 60 * 60 * 24));
    const daysLeft = Math.max(0, 5 - daysPassed);
    const expired = daysPassed >= 5;

    return { expired, daysLeft };
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users).orderBy(users.createdAt);
  }

  async getAdvertisers(): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .where(eq(users.isSubscribed, true))
      .orderBy(users.createdAt);
  }

  // Property operations
  async getProperties(filters?: PropertyFilters): Promise<Property[]> {
    const conditions = [eq(properties.isActive, true)];
    
    if (filters) {
      if (filters.type) {
        conditions.push(eq(properties.type, filters.type));
      }
      if (filters.listingType) {
        conditions.push(eq(properties.listingType, filters.listingType));
      }
      if (filters.location) {
        conditions.push(ilike(properties.location, `%${filters.location}%`));
      }
      if (filters.minPrice) {
        conditions.push(gte(properties.price, filters.minPrice.toString()));
      }
      if (filters.maxPrice) {
        conditions.push(lte(properties.price, filters.maxPrice.toString()));
      }
      if (filters.bedrooms) {
        conditions.push(eq(properties.bedrooms, filters.bedrooms));
      }
      if (filters.search) {
        conditions.push(ilike(properties.title, `%${filters.search}%`));
      }
    }
    
    return await db.select().from(properties)
      .where(and(...conditions))
      .orderBy(desc(properties.createdAt));
  }

  async getProperty(id: number): Promise<Property | undefined> {
    const [property] = await db.select().from(properties).where(eq(properties.id, id));
    return property || undefined;
  }

  async createProperty(insertProperty: InsertProperty): Promise<Property> {
    const [property] = await db
      .insert(properties)
      .values(insertProperty)
      .returning();
    return property;
  }

  async updateProperty(id: number, updates: Partial<Property>): Promise<Property> {
    const [property] = await db
      .update(properties)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(properties.id, id))
      .returning();
    return property;
  }

  async deleteProperty(id: number): Promise<void> {
    await db.update(properties)
      .set({ isActive: false, updatedAt: new Date() })
      .where(eq(properties.id, id));
  }

  async getUserProperties(userId: number): Promise<Property[]> {
    return await db.select().from(properties)
      .where(and(eq(properties.userId, userId), eq(properties.isActive, true)))
      .orderBy(desc(properties.createdAt));
  }

  // Car operations
  async getCars(filters?: CarFilters): Promise<Car[]> {
    const conditions = [eq(cars.isActive, true)];
    
    if (filters) {
      if (filters.make) {
        conditions.push(eq(cars.make, filters.make));
      }
      if (filters.model) {
        conditions.push(eq(cars.model, filters.model));
      }
      if (filters.minYear) {
        conditions.push(gte(cars.year, filters.minYear));
      }
      if (filters.maxYear) {
        conditions.push(lte(cars.year, filters.maxYear));
      }
      if (filters.minPrice) {
        conditions.push(gte(cars.price, filters.minPrice.toString()));
      }
      if (filters.maxPrice) {
        conditions.push(lte(cars.price, filters.maxPrice.toString()));
      }
      if (filters.location) {
        conditions.push(ilike(cars.location, `%${filters.location}%`));
      }
      if (filters.search) {
        conditions.push(ilike(cars.title, `%${filters.search}%`));
      }
    }
    
    return await db.select().from(cars)
      .where(and(...conditions))
      .orderBy(desc(cars.createdAt));
  }

  async getCar(id: number): Promise<Car | undefined> {
    const [car] = await db.select().from(cars).where(eq(cars.id, id));
    return car || undefined;
  }

  async createCar(insertCar: InsertCar): Promise<Car> {
    const [car] = await db
      .insert(cars)
      .values(insertCar)
      .returning();
    return car;
  }

  async updateCar(id: number, updates: Partial<Car>): Promise<Car> {
    const [car] = await db
      .update(cars)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(cars.id, id))
      .returning();
    return car;
  }

  async deleteCar(id: number): Promise<void> {
    await db.update(cars)
      .set({ isActive: false, updatedAt: new Date() })
      .where(eq(cars.id, id));
  }

  async getUserCars(userId: number): Promise<Car[]> {
    return await db.select().from(cars)
      .where(and(eq(cars.userId, userId), eq(cars.isActive, true)))
      .orderBy(desc(cars.createdAt));
  }

  // Open orders
  async getOpenOrders(filters?: OpenOrderFilters): Promise<OpenOrder[]> {
    const conditions = [eq(openOrders.isActive, true)];
    
    if (filters) {
      if (filters.propertyType) {
        conditions.push(eq(openOrders.propertyType, filters.propertyType));
      }
      if (filters.location) {
        conditions.push(ilike(openOrders.location, `%${filters.location}%`));
      }
      if (filters.search) {
        conditions.push(ilike(openOrders.title, `%${filters.search}%`));
      }
    }
    
    return await db.select().from(openOrders)
      .where(and(...conditions))
      .orderBy(desc(openOrders.createdAt));
  }

  async getOpenOrder(id: number): Promise<OpenOrder | undefined> {
    const [order] = await db.select().from(openOrders).where(eq(openOrders.id, id));
    return order || undefined;
  }

  async createOpenOrder(insertOrder: InsertOpenOrder): Promise<OpenOrder> {
    const [order] = await db
      .insert(openOrders)
      .values(insertOrder)
      .returning();
    return order;
  }

  async updateOpenOrder(id: number, updates: Partial<OpenOrder>): Promise<OpenOrder> {
    const [order] = await db
      .update(openOrders)
      .set({ ...updates, updatedAt: new Date() })
      .where(eq(openOrders.id, id))
      .returning();
    return order;
  }

  async deleteOpenOrder(id: number): Promise<void> {
    await db.update(openOrders)
      .set({ isActive: false, updatedAt: new Date() })
      .where(eq(openOrders.id, id));
  }

  async getUserOpenOrders(userId: number): Promise<OpenOrder[]> {
    return await db.select().from(openOrders)
      .where(and(eq(openOrders.userId, userId), eq(openOrders.isActive, true)))
      .orderBy(desc(openOrders.createdAt));
  }

  // Payment operations
  async getPayments(status?: string): Promise<Payment[]> {
    const query = db.select({
      id: payments.id,
      userId: payments.userId,
      amount: payments.amount,
      mpesaReceiptNumber: payments.mpesaReceiptNumber,
      phoneNumber: payments.phoneNumber,
      status: payments.status,
      paymentMethod: payments.paymentMethod,
      tillNumber: payments.tillNumber,
      adminNote: payments.adminNote,
      approvedBy: payments.approvedBy,
      approvedAt: payments.approvedAt,
      createdAt: payments.createdAt,
      updatedAt: payments.updatedAt,
      user: {
        id: users.id,
        fullName: users.fullName,
        email: users.email,
        phoneNumber: users.phoneNumber,
      }
    }).from(payments)
    .leftJoin(users, eq(payments.userId, users.id));

    if (status) {
      return await query.where(eq(payments.status, status));
    }
    
    return await query.orderBy(desc(payments.createdAt));
  }

  async getPayment(id: number): Promise<Payment | undefined> {
    const [payment] = await db.select().from(payments).where(eq(payments.id, id));
    return payment;
  }

  async createPayment(insertPayment: InsertPayment): Promise<Payment> {
    const [payment] = await db
      .insert(payments)
      .values(insertPayment)
      .returning();
    return payment;
  }

  async updatePaymentStatus(id: number, status: string, adminNote?: string, approvedBy?: number): Promise<Payment> {
    const updateData: Partial<Payment> = {
      status,
      adminNote,
      updatedAt: new Date(),
    };

    if (status === 'approved' && approvedBy) {
      updateData.approvedBy = approvedBy;
      updateData.approvedAt = new Date();
    }

    const [payment] = await db
      .update(payments)
      .set(updateData)
      .where(eq(payments.id, id))
      .returning();
    return payment;
  }

  async getUserPayments(userId: number): Promise<Payment[]> {
    return await db.select().from(payments).where(eq(payments.userId, userId));
  }

  // WhatsApp payment message operations
  async getWhatsappPayments(status?: string): Promise<WhatsappPayment[]> {
    if (status && status !== 'all') {
      const result = await db.select().from(whatsappPayments).where(eq(whatsappPayments.status, status)).orderBy(desc(whatsappPayments.createdAt));
      return result;
    }

    const result = await db.select().from(whatsappPayments).orderBy(desc(whatsappPayments.createdAt));
    return result;
  }

  async getWhatsappPayment(id: number): Promise<WhatsappPayment | undefined> {
    const [payment] = await db.select().from(whatsappPayments).where(eq(whatsappPayments.id, id));
    return payment;
  }

  async createWhatsappPayment(insertPayment: InsertWhatsappPayment): Promise<WhatsappPayment> {
    const parsed = this.parseWhatsappMessage(insertPayment.messageText);
    
    const [payment] = await db
      .insert(whatsappPayments)
      .values({
        ...insertPayment,
        amount: parsed.amount?.toString() || insertPayment.amount,
        mpesaCode: parsed.mpesaCode || insertPayment.mpesaCode,
        senderPhone: parsed.senderPhone || insertPayment.senderPhone,
        recipientPhone: parsed.recipientPhone || insertPayment.recipientPhone,
        transactionDate: parsed.transactionDate || insertPayment.transactionDate,
      })
      .returning();
    return payment;
  }

  async updateWhatsappPaymentStatus(id: number, status: string, adminNotes?: string, processedBy?: number): Promise<WhatsappPayment> {
    const [payment] = await db
      .update(whatsappPayments)
      .set({
        status,
        adminNotes,
        processedBy,
        processedAt: new Date(),
        updatedAt: new Date(),
      })
      .where(eq(whatsappPayments.id, id))
      .returning();
    return payment;
  }

  async matchWhatsappPaymentToUser(id: number, userId: number): Promise<WhatsappPayment> {
    const [payment] = await db
      .update(whatsappPayments)
      .set({
        matchedUserId: userId,
        status: 'matched',
        updatedAt: new Date(),
      })
      .where(eq(whatsappPayments.id, id))
      .returning();
    return payment;
  }

  parseWhatsappMessage(messageText: string): { amount?: number; mpesaCode?: string; senderPhone?: string; recipientPhone?: string; transactionDate?: Date } {
    const result: any = {};
    
    // Extract amount (KSH 300.00 or Ksh300 or 300)
    const amountMatch = messageText.match(/(?:KSH|Ksh|ksh)\s*([0-9,]+(?:\.[0-9]{2})?)|([0-9,]+(?:\.[0-9]{2}))\s*(?:KSH|Ksh|ksh)/i);
    if (amountMatch) {
      const amountStr = (amountMatch[1] || amountMatch[2]).replace(/,/g, '');
      result.amount = parseFloat(amountStr);
    }

    // Extract M-Pesa transaction code (usually 10 characters, alphanumeric)
    const codeMatch = messageText.match(/\b([A-Z0-9]{8,12})\b/);
    if (codeMatch) {
      result.mpesaCode = codeMatch[1];
    }

    // Extract phone numbers (254XXXXXXXXX or 07XXXXXXXX)
    const phoneMatches = messageText.match(/(?:254|0)([0-9]{9})/g);
    if (phoneMatches && phoneMatches.length >= 1) {
      result.senderPhone = phoneMatches[0].startsWith('254') ? '+' + phoneMatches[0] : phoneMatches[0];
      if (phoneMatches.length >= 2) {
        result.recipientPhone = phoneMatches[1].startsWith('254') ? '+' + phoneMatches[1] : phoneMatches[1];
      }
    }

    // Extract transaction date (various formats)
    const dateMatch = messageText.match(/(\d{1,2}\/\d{1,2}\/\d{4}|\d{1,2}-\d{1,2}-\d{4}|\d{4}-\d{1,2}-\d{1,2})/);
    if (dateMatch) {
      result.transactionDate = new Date(dateMatch[1]);
    }

    return result;
  }
}

export const storage = new DatabaseStorage();

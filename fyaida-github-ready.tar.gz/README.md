# Fyaida - Kenya's Premier Property & Car Marketplace

A comprehensive digital marketplace for property and vehicle transactions in Kenya, featuring subscription-based access to premium features and M-Pesa payment integration.

## Features

- **Property Listings**: Land/plots and houses for sale/rent
- **Vehicle Marketplace**: Cars with detailed specifications
- **Open Orders**: Request specific properties/vehicles
- **User Authentication**: Secure login with role-based access
- **Admin Dashboard**: Complete user and payment management
- **M-Pesa Integration**: Till number 3511028 for subscriptions
- **WhatsApp Verification**: 0722869901 for payment processing
- **Social Media Sharing**: Direct sharing to WhatsApp, Facebook, etc.
- **Progressive Web App**: Mobile-optimized experience

## Technology Stack

- **Frontend**: React 18 with TypeScript, Vite build tool
- **Backend**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **UI Library**: Shadcn/ui with Tailwind CSS
- **Authentication**: Session-based with bcrypt
- **Payment**: M-Pesa integration for subscriptions

## Deployment

This application is configured for automatic deployment on Render.com using the included `render.yaml` file which creates:

- Web service with 512MB memory
- PostgreSQL database with 1GB storage
- Automatic environment variable configuration
- SSL certificate and custom domain support

## Live Application

Once deployed, the marketplace will be available with full functionality including user registration, property/car posting, admin management, and M-Pesa payment processing.

## Contact

- **WhatsApp**: 0722869901
- **M-Pesa Till**: 3511028
- **Office**: Moi Avenue, Nairobi
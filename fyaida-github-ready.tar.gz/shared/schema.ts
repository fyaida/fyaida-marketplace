import { pgTable, text, serial, integer, boolean, timestamp, decimal, varchar, jsonb, index } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Session storage table for authentication
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: varchar("email").notNull().unique(),
  password: varchar("password").notNull(),
  fullName: varchar("full_name").notNull(),
  phoneNumber: varchar("phone_number").notNull(),
  companyName: varchar("company_name"),
  country: varchar("country").notNull().default("Kenya"),
  city: varchar("city").notNull(),
  isSubscribed: boolean("is_subscribed").default(false),
  subscriptionExpiry: timestamp("subscription_expiry"),
  trialStartDate: timestamp("trial_start_date").defaultNow(), // When user first posts
  trialExpired: boolean("trial_expired").default(false), // Set to true after 5 days
  trialNotified: boolean("trial_notified").default(false), // Shown expiry message
  isAdmin: boolean("is_admin").default(false),
  isActive: boolean("is_active").default(true),
  role: varchar("role").default("user"), // 'admin', 'advertiser', 'user'
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Properties table (for land/plots and houses)
export const properties = pgTable("properties", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  title: varchar("title").notNull(),
  description: text("description").notNull(),
  type: varchar("type").notNull(), // 'land', 'house'
  listingType: varchar("listing_type").notNull(), // 'sale', 'rent', 'lease'
  price: decimal("price", { precision: 15, scale: 2 }).notNull(),
  location: varchar("location").notNull(),
  bedrooms: integer("bedrooms"),
  bathrooms: integer("bathrooms"),
  parking: integer("parking"),
  size: varchar("size"), // e.g., "0.5 acres", "150 sqm"
  amenities: text("amenities").array(),
  images: text("images").array(),
  isActive: boolean("is_active").default(true),
  isFeatured: boolean("is_featured").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Cars table
export const cars = pgTable("cars", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  title: varchar("title").notNull(),
  make: varchar("make").notNull(),
  model: varchar("model").notNull(),
  year: integer("year").notNull(),
  engineSize: varchar("engine_size").notNull(),
  mileage: integer("mileage"),
  condition: varchar("condition").notNull(), // 'excellent', 'good', 'fair', 'poor'
  price: decimal("price", { precision: 15, scale: 2 }).notNull(),
  paymentMethod: varchar("payment_method").notNull(), // 'cash', 'installments'
  installmentAmount: decimal("installment_amount", { precision: 15, scale: 2 }),
  installmentDuration: integer("installment_duration"), // in months
  location: varchar("location").notNull(),
  description: text("description").notNull(),
  images: text("images").array(),
  showRegistration: boolean("show_registration").default(true),
  isActive: boolean("is_active").default(true),
  isFeatured: boolean("is_featured").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Open Orders table
export const openOrders = pgTable("open_orders", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id), // Now optional for anonymous posting
  propertyType: varchar("property_type").notNull(), // 'land', 'house', 'car'
  title: varchar("title").notNull(),
  description: text("description").notNull(),
  budget: decimal("budget", { precision: 15, scale: 2 }).notNull(),
  location: varchar("location").notNull(),
  requirements: text("requirements").array(),
  // Contact details for anonymous posting
  contactName: varchar("contact_name"),
  contactPhone: varchar("contact_phone"),
  contactEmail: varchar("contact_email"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Payments table
export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  mpesaReceiptNumber: varchar("mpesa_receipt_number"),
  phoneNumber: varchar("phone_number").notNull(),
  status: varchar("status").notNull().default("pending"), // 'pending', 'approved', 'rejected'
  paymentMethod: varchar("payment_method").notNull().default("mpesa"),
  tillNumber: varchar("till_number").default("3511028"),
  adminNote: text("admin_note"),
  approvedBy: integer("approved_by").references(() => users.id),
  approvedAt: timestamp("approved_at"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// WhatsApp forwarded payment messages table
export const whatsappPayments = pgTable("whatsapp_payments", {
  id: serial("id").primaryKey(),
  messageText: text("message_text").notNull(), // Full WhatsApp message content
  senderPhone: varchar("sender_phone"), // Phone number that sent the payment
  recipientPhone: varchar("recipient_phone"), // Phone number that received the payment
  amount: decimal("amount", { precision: 15, scale: 2 }), // Extracted amount
  mpesaCode: varchar("mpesa_code"), // Extracted M-Pesa transaction code
  transactionDate: timestamp("transaction_date"), // Extracted transaction date
  status: varchar("status").notNull().default("unprocessed"), // unprocessed, matched, verified, rejected
  matchedUserId: integer("matched_user_id").references(() => users.id), // User matched to this payment
  processedBy: integer("processed_by").references(() => users.id), // Admin who processed
  processedAt: timestamp("processed_at"),
  adminNotes: text("admin_notes"),
  createdAt: timestamp("created_at").defaultNow(), // When message was forwarded
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  properties: many(properties),
  cars: many(cars),
  openOrders: many(openOrders),
  payments: many(payments),
}));

export const propertiesRelations = relations(properties, ({ one }) => ({
  user: one(users, {
    fields: [properties.userId],
    references: [users.id],
  }),
}));

export const carsRelations = relations(cars, ({ one }) => ({
  user: one(users, {
    fields: [cars.userId],
    references: [users.id],
  }),
}));

export const openOrdersRelations = relations(openOrders, ({ one }) => ({
  user: one(users, {
    fields: [openOrders.userId],
    references: [users.id],
  }),
}));

export const paymentsRelations = relations(payments, ({ one }) => ({
  user: one(users, {
    fields: [payments.userId],
    references: [users.id],
  }),
  approver: one(users, {
    fields: [payments.approvedBy],
    references: [users.id],
  }),
}));

export const whatsappPaymentsRelations = relations(whatsappPayments, ({ one }) => ({
  matchedUser: one(users, {
    fields: [whatsappPayments.matchedUserId],
    references: [users.id],
  }),
  processedBy: one(users, {
    fields: [whatsappPayments.processedBy],
    references: [users.id],
  }),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPropertySchema = createInsertSchema(properties).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  amenities: z.array(z.string()).optional(),
  images: z.array(z.string()).optional(),
});

export const insertCarSchema = createInsertSchema(cars).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  images: z.array(z.string()).optional(),
});

export const insertOpenOrderSchema = createInsertSchema(openOrders).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
}).extend({
  requirements: z.array(z.string()).optional(),
  userId: z.number().optional(), // Allow anonymous posting
});

export const insertPaymentSchema = createInsertSchema(payments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  approvedAt: true,
});

export const insertWhatsappPaymentSchema = createInsertSchema(whatsappPayments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Property = typeof properties.$inferSelect;
export type InsertProperty = z.infer<typeof insertPropertySchema>;
export type Car = typeof cars.$inferSelect;
export type InsertCar = z.infer<typeof insertCarSchema>;
export type OpenOrder = typeof openOrders.$inferSelect;
export type InsertOpenOrder = z.infer<typeof insertOpenOrderSchema>;
export type Payment = typeof payments.$inferSelect;
export type InsertPayment = z.infer<typeof insertPaymentSchema>;
export type WhatsappPayment = typeof whatsappPayments.$inferSelect;
export type InsertWhatsappPayment = z.infer<typeof insertWhatsappPaymentSchema>;
